import {
  BarChart3,
  Check,
  ChevronDown,
  Clock3,
  Cpu,
  Crosshair,
  Layers,
  Leaf,
  Maximize2,
  MemoryStick,
  Monitor,
  MousePointer2,
  Search,
  Settings2,
  Sparkles,
  WifiOff,
} from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { fpsLimits, hudPanelLabels, hudTextColors, hudThemes, widgetLabels } from "../lib/data";
import { world } from "../lib/images";
import type { GameModule, HudSettings, PanelKey, VisualSettings, WidgetKey } from "../lib/types";
import { cn } from "../utils/cn";

type Notify = (title: string, description?: string, tone?: "success" | "info" | "warning" | "error") => void;

const clamp = (value: number, min: number, max: number) => Math.min(max, Math.max(min, value));

function rgba(hex: string, alpha: number) {
  const clean = hex.replace("#", "");
  const full = clean.length === 3 ? clean.split("").map((char) => char + char).join("") : clean;
  const value = Number.parseInt(full || "08130d", 16);
  const r = (value >> 16) & 255;
  const g = (value >> 8) & 255;
  const b = value & 255;
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

const hudKeys = [
  { code: "KeyW", label: "W" },
  { code: "KeyA", label: "A" },
  { code: "KeyS", label: "S" },
  { code: "KeyD", label: "D" },
];

function useElementSize<T extends HTMLElement>() {
  const ref = useRef<T>(null);
  const [size, setSize] = useState({ width: 0, height: 0 });
  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    const observer = new ResizeObserver((entries) => {
      const box = entries[0]?.contentRect;
      if (box) setSize({ width: Math.round(box.width), height: Math.round(box.height) });
    });
    observer.observe(node);
    return () => observer.disconnect();
  }, []);
  return { ref, size };
}

/* ------------------------------------------------------------------ */
/* Real, measurable metrics for the preview environment                */
/* ------------------------------------------------------------------ */
function useLiveMetrics() {
  const [fps, setFps] = useState(0);
  const [now, setNow] = useState(() => new Date());
  const [uptime, setUptime] = useState(0);
  const [memory, setMemory] = useState<number | null>(null);
  const started = useRef(Date.now());

  useEffect(() => {
    let frames = 0;
    let last = performance.now();
    let raf = 0;
    const tick = (time: number) => {
      frames += 1;
      if (time - last >= 1000) {
        setFps(Math.round((frames * 1000) / (time - last)));
        frames = 0;
        last = time;
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    const clock = window.setInterval(() => {
      setNow(new Date());
      setUptime(Math.floor((Date.now() - started.current) / 1000));
      const perf = performance as Performance & { memory?: { usedJSHeapSize: number; jsHeapSizeLimit: number } };
      if (perf.memory && perf.memory.jsHeapSizeLimit > 0) {
        setMemory(Math.round((perf.memory.usedJSHeapSize / perf.memory.jsHeapSizeLimit) * 100));
      }
    }, 1000);
    return () => {
      cancelAnimationFrame(raf);
      window.clearInterval(clock);
    };
  }, []);

  return { fps, now, uptime, memory };
}

function formatUptime(seconds: number) {
  const h = String(Math.floor(seconds / 3600)).padStart(2, "0");
  const m = String(Math.floor((seconds % 3600) / 60)).padStart(2, "0");
  const s = String(seconds % 60).padStart(2, "0");
  return `${h}:${m}:${s}`;
}

/* ------------------------------------------------------------------ */
/* Shared pieces for the in-game panels                                */
/* ------------------------------------------------------------------ */
function PanelHead({ icon, title, onToggle, open }: { icon: React.ReactNode; title: string; onToggle: () => void; open: boolean }) {
  return (
    <button
      type="button"
      onClick={(event) => {
        event.stopPropagation();
        onToggle();
      }}
      className="flex w-full items-center gap-1.5 border-b border-white/10 px-2 py-1.5 text-left transition-colors hover:bg-white/[0.035]"
    >
      <span className="flex h-4 w-4 items-center justify-center text-[var(--acc)]">{icon}</span>
      <span className="flex-1 text-[8.5px] font-bold tracking-[0.01em] text-[#eaf6ed]">{title}</span>
      <ChevronDown size={10} className={cn("text-white/45 transition-transform", !open && "-rotate-90")} />
    </button>
  );
}

function MiniToggle({ checked, onChange, label, disabled }: { checked: boolean; onChange: (value: boolean) => void; label: string; disabled?: boolean }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      disabled={disabled}
      onClick={(event) => {
        event.stopPropagation();
        if (!disabled) onChange(!checked);
      }}
      className={cn("h-[13px] w-[24px] shrink-0 rounded-full border transition-all", disabled && "opacity-40")}
      style={{
        background: checked ? "linear-gradient(90deg,#1f8f45,#5dff8e)" : "rgba(255,255,255,0.09)",
        borderColor: checked ? "rgba(120,255,155,0.7)" : "rgba(255,255,255,0.16)",
        boxShadow: checked ? "0 0 7px rgba(77,255,136,0.45), inset 0 1px 0 rgba(255,255,255,0.3)" : undefined,
      }}
    >
      <span
        className="block h-[9px] w-[9px] rounded-full bg-[#f2fff5] shadow transition-transform"
        style={{ transform: `translateX(${checked ? 13 : 2}px) translateY(1px)` }}
      />
    </button>
  );
}

function EditorRow({ label, value, children }: { label: string; value?: string; children?: React.ReactNode }) {
  return (
    <div className="flex items-center gap-1.5 py-[3px]">
      <span className="min-w-0 flex-1 truncate text-[7.5px] font-medium text-[#c9dccf]">{label}</span>
      {value && <span className="font-mono text-[7px] text-[#8fb29b]">{value}</span>}
      {children}
    </div>
  );
}

function MiniSlider({
  label,
  value,
  min,
  max,
  step,
  format,
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  format: (value: number) => string;
  onChange: (value: number) => void;
}) {
  return (
    <div
      className="py-[3.5px]"
      onClick={(event) => event.stopPropagation()}
      onPointerDown={(event) => event.stopPropagation()}
    >
      <div className="flex items-center justify-between gap-1">
        <span className="text-[7.5px] font-medium text-[#c9dccf]">{label}</span>
        <span className="font-mono text-[7px] text-[#d6f7df]">{format(value)}</span>
      </div>
      <input
        type="range"
        className="range mt-1 !h-[3px]"
        aria-label={label}
        min={min}
        max={max}
        step={step}
        value={value}
        style={{ "--pct": `${((value - min) / (max - min)) * 100}%` } as React.CSSProperties}
        onChange={(event) => onChange(Number(event.target.value))}
      />
    </div>
  );
}

function Swatches({ colors, value, onChange }: { colors: string[]; value: string; onChange: (color: string) => void }) {
  return (
    <div className="flex items-center gap-1" onClick={(event) => event.stopPropagation()}>
      {colors.map((color) => (
        <button
          key={color}
          type="button"
          aria-label={`Цвет ${color}`}
          aria-pressed={value.toLowerCase() === color.toLowerCase()}
          onClick={() => onChange(color)}
          className={cn(
            "h-3 w-3 rounded-[2px] border transition-transform",
            value.toLowerCase() === color.toLowerCase()
              ? "scale-110 border-white/80 shadow-[0_0_0_1px_rgba(77,255,136,0.5)]"
              : "border-white/20 hover:scale-105",
          )}
          style={{ background: color }}
        />
      ))}
    </div>
  );
}

type Collapse = Record<string, boolean>;

export function Preview({
  hud,
  visuals,
  modules,
  onChange,
  onVisualsChange,
  onToggleModule,
  onNotify,
  onOpenVisuals,
  onReset,
}: {
  hud: HudSettings;
  visuals: VisualSettings;
  modules: GameModule[];
  onChange: (patch: Partial<HudSettings>) => void;
  onVisualsChange: (patch: Partial<VisualSettings>) => void;
  onToggleModule: (id: string) => void;
  onNotify: Notify;
  onOpenVisuals: () => void;
  onReset: () => void;
}) {
  const { ref: sceneRef, size } = useElementSize<HTMLDivElement>();
  const metrics = useLiveMetrics();
  const [pressed, setPressed] = useState<Set<string>>(new Set());
  const [mouse, setMouse] = useState({ left: false, right: false });
  const [clicks, setClicks] = useState<number[]>([]);
  const [pop, setPop] = useState<{ id: number; x: number; y: number } | null>(null);
  const [collapsed, setCollapsed] = useState<Collapse>({});
  const [moduleQuery, setModuleQuery] = useState("");
  const [visualOnly, setVisualOnly] = useState(false);
  const [settingsGroups, setSettingsGroups] = useState<Collapse>({ visibility: false, profiles: false, shortcuts: false, about: false });
  const dragRef = useRef<{
    target: "hud" | "modules";
    startX: number;
    startY: number;
    originX: number;
    originY: number;
    width: number;
    height: number;
  } | null>(null);

  const panels = hud.panels ?? { home: true, hud: true, modules: true, appearance: true, settings: true, visuals: true };
  const widgets = hud.widgets ?? {} as HudSettings["widgets"];
  const editing = Boolean(hud.showEditorPanels);
  const accent = hud.accent || "#4dff88";
  const textColor = hud.textColor;
  const background = rgba(hud.panelBg, clamp(hud.opacity, 0.25, 1));
  const radius = hud.rounding;
  const glow = hud.glow ? `0 0 22px ${rgba(accent, 0.12)}, 0 8px 26px rgba(0,0,0,0.55)` : "0 8px 24px rgba(0,0,0,0.4)";

  const cps = clicks.length;
  const timeLabel = new Intl.DateTimeFormat("ru-RU", { hour: "2-digit", minute: "2-digit" }).format(metrics.now);
  const memory = metrics.memory;
  const memoryText = memory === null ? "—" : `${memory}%`;
  const resolutionText = size.width > 0 ? `${size.width}×${size.height}` : "—";

  useEffect(() => {
    const down = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      if (target && ["INPUT", "TEXTAREA", "SELECT"].includes(target.tagName)) return;
      if (hudKeys.some((key) => key.code === event.code) || event.code === "Space" || event.code === "ShiftLeft") {
        setPressed((current) => new Set(current).add(event.code));
      }
    };
    const up = (event: KeyboardEvent) => {
      setPressed((current) => {
        const next = new Set(current);
        next.delete(event.code);
        return next;
      });
    };
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    return () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
    };
  }, []);

  useEffect(() => {
    if (!dragRef.current) return;
    const move = (event: PointerEvent) => {
      const drag = dragRef.current;
      if (!drag) return;
      const x = clamp(drag.originX + ((event.clientX - drag.startX) / drag.width) * 100, 0, 92);
      const y = clamp(drag.originY + ((event.clientY - drag.startY) / drag.height) * 100, 0, 92);
      if (drag.target === "hud") onChange({ position: "custom", x: Math.round(x), y: Math.round(y) });
      else onChange({ moduleX: Math.round(x), moduleY: Math.round(y) });
    };
    const end = () => {
      dragRef.current = null;
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", end);
    window.addEventListener("pointercancel", end);
    return () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", end);
      window.removeEventListener("pointercancel", end);
    };
  }, [onChange]);

  const startDrag = (event: React.PointerEvent, target: "hud" | "modules", x: number, y: number) => {
    if (editing) return;
    event.preventDefault();
    event.stopPropagation();
    const box = sceneRef.current?.getBoundingClientRect();
    if (!box) return;
    dragRef.current = { target, startX: event.clientX, startY: event.clientY, originX: x, originY: y, width: box.width, height: box.height };
  };

  const registerClick = (event: React.MouseEvent<HTMLDivElement>) => {
    const now = Date.now();
    setClicks((current) => [...current.filter((time) => now - time < 1000), now].slice(-24));
    const box = sceneRef.current?.getBoundingClientRect();
    if (box) {
      setPop({ id: now, x: event.clientX - box.left, y: event.clientY - box.top });
      window.setTimeout(() => setPop((current) => (current?.id === now ? null : current)), 600);
    }
  };

  const setWidget = (key: WidgetKey, value: boolean) => onChange({ widgets: { ...widgets, [key]: value } });
  const toggleCollapse = (key: string) => setCollapsed((current) => ({ ...current, [key]: !current[key] }));
  const isOpen = (key: string) => collapsed[key] !== true;

  const scope = Math.min(size.width > 0 ? (size.width - 8) / 760 : 0.8, size.height > 0 ? (size.height - 8) / 646 : 0.8);
  const scale = clamp(Number.isFinite(scope) && scope > 0 ? scope : 0.8, 0.5, 1);

  const anchor: React.CSSProperties =
    hud.position === "custom"
      ? { left: `${hud.x}%`, top: `${hud.y}%` }
      : hud.position === "top-left"
        ? { left: "3%", top: "5%" }
        : hud.position === "top-right"
          ? { right: "3%", top: "5%" }
          : hud.position === "bottom-left"
            ? { left: "3%", bottom: "14%" }
            : { right: "3%", bottom: "14%" };

  const enabledModules = modules.filter((module) => module.enabled);
  const moduleNames = [
    ...enabledModules.map((module) => module.name),
    ...(visuals.hat.enabled ? ["China Hat"] : []),
    ...(visuals.trail.enabled ? ["Trail"] : []),
  ];
  const filteredModules = modules.filter((module) => {
    const matches = !moduleQuery.trim() || module.name.toLowerCase().includes(moduleQuery.trim().toLowerCase());
    return matches && (!visualOnly || module.category === "Визуал");
  });

  const panelStyle: React.CSSProperties = {
    background,
    border: `1px solid ${rgba(accent, 0.24)}`,
    borderRadius: radius,
    boxShadow: glow,
    backdropFilter: "blur(8px)",
    width: 143,
    minWidth: 143,
    maxWidth: 143,
    overflow: "hidden",
    color: textColor,
    filter: `brightness(${hud.brightness})`,
  };

  return (
    <div
      ref={sceneRef}
      className="scene relative h-full min-h-[360px] w-full touch-none select-none"
      onClick={registerClick}
      onMouseDown={(event) => setMouse((current) => ({ ...current, left: event.button === 0 || current.left, right: event.button === 2 || current.right }))}
      onMouseUp={() => setMouse({ left: false, right: false })}
      onContextMenu={(event) => event.preventDefault()}
      role="img"
      aria-label="Предпросмотр внутриигрового HUD и панелей редактора. Клик по фону считает CPS."
    >
      <img src={world} alt="" className="pointer-events-none absolute inset-0 h-full w-full object-cover" draggable={false} />
      <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(180deg,rgba(4,9,6,0.34),rgba(4,9,6,0.08)_40%,rgba(3,7,5,0.38))]" />

      <div className="pointer-events-none absolute left-2 top-2 z-30 flex flex-wrap items-center gap-1">
        <span className="rounded border border-[rgba(var(--acc-rgb),0.4)] bg-[#061009]/85 px-1.5 py-1 font-mono text-[7px] font-bold tracking-wide text-[#cfffdc] backdrop-blur">
          GAY client v0.3.5-hud
        </span>
        {widgets.fps && (
          <span className="flex items-center gap-1 rounded border border-white/10 bg-black/55 px-1.5 py-1 font-mono text-[7px] text-[#9fe8b4] backdrop-blur">
            <BarChart3 size={8} />
            {metrics.fps} fps <span className="text-white/45">(превью)</span>
          </span>
        )}
        {!editing && (
          <span className="rounded border border-amber-300/25 bg-amber-400/10 px-1.5 py-1 font-mono text-[7px] text-amber-100/90 backdrop-blur">
            сцена-макет · не игровая камера
          </span>
        )}
      </div>

      <div className="pointer-events-none absolute right-2 top-[92px] z-30 flex flex-col items-end gap-1">
        {hud.notifications && !editing && (
          <div
            className="pointer-events-auto max-w-[200px] rounded-md border px-2 py-1.5 text-[7px] leading-relaxed shadow-lg backdrop-blur"
            style={{ background, borderColor: rgba(accent, 0.3), borderRadius: radius, color: textColor }}
          >
            <p className="flex items-center gap-1 font-bold" style={{ color: accent }}>
              <Leaf size={8} /> HUD · сессия
            </p>
            <p className="mt-0.5 text-white/60">
              Прозрачность {Math.round(hud.opacity * 100)}% · скругление {hud.rounding}px. Настройки
              применяются сразу.
            </p>
          </div>
        )}

      </div>

      {/* ============ In-game editor panels (screenshot 1 reference) ============ */}
      {editing ? (
        <div className="pointer-events-none absolute inset-0 flex items-start justify-center pt-1.5">
          <div
            className="pointer-events-auto relative"
            style={{ width: 760, height: 646, transform: `scale(${scale})`, transformOrigin: "top center" }}
            onClick={(event) => event.stopPropagation()}
          >
            {hud.showToolbar && (
              <div
                className="absolute left-1/2 top-0 z-20 flex max-w-[470px] -translate-x-1/2 items-center gap-1 rounded-lg px-1.5 py-1"
                style={{ background: rgba(hud.panelBg, Math.min(0.96, hud.opacity + 0.1)), border: `1px solid ${rgba(accent, 0.3)}`, borderRadius: radius, boxShadow: glow }}
              >
                <span className="flex items-center gap-1 rounded px-1.5 py-0.5" style={{ background: rgba(accent, 0.1), color: accent }}>
                  <Leaf size={10} />
                  <span className="font-mono text-[7px] font-bold whitespace-nowrap">AOGIRI</span>
                </span>
                {[
                  { label: "Panels", action: () => onChange({ showEditorPanels: false }) },
                  { label: "Edit HUD", action: () => onChange({ panels: { ...panels, hud: true } }) },
                  { label: "Save", action: () => onNotify("HUD сохранён в сессии", "В нативном клиенте настройки плашки живут до закрытия игры.", "success") },
                ].map((item) => (
                  <button
                    key={item.label}
                    type="button"
                    onClick={item.action}
                    className="rounded px-1 py-0.5 text-[7px] font-semibold whitespace-nowrap text-[#e3f4e8] transition-colors hover:bg-white/10"
                  >
                    {item.label}
                  </button>
                ))}
                <span className="ml-0.5 border-l border-white/15 pl-1.5 font-mono text-[6.5px] tracking-wide whitespace-nowrap text-white/55">
                  RSHIFT
                </span>
              </div>
            )}

            <div className="absolute left-1/2 top-[42px] flex -translate-x-1/2 items-start gap-[5px]">
              {/* HOME */}
              {panels.home && (
                <div style={panelStyle}>
                  <PanelHead icon={<Leaf size={9} />} title="Home" open={isOpen("home")} onToggle={() => toggleCollapse("home")} />
                  {isOpen("home") && (
                    <div className="px-2 py-1.5">
                      <div className="flex items-center gap-1.5">
                        <Leaf size={12} style={{ color: accent }} />
                        <p className="font-mono text-[8px] font-bold leading-tight" style={{ color: accent }}>
                          AOGIRI
                          <br />
                          GREEN
                        </p>
                      </div>
                      <p className="mt-1 font-mono text-[6.5px] leading-relaxed text-white/45">
                        Visual client / 0.3.5-hud
                        <br />
                        {hud.theme === "aogiri" ? "Aogiri Green theme" : hud.theme === "emerald" ? "Emerald theme" : "Graphite theme"}
                      </p>
                      <div className="mt-1.5 space-y-[3px] border-t border-white/10 pt-1.5">
                        <EditorRow label="DLL" value="сессия" />
                        <EditorRow label="Интерфейс" value="превью" />
                        <EditorRow label="Аккаунт" value="нет доступа" />
                        <EditorRow label="Uptime" value={formatUptime(metrics.uptime)} />
                        <EditorRow label="Размер" value={resolutionText} />
                      </div>
                      <p className="mt-1.5 border-t border-white/10 pt-1.5 text-[6.5px] leading-relaxed text-white/45">
                        Все значения — этой сессии предпросмотра.
                      </p>
                    </div>
                  )}
                </div>
              )}

              {/* HUD */}
              {panels.hud && (
                <div style={panelStyle}>
                  <PanelHead icon={<Monitor size={9} />} title="HUD" open={isOpen("hud")} onToggle={() => toggleCollapse("hud")} />
                  {isOpen("hud") && (
                    <div className="px-2 py-1.5">
                      {(["fps", "cps", "keys", "clock", "watermark", "ping", "coordinates", "performance", "resolution"] as WidgetKey[]).map((key) => (
                        <EditorRow key={key} label={widgetLabels[key].replace("Показывать ", "")}>
                          <MiniToggle checked={Boolean(widgets[key])} onChange={(value) => setWidget(key, value)} label={widgetLabels[key]} />
                        </EditorRow>
                      ))}
                      <div className="mt-1 border-t border-white/10 pt-1">
                        <MiniSlider label="HUD Scale" value={hud.scale} min={0.7} max={1.6} step={0.01} format={(v) => `${v.toFixed(2)}x`} onChange={(scale) => onChange({ scale })} />
                        <MiniSlider label="Key size" value={hud.keySize} min={0.7} max={1.6} step={0.01} format={(v) => `${v.toFixed(2)}x`} onChange={(keySize) => onChange({ keySize })} />
                      </div>
                      <button
                        type="button"
                        onClick={() => onChange({ showEditorPanels: false })}
                        className="mt-1 w-full rounded py-[4px] text-[7.5px] font-bold"
                        style={{ background: rgba(accent, 0.12), border: `1px solid ${rgba(accent, 0.3)}`, color: accent }}
                      >
                        Edit HUD
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* MODULES */}
              {panels.modules && (
                <div style={panelStyle}>
                  <PanelHead icon={<Layers size={9} />} title="Modules" open={isOpen("modules")} onToggle={() => toggleCollapse("modules")} />
                  {isOpen("modules") && (
                    <div className="px-2 py-1.5">
                      <div className="flex items-center gap-1 rounded border border-white/10 bg-black/30 px-1.5 py-1">
                        <Search size={8} className="text-white/40" />
                        <input
                          value={moduleQuery}
                          onChange={(event) => setModuleQuery(event.target.value)}
                          placeholder="Search…"
                          aria-label="Поиск модулей в редакторе HUD"
                          className="w-full min-w-0 bg-transparent text-[7px] text-[#e7f6ec] placeholder:text-white/35 focus:outline-none"
                        />
                      </div>
                      <button
                        type="button"
                        onClick={() => setVisualOnly((value) => !value)}
                        className="mt-1 flex w-full items-center gap-1 text-left text-[7px] text-white/60"
                      >
                        <span
                          className="flex h-[9px] w-[9px] items-center justify-center rounded-[2px] border"
                          style={{ borderColor: rgba(accent, 0.6), background: visualOnly ? rgba(accent, 0.4) : "transparent" }}
                        >
                          {visualOnly && <Check size={6} style={{ color: "#04120a" }} />}
                        </span>
                        <span className="truncate">Visual only</span>
                      </button>
                      <div className="scroll mt-1 max-h-[132px] space-y-0 overflow-y-auto pr-0.5">
                        {filteredModules.map((module) => (
                          <EditorRow key={module.id} label={module.name} value={module.bind}>
                            <MiniToggle checked={module.enabled} onChange={() => onToggleModule(module.id)} label={`Модуль ${module.name}`} />
                          </EditorRow>
                        ))}
                        {filteredModules.length === 0 && (
                          <p className="py-2 text-center text-[7px] text-white/40">ничего не найдено</p>
                        )}
                      </div>
                      <div className="mt-1 flex gap-1 border-t border-white/10 pt-1">
                        <button
                          type="button"
                          onClick={() => onChange({ panels: { ...panels, hud: true } })}
                          className="min-w-0 flex-1 truncate rounded bg-white/8 px-1 py-[3px] text-[6.5px] text-white/75 hover:bg-white/12"
                        >
                          Настройки
                        </button>
                        <button
                          type="button"
                          onClick={() => onNotify("Магазин модулей", "В прототипе нет сетевого магазина и загрузки файлов.", "info")}
                          className="min-w-0 flex-1 truncate rounded bg-white/8 px-1 py-[3px] text-[6.5px] text-white/75 hover:bg-white/12"
                        >
                          Магазин
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* APPEARANCE */}
              {panels.appearance && (
                <div style={panelStyle}>
                  <PanelHead icon={<Sparkles size={9} />} title="Appearance" open={isOpen("appearance")} onToggle={() => toggleCollapse("appearance")} />
                  {isOpen("appearance") && (
                    <div className="px-2 py-1.5">
                      <p className="text-[7px] text-white/55">Theme</p>
                      <div className="relative mt-0.5">
                        <select
                          value={hud.theme}
                          aria-label="Тема HUD"
                          onChange={(event) => {
                            const theme = hudThemes.find((item) => item.id === event.target.value) ?? hudThemes[0];
                            onChange({ theme: theme.id, accent: theme.accent, panelBg: theme.bg });
                          }}
                          className="w-full appearance-none rounded border border-white/12 bg-black/35 px-1.5 py-[3px] pr-5 text-[7px] font-semibold text-[#e6f6eb] focus:border-[rgba(77,255,136,0.5)] focus:outline-none"
                        >
                          {hudThemes.map((theme) => (
                            <option key={theme.id} value={theme.id}>
                              {theme.name}
                            </option>
                          ))}
                        </select>
                        <ChevronDown size={8} className="pointer-events-none absolute right-1.5 top-1/2 -translate-y-1/2 text-white/45" />
                      </div>
                      <div className="mt-1 space-y-[3px]">
                        <EditorRow label="Accent"><Swatches colors={hudTextColors.concat(["#4dff88"])} value={accent} onChange={(value) => onChange({ accent: value })} /></EditorRow>
                        <EditorRow label="Background"><Swatches colors={["#08130d", "#07130f", "#0d1110", "#101318", "#151a15"]} value={hud.panelBg} onChange={(panelBg) => onChange({ panelBg })} /></EditorRow>
                        <EditorRow label="Text"><Swatches colors={hudTextColors} value={textColor} onChange={(value) => onChange({ textColor: value })} /></EditorRow>
                      </div>
                      <div className="mt-1 border-t border-white/10 pt-1">
                        <MiniSlider label="Brightness" value={hud.brightness} min={0.6} max={1.4} step={0.01} format={(v) => `${v.toFixed(2)}x`} onChange={(brightness) => onChange({ brightness })} />
                        <MiniSlider label="Opacity" value={hud.opacity} min={0.2} max={1} step={0.01} format={(v) => v.toFixed(2)} onChange={(opacity) => onChange({ opacity })} />
                        <MiniSlider label="Rounding" value={hud.rounding} min={0} max={18} step={1} format={(v) => `${v}px`} onChange={(rounding) => onChange({ rounding })} />
                      </div>
                      <EditorRow label="Glow Effect">
                        <MiniToggle checked={hud.glow} onChange={(glow) => onChange({ glow })} label="Glow Effect" />
                      </EditorRow>
                    </div>
                  )}
                </div>
              )}

              {/* SETTINGS */}
              {panels.settings && (
                <div style={panelStyle}>
                  <PanelHead icon={<Settings2 size={9} />} title="Settings" open={isOpen("settings")} onToggle={() => toggleCollapse("settings")} />
                  {isOpen("settings") && (
                    <div className="px-2 py-1.5">
                      <MiniSlider label="Animation Speed" value={hud.animationSpeed} min={0.25} max={2} step={0.05} format={(v) => `${v.toFixed(2)}x`} onChange={(animationSpeed) => onChange({ animationSpeed })} />
                      <div className="py-[2px]">
                        <p className="text-[7px] text-white/55">FPS Limit</p>
                        <div className="relative mt-0.5">
                          <select
                            value={hud.fpsLimit}
                            aria-label="Лимит FPS"
                            onChange={(event) => onChange({ fpsLimit: Number(event.target.value) })}
                            className="w-full appearance-none rounded border border-white/12 bg-black/35 px-1.5 py-[3px] pr-5 text-[7px] text-[#e6f6eb] focus:outline-none"
                          >
                            {fpsLimits.map((limit) => (
                              <option key={limit} value={limit}>
                                {limit} Hz
                              </option>
                            ))}
                          </select>
                          <ChevronDown size={8} className="pointer-events-none absolute right-1.5 top-1/2 -translate-y-1/2 text-white/45" />
                        </div>
                      </div>
                      {(
                        [
                          { id: "visibility", label: "Panel visibility" },
                          { id: "profiles", label: "Profiles" },
                          { id: "shortcuts", label: "Module shortcuts" },
                          { id: "about", label: "About" },
                        ] as const
                      ).map((group) => (
                        <div key={group.id} className="border-t border-white/8 py-[1px]">
                          <button
                            type="button"
                            onClick={() => setSettingsGroups((current) => ({ ...current, [group.id]: !current[group.id] }))}
                            className="flex w-full items-center gap-1 py-[3px] text-left text-[7.5px] font-semibold text-[#d8ecde]"
                          >
                            <ChevronDown size={8} className={cn("text-white/45 transition-transform", !settingsGroups[group.id] && "-rotate-90")} />
                            {group.label}
                          </button>
                          {settingsGroups[group.id] && group.id === "visibility" && (
                            <div className="pb-1 pl-2.5">
                              {(Object.keys(panels) as PanelKey[]).filter((key) => key !== "visuals").map((key) => (
                                <EditorRow key={key} label={hudPanelLabels[key]}>
                                  <MiniToggle checked={panels[key]} onChange={(value) => onChange({ panels: { ...panels, [key]: value } })} label={`Панель ${hudPanelLabels[key]}`} />
                                </EditorRow>
                              ))}
                              <EditorRow label="Visuals">
                                <MiniToggle checked={panels.visuals} onChange={(value) => onChange({ panels: { ...panels, visuals: value } })} label="Панель Visuals" />
                              </EditorRow>
                            </div>
                          )}
                          {settingsGroups[group.id] && group.id === "profiles" && (
                            <div className="space-y-[2px] pb-1 pl-2.5 text-[7px] text-white/55">
                              <p>Текущая сессия · {hud.theme}</p>
                              <button
                                type="button"
                                onClick={() => onNotify("Профили HUD", "Откройте вкладку «Профили» в лаунчере, чтобы сохранить сборку.", "info")}
                                className="rounded border border-white/12 bg-white/5 px-1.5 py-[2px] text-[7px] text-white/70 hover:bg-white/10"
                              >
                                Сохранить профиль…
                              </button>
                            </div>
                          )}
                          {settingsGroups[group.id] && group.id === "shortcuts" && (
                            <div className="space-y-[2px] pb-1 pl-2.5">
                              {hudKeys.concat([{ code: "Space", label: "SPACE" }]).map((key) => (
                                <div key={key.code} className="flex items-center justify-between text-[7px] text-white/55">
                                  <span>{key.label}</span>
                                  <kbd className="rounded border border-white/12 bg-black/30 px-1 font-mono text-[6.5px] text-white/70">
                                    {key.code === "Space" ? "Прыжок" : key.code.replace("Key", "")}
                                  </kbd>
                                </div>
                              ))}
                            </div>
                          )}
                          {settingsGroups[group.id] && group.id === "about" && (
                            <div className="space-y-[2px] pb-1 pl-2.5 text-[6.5px] leading-relaxed text-white/50">
                              <p>GAYClient HUD · адаптер 0.3.5</p>
                              <p>React-макет, не сборка ImGui.</p>
                              <p>Настройки не пишутся в профиль.</p>
                            </div>
                          )}
                        </div>
                      ))}
                      <div className="scroll max-h-[150px] overflow-y-auto pr-0.5">
                      <p className="mt-1 rounded border border-amber-300/20 bg-amber-400/8 px-1 py-[3px] text-[6.5px] leading-relaxed text-amber-100/75">
                        Настройки панели действуют в текущем сеансе. Ошибка хранилища: в нативном
                        клиенте профиль не сохраняется.
                      </p>
                      <div className="mt-1 flex gap-1">
                        <button
                          type="button"
                          onClick={onReset}
                          className="flex-1 rounded py-[3px] text-[7px] font-semibold"
                          style={{ border: `1px solid ${rgba(accent, 0.3)}`, color: accent, background: rgba(accent, 0.08) }}
                        >
                          Reset settings
                        </button>
                      </div>
                      <button
                        type="button"
                        onClick={() => onNotify("Отключение оверлея", "В нативном клиенте кнопка отключает HUD до перезапуска игры. Прототип этого не делает.", "warning")}
                        className="mt-1 w-full rounded border border-white/12 bg-white/6 py-[3px] text-[7px] text-white/70"
                      >
                        Disable until game restart
                      </button>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>

            {panels.visuals && (
              <div className="absolute left-[24px] top-[430px]" style={panelStyle}>
                <PanelHead icon={<Sparkles size={9} />} title="Visuals" open={isOpen("visuals")} onToggle={() => toggleCollapse("visuals")} />
                {isOpen("visuals") && (
                  <div className="px-2 py-1.5">
                    <div className="flex items-center gap-1">
                      <MiniToggle checked={visuals.hat.enabled} onChange={(enabled) => onVisualsChange({ hat: { ...visuals.hat, enabled } })} label="China Hat" />
                      <span className="flex-1 text-[7.5px] text-[#d9ecdf]">China Hat</span>
                    </div>
                    <div className="mt-0.5 flex gap-1">
                      <button type="button" onClick={onOpenVisuals} className="flex-1 rounded bg-white/8 py-[3px] text-[7px] text-white/75 hover:bg-white/12">
                        Settings
                      </button>
                    </div>
                    <div className="mt-1.5 flex items-center gap-1 border-t border-white/8 pt-1.5">
                      <MiniToggle checked={visuals.trail.enabled} onChange={(enabled) => onVisualsChange({ trail: { ...visuals.trail, enabled } })} label="Trail" />
                      <span className="flex-1 text-[7.5px] text-[#d9ecdf]">Trail</span>
                    </div>
                    <div className="mt-0.5 flex gap-1">
                      <button type="button" onClick={onOpenVisuals} className="flex-1 rounded bg-white/8 py-[3px] text-[7px] text-white/75 hover:bg-white/12">
                        Settings
                      </button>
                    </div>
                    <button
                      type="button"
                      onClick={onOpenVisuals}
                      className="mt-1 w-full rounded py-[3px] text-[7px] font-semibold"
                      style={{ background: rgba(accent, 0.1), border: `1px solid ${rgba(accent, 0.26)}`, color: accent }}
                    >
                      Options
                    </button>
                    <p className="mt-1 text-[6px] leading-relaxed text-white/40">
                      Отдельный предпросмотр эффектов — во вкладке Visuals.
                    </p>
                  </div>
                )}
              </div>
            )}

            {hud.infoPanel && (
              <div className="absolute left-[24px] top-[548px] w-[150px] rounded-lg border px-2 py-1.5 font-mono text-[6.5px] leading-relaxed" style={{ background: rgba(hud.panelBg, Math.min(0.95, hud.opacity + 0.08)), borderColor: rgba(accent, 0.2), borderRadius: radius, color: "rgba(230,246,235,0.7)" }}>
                <p style={{ color: accent }}>SESSION · РЕАЛЬНЫЕ ЗНАЧЕНИЯ</p>
                <p className="mt-0.5">Uptime {formatUptime(metrics.uptime)}</p>
                <p>Preview {resolutionText} · {metrics.fps} fps</p>
                <p className="text-white/35">Ping нет доступа · игра не запущена</p>
              </div>
            )}

            {widgets.keys && (
              <div className="absolute bottom-1 right-1 grid w-[80px] grid-cols-3 gap-[3px] rounded-lg border p-1.5" style={{ background: rgba(hud.panelBg, Math.min(0.94, hud.opacity + 0.08)), borderColor: rgba(accent, 0.3), borderRadius: radius, boxShadow: glow }}>
                {[
                  { label: "W", active: pressed.has("KeyW"), col: "col-start-2" },
                  { label: "A", active: pressed.has("KeyA"), col: "" },
                  { label: "S", active: pressed.has("KeyS"), col: "" },
                  { label: "D", active: pressed.has("KeyD"), col: "" },
                  { label: "LMB", active: mouse.left, col: "col-span-2" },
                  { label: "RMB", active: mouse.right, col: "" },
                ].map((key) => (
                  <span
                    key={key.label}
                    className={cn("flex h-[17px] items-center justify-center rounded-[3px] border font-mono text-[6.5px] font-bold transition-colors", key.col)}
                    style={{
                      transform: `scale(${hud.keySize})`,
                      background: key.active ? rgba(accent, 0.28) : "rgba(255,255,255,0.03)",
                      borderColor: key.active ? rgba(accent, 0.8) : "rgba(255,255,255,0.12)",
                      color: key.active ? accent : "rgba(230,246,235,0.7)",
                    }}
                  >
                    {key.label}
                  </span>
                ))}
              </div>
            )}

            {moduleNames.length > 0 && widgets.moduleList && (
              <div
                className="absolute w-[132px] rounded-lg border p-1.5"
                style={{ left: `${hud.moduleX}%`, top: `${hud.moduleY}%`, background: rgba(hud.panelBg, hud.moduleOpacity), borderColor: rgba(accent, 0.3), borderRadius: radius, boxShadow: glow }}
              >
                <p className="font-mono text-[7px] font-bold tracking-[0.1em]" style={{ color: textColor }}>MODULES</p>
                {moduleNames.map((name) => (
                  <p key={name} className="mt-0.5 font-mono text-[7px]" style={{ color: textColor, opacity: 0.9 }}>
                    › {name}
                  </p>
                ))}
              </div>
            )}

            <div className="pointer-events-none absolute bottom-1 left-1/2 z-30 -translate-x-1/2 rounded border border-white/10 bg-black/55 px-2 py-1 font-mono text-[6.5px] text-white/55 backdrop-blur">
              редактор открыт · остальной HUD скрыт · клик по фону = CPS
            </div>
          </div>
        </div>
      ) : (
        <>
          {/* ============ Compact HUD card (HUD widgets) ============ */}
          <div
            className="hud-card"
            style={{
              ...anchor,
              "--hud-scale": hud.scale,
              "--hud-color": textColor,
              "--hud-opacity": hud.opacity,
              backgroundColor: rgba(hud.panelBg, hud.opacity),
              borderColor: rgba(accent, 0.32),
              borderRadius: radius,
              boxShadow: glow,
              filter: `brightness(${hud.brightness})`,
              padding: hud.padding,
              display: "flex",
              flexDirection: "column",
              gap: hud.gap,
            } as React.CSSProperties}
            onPointerDown={(event) => startDrag(event, "hud", hud.x, hud.y)}
            onClick={(event) => event.stopPropagation()}
            title="Перетащите HUD, чтобы изменить позицию"
          >
            {enabledWidgets(hud).length === 0 && (
              <p className="hud-row" style={{ opacity: 0.55 }}>все виджеты выключены</p>
            )}
            {widgets.fps && (
              <HudLine icon={<BarChart3 size={12 * hud.scale} />} label="FPS:" value={String(metrics.fps)} title="Частота кадров этого превью, не игры" />
            )}
            {widgets.cps && (
              <HudLine icon={<MousePointer2 size={12 * hud.scale} />} label="CPS:" value={String(cps)} title="Клики по превью за последнюю секунду" />
            )}
            {widgets.clock && (
              <HudLine icon={<Clock3 size={12 * hud.scale} />} label="" value={timeLabel} title="Системное время" />
            )}
            {widgets.ping && (
              <HudLine icon={<WifiOff size={12 * hud.scale} />} label="Ping:" value="—" title="Игра не запущена — пинг недоступен" muted />
            )}
            {widgets.coordinates && (
              <HudLine icon={<Crosshair size={12 * hud.scale} />} label="XYZ:" value="— / — / —" title="Нет доступа к ядру игры" muted />
            )}
            {widgets.performance && (
              <>
                <HudLine icon={<Cpu size={12 * hud.scale} />} label="CPU:" value="—" title="Загрузка CPU игры недоступна" muted />
                <HudLine icon={<MemoryStick size={12 * hud.scale} />} label="RAM:" value={memoryText} title="Память вкладки превью, не игры" muted={memory === null} />
              </>
            )}
            {widgets.resolution && (
              <HudLine icon={<Maximize2 size={12 * hud.scale} />} label="Res:" value={resolutionText} title="Размер превью в пикселях" />
            )}
            {widgets.keys && (
              <div className="mt-0.5 flex flex-wrap gap-1" style={{ maxWidth: 130 * hud.scale }}>
                {[...hudKeys, { code: "Space", label: "SP" }, { code: "ShiftLeft", label: "SH" }].map((key) => (
                  <span
                    key={key.code}
                    className="rounded-[3px] border px-1 py-px font-minecraft leading-none transition-all"
                    style={{
                      fontSize: Math.max(6, 7 * hud.scale),
                      borderColor: pressed.has(key.code) ? rgba(accent, 0.9) : "rgba(255,255,255,0.22)",
                      background: pressed.has(key.code) ? rgba(accent, 0.28) : "rgba(0,0,0,0.3)",
                      color: pressed.has(key.code) ? textColor : "rgba(255,255,255,0.65)",
                    }}
                  >
                    {key.label}
                  </span>
                ))}
              </div>
            )}
          </div>

          {widgets.watermark && (
            <div
              className="pointer-events-none absolute left-3 top-12 z-20 flex items-center gap-1.5 rounded-md border px-1.5 py-1"
              style={{ background: rgba(hud.panelBg, hud.opacity), borderColor: rgba(accent, 0.3), borderRadius: radius, color: textColor }}
            >
              <Leaf size={9} style={{ color: accent }} />
              <span className="font-mono text-[7px] font-bold">GAYCLIENT</span>
              <span className="font-mono text-[6.5px] opacity-60">HUD · сессия</span>
            </div>
          )}

          {widgets.moduleList && (
            <div
              className="hud-card"
              style={{
                left: `${hud.moduleX}%`,
                top: `${hud.moduleY}%`,
                backgroundColor: rgba(hud.panelBg, hud.moduleOpacity),
                borderColor: rgba(accent, 0.3),
                borderRadius: radius,
                padding: hud.padding,
                boxShadow: glow,
              }}
              onPointerDown={(event) => startDrag(event, "modules", hud.moduleX, hud.moduleY)}
              onClick={(event) => event.stopPropagation()}
            >
              <p className="hud-label mb-1 font-bold tracking-[0.12em]" style={{ color: accent }}>MODULES</p>
              {moduleNames.length === 0 ? (
                <p className="hud-row" style={{ opacity: 0.5, fontSize: 8 }}>No active modules</p>
              ) : (
                moduleNames.slice(0, 8).map((name) => (
                  <p key={name} className="hud-row" style={{ fontSize: 9, color: textColor }}>
                    <span style={{ color: accent }}>›</span> {name}
                  </p>
                ))
              )}
            </div>
          )}

          {widgets.keys && (
            <div
              className="pointer-events-none absolute right-3 bottom-3 z-20 grid w-[92px] grid-cols-3 gap-[3px] rounded-lg border p-1.5"
              style={{ background: rgba(hud.panelBg, hud.opacity), borderColor: rgba(accent, 0.3), borderRadius: radius }}
            >
              {[
                { label: "W", active: pressed.has("KeyW"), col: "col-start-2" },
                { label: "A", active: pressed.has("KeyA"), col: "" },
                { label: "S", active: pressed.has("KeyS"), col: "" },
                { label: "D", active: pressed.has("KeyD"), col: "" },
                { label: "LMB", active: mouse.left, col: "col-span-2" },
                { label: "RMB", active: mouse.right, col: "" },
              ].map((key) => (
                <span
                  key={key.label}
                  className={cn("flex h-[18px] items-center justify-center rounded-[3px] border font-mono text-[7px] font-bold", key.col)}
                  style={{
                    transform: `scale(${hud.keySize})`,
                    borderColor: key.active ? rgba(accent, 0.85) : "rgba(255,255,255,0.14)",
                    background: key.active ? rgba(accent, 0.24) : "rgba(255,255,255,0.03)",
                    color: key.active ? textColor : "rgba(235,250,240,0.75)",
                  }}
                >
                  {key.label}
                </span>
              ))}
            </div>
          )}

          {widgets.coordinates && (
            <div className="pointer-events-none absolute bottom-3 left-3 z-20 rounded-md border px-2 py-1 font-minecraft text-[8px] leading-relaxed" style={{ background: rgba(hud.panelBg, hud.opacity), borderColor: rgba(accent, 0.26), borderRadius: radius, color: textColor }}>
              <p>X: — &nbsp; Y: — &nbsp; Z: —</p>
              <p style={{ opacity: 0.55 }}>ядро не подключено</p>
            </div>
          )}

          <button
            type="button"
            onClick={(event) => {
              event.stopPropagation();
              onChange({ showEditorPanels: true });
            }}
            className="absolute bottom-3 left-1/2 z-30 flex -translate-x-1/2 items-center gap-1.5 rounded-lg border border-[rgba(var(--acc-rgb),0.3)] bg-[#07130c]/85 px-2.5 py-1.5 font-mono text-[7.5px] text-[#c9f7d4] backdrop-blur transition-colors hover:bg-[#0d2013]"
          >
            <Settings2 size={9} />
            Открыть панели редактора
          </button>
        </>
      )}

      {pop && (
        <span
          className="pointer-events-none absolute z-40 font-minecraft text-[10px] font-bold text-[#b9ff62]"
          style={{ left: pop.x, top: pop.y, animation: "cps-pop 0.6s ease-out forwards" }}
        >
          +1
        </span>
      )}
    </div>
  );
}

function enabledWidgets(hud: HudSettings) {
  return (Object.keys(hud.widgets ?? {}) as WidgetKey[]).filter((key) => hud.widgets?.[key]);
}

function HudLine({ icon, label, value, title, muted }: { icon: React.ReactNode; label: string; value: string; title?: string; muted?: boolean }) {
  return (
    <div className="hud-row" title={title} style={{ cursor: "help" }}>
      <span className="hud-icon">{icon}</span>
      {label && <span className="hud-label">{label}</span>}
      <span className="ml-auto pl-2 font-bold tracking-wide" style={{ opacity: muted ? 0.45 : 1 }}>
        {value}
      </span>
    </div>
  );
}
