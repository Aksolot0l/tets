import {
  AlertTriangle,
  ArrowRight,
  BadgeCheck,
  BarChart3,
  Boxes,
  Check,
  Clock3,
  Copy,
  Cpu,
  Download,
  FileJson,
  Gamepad2,
  Gauge,
  Heart,
  Info,
  Layers,
  LayoutDashboard,
  MonitorCog,
  MousePointer2,
  Palette,
  RefreshCcw,
  RotateCcw,
  Save,
  ShieldAlert,
  Sparkles,
  Triangle,
  Volume2,
  VolumeX,
  WandSparkles,
} from "lucide-react";
import { useMemo, useState } from "react";
import { accentThemes, APP_VERSION, hotkeys } from "../lib/data";
import { mascot } from "../lib/images";
import type {
  GameModule,
  HudSettings,
  InterfaceSettings,
  Section,
  SoundSettings,
  VisualSettings,
} from "../lib/types";
import { cn } from "../utils/cn";
import { VisualsPanel } from "./HudPanel";
import { SchematicStage } from "./SchematicStage";
import {
  Dropdown,
  Modal,
  PageTitle,
  SectionCard,
  Slider,
  ToggleRow,
} from "./ui";

const positionLabel: Record<HudSettings["position"], string> = {
  "top-left": "сверху слева",
  "top-right": "сверху справа",
  "bottom-left": "снизу слева",
  "bottom-right": "снизу справа",
  custom: "своя позиция",
};

export function HomeSection({
  hud,
  visuals,
  modules,
  onOpenHud,
  onOpenGraphics,
  onOpenProfiles,
  onNotify,
}: {
  hud: HudSettings;
  visuals: VisualSettings;
  modules: GameModule[];
  onOpenHud: () => void;
  onOpenGraphics: () => void;
  onOpenProfiles: () => void;
  onNotify: (title: string, description?: string, tone?: "success" | "info" | "warning" | "error") => void;
}) {
  const enabledWidgets = Object.entries(hud.widgets).filter(([, value]) => value).length;
  const enabledModules = modules.filter((module) => module.enabled).length;
  const activeNames = [
    ...modules.filter((module) => module.enabled).map((module) => module.name),
    ...(visuals.hat.enabled ? ["China Hat"] : []),
    ...(visuals.trail.enabled ? ["Trail"] : []),
  ];

  return (
    <div className="animate-fade-up space-y-3">
      <PageTitle
        eyebrow="GAYCLIENT · HUD EDITOR"
        title="Всё под контролем"
        description="Живой редактор игрового HUD: виджеты, масштаб и позиция меняются сразу в превью. Настройки старых виджетов ядра не затрагиваются."
        action={
          <button type="button" onClick={onOpenHud} className="btn-solid">
            <SlidersIcon />
            Открыть редактор HUD
          </button>
        }
      />

      <div className="panel relative overflow-hidden p-4 sm:p-5">
        <div className="pointer-events-none absolute -top-24 right-[-40px] h-64 w-64 rounded-full bg-[rgba(var(--acc-rgb),0.15)] blur-3xl" />
        <div className="relative flex flex-wrap items-center gap-5">
          <div className="relative flex h-24 w-24 shrink-0 items-center justify-center">
            <div className="absolute inset-2 rounded-full bg-[rgba(var(--acc-rgb),0.16)] blur-xl" />
            <img src={mascot} alt="Маскот GAYCLIENT" className="mascot-glow mascot-fade relative h-28 w-28 object-contain" />
          </div>
          <div className="min-w-[220px] flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="chip chip-accent">
                <span className="h-1 w-1 rounded-full bg-[var(--acc)]" />
                редактор готов
              </span>
              <span className="chip">HUD v{APP_VERSION}</span>
              <span className="chip">сессионные настройки</span>
            </div>
            <h2 className="mt-2 font-display text-[20px] leading-snug text-[#f1fff4]">
              {hud.widgets.fps || hud.widgets.cps ? "HUD активен и отрисовывается" : "Все основные виджеты выключены"}
            </h2>
            <p className="mt-1 max-w-xl text-[11px] leading-relaxed text-[#86a392]">
              Позиция: <span className="text-[#cfe8d6]">{positionLabel[hud.position]}</span> · масштаб{" "}
              <span className="font-mono text-[#cfe8d6]">{hud.scale.toFixed(2)}x</span> · прозрачность{" "}
              <span className="font-mono text-[#cfe8d6]">{Math.round(hud.opacity * 100)}%</span>
            </p>
            <div className="mt-3 flex flex-wrap gap-2">
              <button type="button" onClick={onOpenGraphics} className="btn-ghost">
                <Sparkles size={12} />
                Visuals
              </button>
              <button type="button" onClick={onOpenProfiles} className="btn-ghost">
                <Save size={12} />
                Профили HUD
              </button>
              <button
                type="button"
                onClick={() => onNotify("Горячие клавиши", "Shift открывает меню в игре; в редакторе — 1…7 для разделов.", "info")}
                className="btn-ghost"
              >
                <Info size={12} />
                Как это работает
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="grid gap-2.5 sm:grid-cols-2 xl:grid-cols-4">
        {[
          { label: "Виджеты", value: `${enabledWidgets} / 8`, hint: "включено в HUD", icon: LayoutDashboard },
          { label: "Модули", value: String(enabledModules), hint: "активны в списке", icon: Boxes },
          { label: "Масштаб", value: `${hud.scale.toFixed(2)}x`, hint: "диапазон 0.70–1.60", icon: Gauge },
          {
            label: "Визуалы",
            value: visuals.hat.enabled || visuals.trail.enabled ? "Активны" : "Выкл.",
            hint: "China Hat / Trail",
            icon: Triangle,
          },
        ].map((metric) => {
          const Icon = metric.icon;
          return (
            <div key={metric.label} className="panel flex items-center gap-3 p-3.5">
              <span className="icon-tile h-9 w-9">
                <Icon size={15} />
              </span>
              <div>
                <p className="text-[8px] font-extrabold tracking-[0.16em] text-[#688574] uppercase">{metric.label}</p>
                <p className="mt-1 font-display text-[15px] leading-none text-[#f0fff4]">{metric.value}</p>
                <p className="mt-1 text-[9px] text-[#607d6b]">{metric.hint}</p>
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid gap-3 xl:grid-cols-[minmax(0,1.5fr)_minmax(0,1fr)]">
        <SectionCard title="Что сейчас на экране" icon={<Sparkles size={12} className="text-[var(--acc)]" />}>
          <div className="flex flex-wrap gap-1.5 py-1">
            {Object.entries(hud.widgets)
              .filter(([, enabled]) => enabled)
              .map(([key]) => (
                <span key={key} className="chip chip-accent">
                  <span className="h-1 w-1 rounded-full bg-[var(--acc)]" />
                  {key === "fps" ? "FPS" : key === "cps" ? "CPS" : key === "clock" ? "Clock" : key === "keys" ? "Keys" : key === "watermark" ? "Watermark" : key === "coordinates" ? "Coordinates" : key === "performance" ? "CPU / RAM" : "Modules"}
                </span>
              ))}
            {enabledWidgets === 0 && <span className="text-[10px] text-[#708d7a]">Нет включённых виджетов.</span>}
          </div>
          <div className="mt-2 flex flex-wrap gap-1.5 border-t border-white/5 pt-2">
            <span className="text-[8.5px] font-bold tracking-wider text-[#5f7d69] uppercase">Модули:</span>
            {activeNames.length ? (
              activeNames.map((name) => (
                <span key={name} className="chip">
                  {name}
                </span>
              ))
            ) : (
              <span className="text-[9px] text-[#607d6b]">No active modules</span>
            )}
          </div>
          <p className="mt-2 flex items-start gap-1.5 border-t border-white/5 pt-2 text-[8.5px] leading-relaxed text-[#5f7d69]">
            <ShieldAlert size={9} className="mt-px shrink-0" />
            Плашка MODULES может дублировать старый Active Modules. Стиль старых виджетов не
            переопределяется.
          </p>
        </SectionCard>

        <div className="panel flex flex-col justify-between p-4">
          <div>
            <p className="text-[9px] font-extrabold tracking-[0.18em] text-[var(--acc)] uppercase">Быстрый старт</p>
            <h3 className="mt-1 font-display text-[14px] text-[#effff3]">Три шага до нужного HUD</h3>
            <ol className="mt-2.5 space-y-2">
              {[
                "Включите FPS, CPS и часы.",
                "Перетащите HUD в превью.",
                "Сохраните профиль HUD.",
              ].map((step, index) => (
                <li key={step} className="flex items-center gap-2 text-[10px] text-[#9bbaa5]">
                  <span className="flex h-4 w-4 items-center justify-center rounded-full border border-[rgba(var(--acc-rgb),0.3)] bg-[rgba(var(--acc-rgb),0.08)] font-mono text-[8px] text-[#c8f5d2]">
                    {index + 1}
                  </span>
                  {step}
                </li>
              ))}
            </ol>
          </div>
          <button type="button" onClick={onOpenHud} className="btn-primary mt-3 w-full">
            Перейти к настройке
            <ArrowRight size={13} />
          </button>
        </div>
      </div>
    </div>
  );
}

function SlidersIcon() {
  return <LayoutDashboard size={14} />;
}

export function InterfaceSection({
  settings,
  onChange,
  hud,
  onHudChange,
}: {
  settings: InterfaceSettings;
  onChange: (patch: Partial<InterfaceSettings>) => void;
  hud: HudSettings;
  onHudChange: (patch: Partial<HudSettings>) => void;
}) {
  return (
    <div className="animate-fade-up space-y-3">
      <PageTitle
        eyebrow="Оформление"
        title="Интерфейс лаунчера"
        description="Акцентная тема, плотность и анимации. Тема влияет и на цвет иконок в игровом превью."
      />

      <SectionCard title="Акцентная тема" icon={<Palette size={12} className="text-[var(--acc)]" />}>
        <div className="grid gap-2 py-1 sm:grid-cols-2">
          {accentThemes.map((theme) => {
            const active = settings.accent === theme.id;
            return (
              <button
                key={theme.id}
                type="button"
                onClick={() => onChange({ accent: theme.id })}
                aria-pressed={active}
                className={cn(
                  "relative flex items-center gap-2.5 rounded-lg border p-2.5 text-left transition-colors",
                  active
                    ? "border-[rgba(var(--acc-rgb),0.5)] bg-[rgba(var(--acc-rgb),0.08)]"
                    : "border-white/8 bg-black/20 hover:border-white/16 hover:bg-white/4",
                )}
              >
                <span
                  className="h-8 w-8 shrink-0 rounded-md border border-white/15"
                  style={{ background: theme.swatch }}
                />
                <span className="min-w-0 flex-1">
                  <span className="block text-[11px] font-bold text-[#e6f7ea]">{theme.name}</span>
                  <span className="mt-0.5 block truncate text-[8.5px] text-[#6d8b78]">{theme.description}</span>
                </span>
                {active && (
                  <span className="flex h-4 w-4 items-center justify-center rounded-full bg-[var(--acc)] text-[#062410]">
                    <Check size={10} strokeWidth={3} />
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </SectionCard>

      <div className="grid gap-3 xl:grid-cols-2">
        <SectionCard title="Плотность и поведение" icon={<MonitorCog size={12} className="text-[var(--acc)]" />}>
          <ToggleRow
            icon={<Sparkles size={12} />}
            title="Анимации интерфейса"
            hint="Маскот, свечения и плавные переходы"
            checked={settings.animations}
            onChange={(animations) => onChange({ animations })}
          />
          <ToggleRow
            icon={<WandSparkles size={12} />}
            title="Фоновая аврора"
            hint="Размытые зелёные пятна за окном"
            checked={settings.glow}
            onChange={(glow) => onChange({ glow })}
          />
          <ToggleRow
            icon={<MousePointer2 size={12} />}
            title="Сердца и хотбар в превью"
            hint="Показывать элементы игрового интерфейса"
            checked={hud.showHearts && hud.showHotbar}
            onChange={(value) => onHudChange({ showHearts: value, showHotbar: value })}
          />
          <div className="flex items-center justify-between gap-3 border-t border-white/5 py-2">
            <div>
              <p className="text-[11px] font-semibold text-[#d6ecdd]">Плотность</p>
              <p className="mt-0.5 text-[9px] text-[#6c8a78]">Отступы в панелях редактора</p>
            </div>
            <div className="w-[130px]">
              <Dropdown
                label="Плотность"
                value={settings.density}
                options={[
                  { id: "comfortable", label: "Комфортная" },
                  { id: "compact", label: "Компактная" },
                ]}
                onChange={(value) => onChange({ density: value as InterfaceSettings["density"] })}
              />
            </div>
          </div>
        </SectionCard>

        <SectionCard title="Масштаб интерфейса" icon={<Gauge size={12} className="text-[var(--acc)]" />}>
          <Slider
            label="UI scale"
            icon={<Gauge size={12} />}
            value={settings.uiScale}
            min={0.85}
            max={1.15}
            step={0.01}
            format={(value) => `${Math.round(value * 100)}%`}
            onChange={(uiScale) => onChange({ uiScale })}
            accent
          />
          <div className="mt-1 flex items-center gap-2 rounded-lg border border-white/7 bg-black/25 p-2">
            <img src={mascot} alt="" className="mascot-fade h-9 w-9 object-contain" />
            <div className="min-w-0 flex-1">
              <p className="font-pixel text-[7px] text-[#edfff1]">GAYCLIENT</p>
              <div className="mt-1 h-1 rounded-full bg-white/8">
                <div className="h-full w-2/3 rounded-full bg-[var(--acc)]" />
              </div>
            </div>
            <span className="chip chip-accent">live</span>
          </div>
          <p className="flex items-start gap-1.5 pt-2 text-[8.5px] leading-relaxed text-[#5f7d69]">
            <Info size={9} className="mt-px shrink-0" />
            Здесь UI scale — предпросмотр интерфейса лаунчера. HUD в игре масштабируется отдельно.
          </p>
        </SectionCard>
      </div>
    </div>
  );
}

export function GraphicsSection({
  visuals,
  onChange,
  hud,
}: {
  visuals: VisualSettings;
  onChange: (patch: Partial<VisualSettings>) => void;
  hud: HudSettings;
}) {
  return (
    <div className="animate-fade-up space-y-3">
      <PageTitle
        eyebrow="Visuals · experimental"
        title="Графика и 3D-эффекты"
        description="China Hat и Trail повторяют параметры из HUD_ALL_IN_ONE: контур, заливка, цвет, покачивание и прозрачность. Окклюзия и поведение материала зависят от игры."
        action={
          <span className="chip border-amber-300/25 bg-amber-400/8 text-amber-200">
            <AlertTriangle size={10} />
            не проверено в игре
          </span>
        }
      />
      <div className="grid gap-3 xl:grid-cols-[minmax(0,1.15fr)_minmax(0,0.85fr)]">
        <VisualsPanel visuals={visuals} onChange={onChange} />
        <div className="space-y-3">
          <div className="panel p-3">
            <div className="flex items-center justify-between gap-2 pb-2">
              <div>
                <p className="text-[10.5px] font-bold text-[#e4f6e9]">Предпросмотр эффектов</p>
                <p className="mt-0.5 text-[8px] text-[#6d8b78]">Независимая схема · не игровая камера</p>
              </div>
              <span className="chip !text-[8px]">demo avatar</span>
            </div>
            <SchematicStage visuals={visuals} />
            <div className="mt-2 flex flex-wrap items-center gap-1">
              <span className={cn("chip !text-[8px]", visuals.hat.enabled ? "chip-accent" : "")}>
                Hat {visuals.hat.enabled ? "вкл." : "выкл."}
              </span>
              <span className={cn("chip !text-[8px]", visuals.trail.enabled ? "chip-accent" : "")}>
                Trail {visuals.trail.enabled ? "вкл." : "выкл."}
              </span>
              <span className="chip !text-[8px]">opacity {visuals.hat.opacity.toFixed(2)}</span>
            </div>
            <p className="mt-1.5 flex items-start gap-1.5 border-t border-white/5 pt-1.5 text-[8px] leading-relaxed text-[#5f7d69]">
              <Info size={9} className="mt-px shrink-0" />
              Скин, путь и материал условные. В игре действуют depth-test и occlusion;
              реальный результат зависит от шейдера Minecraft.
            </p>
          </div>
          <SectionCard title="Связь с HUD" icon={<Layers size={12} className="text-[var(--acc)]" />}>
            <div className="py-1 text-[10px] leading-relaxed text-[#8fab99]">
              <p className="flex items-center justify-between gap-2 border-b border-white/5 py-1.5">
                <span>Плашка MODULES</span>
                <span className={cn("font-mono text-[9px]", hud.widgets.moduleList ? "text-[var(--acc)]" : "text-[#607d6b]")}>
                  {hud.widgets.moduleList ? "включена" : "выключена"}
                </span>
              </p>
              <p className="flex items-center justify-between gap-2 border-b border-white/5 py-1.5">
                <span>China Hat в списке</span>
                <span className={cn("font-mono text-[9px]", visuals.hat.enabled ? "text-[var(--acc)]" : "text-[#607d6b]")}>
                  {visuals.hat.enabled ? "да" : "нет"}
                </span>
              </p>
              <p className="flex items-center justify-between gap-2 py-1.5">
                <span>Trail в списке</span>
                <span className={cn("font-mono text-[9px]", visuals.trail.enabled ? "text-[var(--acc)]" : "text-[#607d6b]")}>
                  {visuals.trail.enabled ? "да" : "нет"}
                </span>
              </p>
            </div>
            <p className="mt-1 flex items-start gap-1.5 border-t border-white/5 pt-2 text-[8.5px] leading-relaxed text-[#5f7d69]">
              <Info size={9} className="mt-px shrink-0" />
              В превью эффекты показаны схематично, чтобы видеть включение. Реальный рендер
              выполняется клиентом и может отличаться.
            </p>
          </SectionCard>

          <SectionCard title="Ограничения" icon={<ShieldAlert size={12} className="text-amber-300/80" />}>
            <ul className="space-y-1.5 py-1 text-[9px] leading-relaxed text-[#86a292]">
              <li>• Прозрачность зависит от материала и blending игры.</li>
              <li>• Vertex gradient может не примениться или стать белым.</li>
              <li>• Эффекты могут просвечивать сквозь блоки — это не исправлено.</li>
              <li>• Значения DSV/depth — диагностика, а не гарантия корректной глубины.</li>
            </ul>
          </SectionCard>
        </div>
      </div>
    </div>
  );
}

export function SoundSection({
  sound,
  onChange,
}: {
  sound: SoundSettings;
  onChange: (patch: Partial<SoundSettings>) => void;
}) {
  const playTest = () => {
    try {
      const Ctx = window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const context = new Ctx();
      const oscillator = context.createOscillator();
      const gain = context.createGain();
      oscillator.type = "sine";
      oscillator.frequency.value = 660;
      gain.gain.value = sound.muted ? 0 : (sound.master / 100) * (sound.effects / 100) * 0.14;
      oscillator.connect(gain);
      gain.connect(context.destination);
      oscillator.start();
      oscillator.stop(context.currentTime + 0.12);
      oscillator.onended = () => context.close();
    } catch {
      /* audio may be unavailable */
    }
  };

  return (
    <div className="animate-fade-up space-y-3">
      <PageTitle
        eyebrow="Звук"
        title="Звук интерфейса"
        description="Громкость лаунчера. Тестовый сигнал проверяет выбранный уровень; игровые звуки клиента эти настройки не меняют."
      />
      <div className="grid gap-3 xl:grid-cols-[minmax(0,1.2fr)_minmax(0,0.8fr)]">
        <SectionCard
          title="Микшер"
          icon={<Volume2 size={12} className="text-[var(--acc)]" />}
          action={
            <button
              type="button"
              onClick={() => onChange({ muted: !sound.muted })}
              className={cn("btn-ghost !h-7 !px-2", sound.muted && "!border-amber-300/30 !text-amber-200")}
              aria-pressed={sound.muted}
            >
              {sound.muted ? <VolumeX size={12} /> : <Volume2 size={12} />}
              {sound.muted ? "Выключен" : "Включён"}
            </button>
          }
        >
          <Slider
            label="Общая громкость"
            icon={<Volume2 size={12} />}
            value={sound.master}
            min={0}
            max={100}
            step={1}
            format={(value) => `${value}%`}
            onChange={(master) => onChange({ master })}
            accent
          />
          <Slider
            label="Звуки интерфейса"
            icon={<MousePointer2 size={12} />}
            value={sound.interface}
            min={0}
            max={100}
            step={1}
            format={(value) => `${value}%`}
            onChange={(interfaceValue) => onChange({ interface: interfaceValue })}
          />
          <Slider
            label="Эффекты"
            icon={<Sparkles size={12} />}
            value={sound.effects}
            min={0}
            max={100}
            step={1}
            format={(value) => `${value}%`}
            onChange={(effects) => onChange({ effects })}
          />
          <div className="mt-2 flex items-center justify-between gap-2 border-t border-white/5 pt-2">
            <p className="text-[8.5px] leading-relaxed text-[#5f7d69]">Проверить выбранный уровень</p>
            <button type="button" onClick={playTest} className="btn-ghost !h-7 !px-2.5">
              <Gauge size={11} />
              Тест
            </button>
          </div>
        </SectionCard>

        <div className="panel flex flex-col items-center justify-center overflow-hidden p-5 text-center">
          <div className="relative flex h-24 w-24 items-center justify-center rounded-full border border-[rgba(var(--acc-rgb),0.22)] bg-[rgba(var(--acc-rgb),0.06)]">
            <span className="absolute inset-0 rounded-full border border-[rgba(var(--acc-rgb),0.12)]" />
            <img src={mascot} alt="" className="mascot-fade h-20 w-20 object-contain" />
          </div>
          <p className="mt-3 text-[11px] font-bold text-[#dff4e5]">
            {sound.muted ? "Интерфейс без звука" : `Громкость ${sound.master}%`}
          </p>
          <p className="mt-1 max-w-[220px] text-[9px] leading-relaxed text-[#6f8d7a]">
            Маскот-страж следит за микшером. Настройки сохраняются локально.
          </p>
        </div>
      </div>
    </div>
  );
}

export function ControlsSection({
  hud,
  onHudChange,
  modules,
}: {
  hud: HudSettings;
  onHudChange: (patch: Partial<HudSettings>) => void;
  modules: GameModule[];
}) {
  const initialBinds = useMemo(() => {
    const map: Record<string, string> = {};
    hotkeys.forEach((item, index) => {
      map[`global-${index}`] = item.keys.join(" + ");
    });
    modules.forEach((module) => {
      map[`module-${module.id}`] = module.bind;
    });
    return map;
  }, [modules]);

  const [binds, setBinds] = useState(initialBinds);
  const [capturing, setCapturing] = useState<string | null>(null);

  const startCapture = (id: string) => {
    setCapturing(id);
    const onKey = (event: KeyboardEvent) => {
      event.preventDefault();
      const key = event.key === " " ? "Space" : event.key.length === 1 ? event.key.toUpperCase() : event.key;
      if (key === "Escape") {
        setCapturing(null);
      } else {
        setBinds((current) => ({ ...current, [id]: key }));
        setCapturing(null);
      }
      window.removeEventListener("keydown", onKey, true);
    };
    window.addEventListener("keydown", onKey, true);
  };

  const rows = [
    ...hotkeys.map((item, index) => ({ id: `global-${index}`, label: item.label, bind: binds[`global-${index}`] })),
    ...modules.map((module) => ({ id: `module-${module.id}`, label: `Модуль · ${module.name}`, bind: binds[`module-${module.id}`] })),
  ];

  return (
    <div className="animate-fade-up space-y-3">
      <PageTitle
        eyebrow="Управление"
        title="Клавиши и мышь"
        description="Нажмите «Изменить» и клавишу, чтобы переназначить действие. Escape отменяет захват. Колесо мыши не затрагивается."
        action={
          <button type="button" onClick={() => setBinds(initialBinds)} className="btn-ghost">
            <RotateCcw size={12} />
            Сбросить клавиши
          </button>
        }
      />
      <div className="grid gap-3 xl:grid-cols-[minmax(0,1.3fr)_minmax(0,0.7fr)]">
        <div className="panel overflow-hidden">
          <div className="panel-head !py-2.5">
            <p className="flex items-center gap-2 text-[10.5px] font-bold text-[#ddeee3]">
              <Gamepad2 size={13} className="text-[var(--acc)]" />
              Назначения
            </p>
            <span className="chip">нажмите, чтобы изменить</span>
          </div>
          <div className="scroll max-h-[440px] divide-y divide-white/5 overflow-y-auto">
            {rows.map((row) => (
              <div key={row.id} className="flex items-center gap-2 px-3 py-2">
                <span className="min-w-0 flex-1 truncate text-[10.5px] text-[#aac6b3]">{row.label}</span>
                <kbd className="rounded-md border border-white/10 bg-black/30 px-2 py-1 font-mono text-[9px] font-bold text-[#d9ecdf]">
                  {capturing === row.id ? "нажмите…" : row.bind}
                </kbd>
                <button
                  type="button"
                  onClick={() => startCapture(row.id)}
                  className={cn("btn-ghost !h-7 !px-2 !text-[9px]", capturing === row.id && "!border-[var(--acc)] !text-[var(--acc)]")}
                >
                  {capturing === row.id ? "..." : "Изменить"}
                </button>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-3">
          <SectionCard title="Поведение HUD" icon={<LayoutDashboard size={12} className="text-[var(--acc)]" />}>
            <ToggleRow
              icon={<Layers size={12} />}
              title="Показывать плашку MODULES"
              hint="Дубликат старого Active Modules"
              checked={hud.widgets.moduleList}
              onChange={(value) => onHudChange({ widgets: { ...hud.widgets, moduleList: value } })}
            />
            <ToggleRow
              icon={<MousePointer2 size={12} />}
              title="Клик по превью считает CPS"
              hint="Демонстрация виджета кликов"
              checked={hud.widgets.cps}
              onChange={(value) => onHudChange({ widgets: { ...hud.widgets, cps: value } })}
            />
            <div className="mt-1 flex items-start gap-1.5 rounded-md border border-amber-300/20 bg-amber-400/[0.05] px-2 py-1.5 text-[8.5px] leading-relaxed text-amber-200/80">
              <ShieldAlert size={10} className="mt-px shrink-0" />
              Delete отключает оверлей в игре до перезапуска; DLL при этом остаётся загруженной.
            </div>
          </SectionCard>
          <SectionCard title="Мышь" icon={<MousePointer2 size={12} className="text-[var(--acc)]" />}>
            <p className="py-1 text-[9px] leading-relaxed text-[#86a292]">
              Захват указателя и мост колеса относятся к нативной части и здесь не меняются.
              Перетаскивание HUD в превью работает обычным указателем.
            </p>
          </SectionCard>
        </div>
      </div>
    </div>
  );
}

export function OtherSection({
  hud,
  visuals,
  onExport,
  onResetAll,
  onNotify,
}: {
  hud: HudSettings;
  visuals: VisualSettings;
  onExport: () => void;
  onResetAll: () => void;
  onNotify: (title: string, description?: string, tone?: "success" | "info" | "warning" | "error") => void;
}) {
  const [resetOpen, setResetOpen] = useState(false);
  const payload = useMemo(
    () => JSON.stringify({ hud, visuals, version: APP_VERSION }, null, 2),
    [hud, visuals],
  );

  return (
    <div className="animate-fade-up space-y-3">
      <PageTitle
        eyebrow="Прочее"
        title="О клиенте и данных"
        description="Локальный редактор HUD. Здесь можно выгрузить конфигурацию, скопировать её и вернуть значения по умолчанию."
      />
      <div className="grid gap-3 xl:grid-cols-2">
        <SectionCard title="Конфигурация" icon={<FileJson size={12} className="text-[var(--acc)]" />}>
          <div className="flex flex-wrap gap-2 py-1.5">
            <button type="button" onClick={onExport} className="btn-primary !h-9">
              <Download size={13} />
              Скачать JSON
            </button>
            <button
              type="button"
              onClick={() => {
                navigator.clipboard
                  ?.writeText(payload)
                  .then(() => onNotify("Конфигурация скопирована", "JSON HUD и Visuals в буфере обмена.", "success"))
                  .catch(() => onNotify("Не удалось скопировать", "Буфер обмена недоступен.", "warning"));
              }}
              className="btn-ghost !h-9"
            >
              <Copy size={12} />
              Копировать
            </button>
          </div>
          <pre className="scroll mt-1 max-h-[180px] overflow-auto rounded-lg border border-white/7 bg-black/35 p-2 font-mono text-[8px] leading-relaxed text-[#7fa58c]">
            {payload}
          </pre>
        </SectionCard>

        <div className="space-y-3">
          <SectionCard title="О GAYCLIENT" icon={<BadgeCheck size={12} className="text-[var(--acc)]" />}>
            <div className="flex items-start gap-3 py-1.5">
              <img src={mascot} alt="Маскот GAYCLIENT" className="mascot-fade h-14 w-14 object-contain" />
              <div>
                <p className="font-pixel text-[9px] text-[#eefff2]">GAYCLIENT</p>
                <p className="mt-1 text-[9px] leading-relaxed text-[#7f9d89]">
                  HUD visual guide + module list editor. Версия {APP_VERSION}. Прототип интерфейса на
                  React: реальная отрисовка ImGui и DLL находятся в нативном клиенте Windows.
                </p>
                <div className="mt-1.5 flex flex-wrap gap-1">
                  <span className="chip !text-[8px]">commit f6aed30</span>
                  <span className="chip !text-[8px]">сессионно</span>
                </div>
              </div>
            </div>
          </SectionCard>

          <SectionCard title="Сброс" icon={<RefreshCcw size={12} className="text-amber-300/80" />}>
            <p className="py-1 text-[9px] leading-relaxed text-[#86a292]">
              Вернуть HUD и Visuals к значениям по умолчанию. Профили HUD не удаляются.
            </p>
            <button type="button" onClick={() => setResetOpen(true)} className="btn-ghost !h-8 !border-red-400/25 !text-red-200">
              <AlertTriangle size={11} />
              Сбросить всё
            </button>
          </SectionCard>
        </div>
      </div>

      <Modal
        open={resetOpen}
        onClose={() => setResetOpen(false)}
        title="Сбросить настройки HUD?"
        description="Виджеты, позиция, цвета и Visuals вернутся к значениям по умолчанию. Сохранённые профили останутся."
        icon={<RotateCcw size={16} />}
        footer={
          <>
            <button type="button" onClick={() => setResetOpen(false)} className="btn-ghost !h-9">
              Отмена
            </button>
            <button
              type="button"
              onClick={() => {
                onResetAll();
                setResetOpen(false);
                onNotify("Настройки сброшены", "HUD и Visuals вернулись к значениям по умолчанию.", "success");
              }}
              className="btn-primary !h-9"
            >
              <RotateCcw size={12} />
              Сбросить
            </button>
          </>
        }
      />
    </div>
  );
}

export function settingsSectionIcon(section: Section) {
  const map = {
    home: Sparkles,
    hud: LayoutDashboard,
    interface: Palette,
    graphics: Triangle,
    sound: Volume2,
    controls: Gamepad2,
    other: Layers,
  } as const;
  const Icon = map[section];
  return <Icon size={12} />;
}

export const extraIcons = { BarChart3, Clock3, Cpu, Heart, MonitorCog, BadgeCheck, SlidersIcon };
