import { Box, Info } from "lucide-react";
import type { VisualSettings } from "../lib/types";
import { cn } from "../utils/cn";

/**
 * Independent schematic preview for China Hat / Trail.
 * It deliberately does NOT reuse the game scene: the avatar, path and material
 * are approximations, not the player's real skin or the real game shader.
 */
export function SchematicStage({
  visuals,
  mode = "both",
  className,
  compact = false,
}: {
  visuals: VisualSettings;
  mode?: "hat" | "trail" | "both";
  className?: string;
  compact?: boolean;
}) {
  const hat = visuals.hat;
  const trail = visuals.trail;
  const showHat = mode !== "trail" && hat.enabled;
  const showTrail = mode !== "hat" && trail.enabled;

  const hatHeight = 54 + hat.coneHeight * 30;
  const hatWidth = 46 + hat.radius * 46;
  const bob = 2 + hat.floatAmount * 28;
  const bobDuration = Math.max(0.4, 2.4 / Math.max(0.15, hat.floatSpeed));
  const trailStroke = 5 + trail.height * 14;
  const trailSegments = Math.max(2, Math.round(trail.lifetime * 4));

  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-xl border border-white/10 bg-[radial-gradient(circle_at_50%_28%,#12241a,#060d09_68%)]",
        className,
      )}
    >
      <div
        className="absolute inset-0 opacity-50 [background-image:linear-gradient(rgba(109,255,135,0.085)_1px,transparent_1px),linear-gradient(90deg,rgba(109,255,135,0.085)_1px,transparent_1px)] [background-size:22px_22px] [mask-image:radial-gradient(ellipse_at_center,black_20%,transparent_80%)]"
        aria-hidden="true"
      />
      <div className="pointer-events-none absolute left-1/2 top-1/2 h-32 w-32 -translate-x-1/2 -translate-y-1/2 rounded-full bg-[rgba(var(--acc-rgb),0.1)] blur-2xl" />

      <svg
        viewBox="0 0 320 220"
        className={cn("relative z-10 w-full", compact ? "h-[168px]" : "h-[230px]")}
        role="img"
        aria-label="Схематичный предпросмотр эффектов: демонстрационный аватар, не игровой скин"
      >
        <defs>
          <linearGradient id="schem-trail" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="transparent" />
            <stop offset="45%" stopColor={trail.rainbow ? "#7bb9ff" : trail.color} stopOpacity="0.75" />
            <stop offset="100%" stopColor={trail.rainbow ? "#ff8b8b" : trail.color} stopOpacity="0.95" />
          </linearGradient>
          <linearGradient id="schem-hat" x1="0" y1="0" x2="1" y2="1">
            {hat.rainbow ? (
              <>
                <stop offset="0%" stopColor="#ff7b7b" />
                <stop offset="30%" stopColor="#ffe97b" />
                <stop offset="60%" stopColor="#8cff9d" />
                <stop offset="100%" stopColor="#7bb9ff" />
              </>
            ) : (
              <>
                <stop offset="0%" stopColor={hat.color} stopOpacity="0.95" />
                <stop offset="100%" stopColor={hat.color} stopOpacity="0.35" />
              </>
            )}
          </linearGradient>
          <filter id="schem-glow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="4" result="blur" />
            <feMerge>
              <feMergeNode in="blur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        <ellipse cx="160" cy="196" rx="92" ry="13" fill="rgba(0,0,0,0.45)" />
        <ellipse cx="160" cy="196" rx="60" ry="7" fill="rgba(var(--acc-rgb),0.12)" />

        {showTrail && (
          <g opacity={trail.opacity}>
            <path
              d={`M ${60} ${172} C ${95} 150, ${110} 186, ${138} 165`}
              fill="none"
              stroke="url(#schem-trail)"
              strokeWidth={trailStroke}
              strokeLinecap="round"
              strokeDasharray={trail.fill ? undefined : "6 5"}
            />
            {Array.from({ length: trailSegments }).map((_, index) => {
              const t = index / Math.max(1, trailSegments - 1);
              return (
                <circle
                  key={index}
                  cx={64 + t * 72}
                  cy={172 - Math.sin(t * Math.PI * 1.4) * 12}
                  r={2.2}
                  fill={trail.rainbow ? "#9dffb4" : trail.color}
                  opacity={0.25 + t * 0.6}
                />
              );
            })}
            <text x="62" y="196" fill="rgba(255,255,255,0.4)" fontSize="6" fontFamily="monospace">
              demo path · lifetime {trail.lifetime.toFixed(1)}s
            </text>
          </g>
        )}

        <g transform="translate(126, 82)">
          <rect x="18" y="46" width="33" height="34" rx="2" fill="#4c7a3f" />
          <rect x="18" y="46" width="33" height="7" rx="1" fill="#5f934d" />
          <rect x="14" y="48" width="8" height="26" rx="2" fill="#b98a6a" />
          <rect x="47" y="48" width="8" height="26" rx="2" fill="#b98a6a" />
          <rect x="54" y="70" width="6" height="16" rx="2" fill="#3a5f31" />
          <rect x="19" y="80" width="13" height="30" rx="2" fill="#40506e" />
          <rect x="36" y="80" width="13" height="30" rx="2" fill="#34425c" />
          <rect x="16" y="108" width="17" height="8" rx="2" fill="#232a33" />
          <rect x="35" y="108" width="17" height="8" rx="2" fill="#232a33" />
          <g>
            <rect x="15" y="14" width="38" height="34" rx="3" fill="#c99a7a" />
            <rect x="15" y="14" width="38" height="8" rx="2" fill="#2f2a28" />
            <rect x="19" y="24" width="7" height="6" rx="1" fill="#4b3b33" />
            <rect x="41" y="24" width="7" height="6" rx="1" fill="#4b3b33" />
            <rect x="30" y="34" width="12" height="4" rx="1" fill="#8d6a55" />
            <rect x="25" y="38" width="18" height="8" rx="2" fill="#6c4f3d" />
            <rect x="48" y="16" width="6" height="30" rx="2" fill="#b98a6a" />
          </g>
          {showHat && (
            <g
              filter={hat.rainbow ? "url(#schem-glow)" : undefined}
              style={{
                animation: `schem-bob ${bobDuration}s ease-in-out infinite`,
                transformOrigin: "34px 12px",
              }}
            >
              <ellipse
                cx="34"
                cy={14 - hat.offset * 20}
                rx={hatWidth / 2}
                ry={9}
                fill={hat.rainbow ? "url(#schem-hat)" : hat.color}
                opacity={hat.opacity * 0.55}
              />
              <path
                d={`M ${34 - hatWidth / 2} ${14 - hat.offset * 20}
                    L 34 ${14 - hat.offset * 20 - hatHeight}
                    L ${34 + hatWidth / 2} ${14 - hat.offset * 20} Z`}
                fill={hat.rainbow ? "url(#schem-hat)" : hat.color}
                opacity={hat.fill ? hat.opacity * 0.55 : 0.06}
                stroke={hat.color}
                strokeOpacity={hat.opacity * 0.9}
                strokeWidth="1.4"
              />
              {Array.from({ length: 6 }).map((_, index) => {
                const angle = (index / 6) * Math.PI;
                const dx = Math.cos(angle) * (hatWidth / 2);
                const dy = Math.sin(angle) * 9;
                return (
                  <line
                    key={index}
                    x1={34 - dx}
                    y1={14 - hat.offset * 20 + dy}
                    x2={34 + dx}
                    y2={14 - hat.offset * 20 - dy}
                    stroke={hat.color}
                    strokeOpacity={hat.opacity * 0.55}
                    strokeWidth="0.8"
                  />
                );
              })}
              <ellipse
                cx="34"
                cy={14 - hat.offset * 20}
                rx={hatWidth / 2}
                ry={9}
                fill="none"
                stroke={hat.color}
                strokeOpacity={hat.opacity}
                strokeWidth="1.4"
              />
            </g>
          )}
        </g>
      </svg>

      <div className="pointer-events-none absolute inset-x-2 bottom-1.5 flex items-wrap items-center justify-between gap-2">
        <span className="flex items-center gap-1 rounded border border-white/10 bg-black/40 px-1.5 py-0.5 font-mono text-[7px] text-white/55">
          <Box size={8} />
          demo avatar
        </span>
        <span className="flex items-center gap-1 rounded border border-amber-300/20 bg-amber-400/8 px-1.5 py-0.5 font-mono text-[7px] text-amber-200/80">
          <Info size={8} />
          {showHat || showTrail ? "приближение, не игровой шейдер" : "эффекты выключены"}
        </span>
      </div>

      <style>{`
        @keyframes schem-bob {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-${bob.toFixed(1)}px); }
        }
        @media (prefers-reduced-motion: reduce) {
          g[style] { animation: none !important; }
        }
      `}</style>
    </div>
  );
}
