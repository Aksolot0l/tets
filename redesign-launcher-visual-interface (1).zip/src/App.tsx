import {
  AlertTriangle,
  CheckCircle2,
  Expand,
  Eye,
  Info,
  Lightbulb,
  Minus,
  Square,
  X,
  XCircle,
  LayoutDashboard,
} from "lucide-react";
import { Component, useCallback, useEffect, useRef, useState, type ErrorInfo, type ReactNode } from "react";
import { HudSettingsPanel } from "./components/HudPanel";
import { Preview } from "./components/Preview";
import {
  ControlsSection,
  GraphicsSection,
  HomeSection,
  InterfaceSection,
  OtherSection,
  SoundSection,
} from "./components/SettingsSections";
import { Sidebar, sections } from "./components/Sidebar";
import { ModsPage, ProfilesPage, StatsPage } from "./components/TabsPages";
import { TopBar } from "./components/TopBar";
import { PixelBlocks, PixelSparkles } from "./components/ui";
import {
  accentThemes,
  APP_VERSION,
  defaultHud,
  defaultInterface,
  defaultModules,
  defaultSound,
  defaultVisuals,
} from "./lib/data";
import { mascot } from "./lib/images";
import type {
  GameModule,
  HudPreset,
  HudSettings,
  InterfaceSettings,
  Section,
  SoundSettings,
  Toast,
  TopTab,
  VisualSettings,
  WindowState,
} from "./lib/types";
import { cn } from "./utils/cn";

const clone = <T,>(value: T): T => JSON.parse(JSON.stringify(value)) as T;

class AppErrorBoundary extends Component<{ children: ReactNode }, { error: Error | null }> {
  state = { error: null as Error | null };

  static getDerivedStateFromError(error: Error) {
    return { error };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error("GAYCLIENT UI error", error, info);
  }

  render() {
    if (!this.state.error) return this.props.children;
    return (
      <div className="game-bg flex min-h-[100dvh] items-center justify-center p-4">
        <div className="panel w-full max-w-[420px] p-6 text-center">
          <p className="font-pixel text-[10px] text-[#f0fff4]">GAYCLIENT</p>
          <h1 className="mt-3 font-display text-[17px] text-[#f2fff5]">Не удалось открыть интерфейс</h1>
          <p className="mt-1.5 text-[10.5px] leading-relaxed text-[#8aa793]">
            Похоже, сохранённые настройки несовместимы с этой версией. Сбросьте их — профили и
            остальные данные останутся.
          </p>
          <button
            type="button"
            className="btn-solid mt-4 h-10 w-full"
            onClick={() => {
              try {
                Object.keys(localStorage)
                  .filter((key) => key.startsWith("gayclient."))
                  .forEach((key) => localStorage.removeItem(key));
              } catch {
                /* ignore */
              }
              window.location.reload();
            }}
          >
            Сбросить настройки и открыть
          </button>
          <p className="mt-2 font-mono text-[8px] break-all text-[#4f6b58]">{this.state.error.message}</p>
        </div>
      </div>
    );
  }
}

const initialPresets: HudPreset[] = [
  {
    id: "classic",
    name: "Классика",
    createdAt: "12.03.2026",
    hud: { ...clone(defaultHud), widgets: { ...clone(defaultHud.widgets), fps: true, cps: true, clock: true, keys: false, watermark: false } },
    visuals: clone(defaultVisuals),
  },
  {
    id: "minimal",
    name: "Минимал",
    createdAt: "08.03.2026",
    hud: {
      ...clone(defaultHud),
      scale: 0.9,
      opacity: 0.55,
      position: "bottom-left",
      x: 3,
      y: 72,
      widgets: { ...clone(defaultHud.widgets), fps: true, cps: false, clock: false, keys: false, watermark: true },
    },
    visuals: clone(defaultVisuals),
  },
];

function mergeDeep<T>(base: T, saved: unknown): T {
  if (Array.isArray(base)) return (Array.isArray(saved) ? saved : base) as T;
  if (base && typeof base === "object") {
    if (!saved || typeof saved !== "object" || Array.isArray(saved)) return base;
    const result: Record<string, unknown> = { ...(base as Record<string, unknown>) };
    for (const [key, value] of Object.entries(saved as Record<string, unknown>)) {
      const fallback = (base as Record<string, unknown>)[key];
      result[key] = fallback !== undefined ? mergeDeep(fallback, value) : value;
    }
    return result as T;
  }
  if (typeof base === "number") return (typeof saved === "number" && Number.isFinite(saved) ? saved : base) as T;
  if (typeof base === "boolean") return (typeof saved === "boolean" ? saved : base) as T;
  if (typeof base === "string") return (typeof saved === "string" ? saved : base) as T;
  return (saved ?? base) as T;
}

function usePersisted<T>(key: string, initial: T) {
  const [value, setValue] = useState<T>(() => {
    try {
      const raw = localStorage.getItem(key);
      if (!raw) return initial;
      return mergeDeep(initial, JSON.parse(raw));
    } catch {
      return initial;
    }
  });
  useEffect(() => {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch {
      /* storage can be unavailable */
    }
  }, [key, value]);
  return [value, setValue] as const;
}

function useToast() {
  const [toast, setToast] = useState<Toast | null>(null);
  const timer = useRef<number | null>(null);
  const notify = useCallback(
    (title: string, description?: string, tone: Toast["tone"] = "info") => {
      if (timer.current) window.clearTimeout(timer.current);
      setToast({ id: Date.now(), title, description, tone });
      timer.current = window.setTimeout(() => setToast(null), 3800);
    },
    [],
  );
  useEffect(() => () => {
    if (timer.current) window.clearTimeout(timer.current);
  }, []);
  return { toast, notify, dismiss: () => setToast(null) };
}

function ToastCard({ toast, onClose }: { toast: Toast | null; onClose: () => void }) {
  if (!toast) return null;
  const map = {
    success: { icon: CheckCircle2, color: "text-[var(--acc)]", border: "border-[rgba(var(--acc-rgb),0.35)]" },
    info: { icon: Info, color: "text-[#7dccff]", border: "border-sky-300/25" },
    warning: { icon: AlertTriangle, color: "text-amber-300", border: "border-amber-300/30" },
    error: { icon: XCircle, color: "text-red-300", border: "border-red-400/30" },
  }[toast.tone];
  const Icon = map.icon;
  return (
    <div
      role="status"
      aria-live="polite"
      className={cn(
        "animate-toast fixed right-4 bottom-4 z-[80] flex w-[min(360px,calc(100vw-2rem))] items-start gap-2.5 rounded-xl border bg-[linear-gradient(155deg,#122418,#07130c)] p-3 shadow-[0_24px_70px_-20px_#000]",
        map.border,
      )}
    >
      <Icon size={16} className={cn("mt-0.5 shrink-0", map.color)} />
      <div className="min-w-0 flex-1">
        <p className="text-[11.5px] font-bold text-[#effff3]">{toast.title}</p>
        {toast.description && <p className="mt-0.5 text-[9.5px] leading-relaxed text-[#88a493]">{toast.description}</p>}
      </div>
      <button type="button" onClick={onClose} aria-label="Скрыть" className="text-[#658172] hover:text-white">
        <X size={12} />
      </button>
    </div>
  );
}

function Launcher() {
  const [topTab, setTopTab] = useState<TopTab>("settings");
  const [section, setSection] = useState<Section>("hud");
  const [windowState, setWindowState] = useState<WindowState>("normal");
  const [previewOpen, setPreviewOpen] = useState(false);

  const [hud, setHud] = usePersisted<HudSettings>("gayclient.hud.v3", defaultHud);
  const [visuals, setVisuals] = usePersisted<VisualSettings>("gayclient.visuals.v3", defaultVisuals);
  const [iface, setIface] = usePersisted<InterfaceSettings>("gayclient.interface.v3", defaultInterface);
  const [sound, setSound] = usePersisted<SoundSettings>("gayclient.sound.v3", defaultSound);
  const [storedModules, setModules] = usePersisted<GameModule[]>("gayclient.modules.v3", defaultModules);
  const modules = Array.isArray(storedModules) && storedModules.length > 0 ? storedModules.filter((module) => module && typeof module.id === "string") : defaultModules;
  const [presets, setPresets] = usePersisted<HudPreset[]>("gayclient.presets.v3", initialPresets);
  const { toast, notify, dismiss } = useToast();

  useEffect(() => {
    const theme = accentThemes.find((item) => item.id === iface.accent) ?? accentThemes[0];
    const root = document.documentElement;
    root.style.setProperty("--acc", theme.accent);
    root.style.setProperty("--acc2", theme.accent2);
    root.style.setProperty("--acc-deep", theme.deep);
    root.style.setProperty("--acc-rgb", theme.rgb);
    root.dataset.motion = iface.animations ? "on" : "off";
  }, [iface.accent, iface.animations]);

  const patchHud = useCallback(
    (patch: Partial<HudSettings>) => setHud((current) => ({ ...current, ...patch })),
    [setHud],
  );
  const patchVisuals = useCallback(
    (patch: Partial<VisualSettings>) => setVisuals((current) => ({ ...current, ...patch })),
    [setVisuals],
  );
  const patchInterface = useCallback(
    (patch: Partial<InterfaceSettings>) => setIface((current) => ({ ...current, ...patch })),
    [setIface],
  );
  const patchSound = useCallback(
    (patch: Partial<SoundSettings>) => setSound((current) => ({ ...current, ...patch })),
    [setSound],
  );

  const moveHud = useCallback(
    (x: number, y: number) => setHud((current) => ({ ...current, position: "custom", x: Math.round(x), y: Math.round(y) })),
    [setHud],
  );
  const moveModules = useCallback(
    (x: number, y: number) => setHud((current) => ({ ...current, moduleX: Math.round(x), moduleY: Math.round(y) })),
    [setHud],
  );

  const resetAll = useCallback(() => {
    setHud(clone(defaultHud));
    setVisuals(clone(defaultVisuals));
  }, [setHud, setVisuals]);

  const navigate = useCallback((next: Section) => {
    setSection(next);
    setTopTab("settings");
  }, []);

  const savePreset = useCallback(
    (name: string) => {
      const preset: HudPreset = {
        id: `preset-${Date.now()}`,
        name,
        createdAt: new Intl.DateTimeFormat("ru-RU", { day: "2-digit", month: "2-digit", year: "numeric" }).format(new Date()),
        hud: clone(hud),
        visuals: clone(visuals),
      };
      setPresets((current) => [preset, ...current]);
      notify("Профиль HUD сохранён", `«${name}» готов к применению.`, "success");
    },
    [hud, visuals, setPresets, notify],
  );

  const applyPreset = useCallback(
    (preset: HudPreset) => {
      setHud(clone(preset.hud));
      setVisuals(clone(preset.visuals));
      notify("Профиль применён", `HUD «${preset.name}» загружен в редактор.`, "success");
    },
    [setHud, setVisuals, notify],
  );

  const deletePreset = useCallback(
    (id: string) => {
      setPresets((current) => current.filter((preset) => preset.id !== id));
      notify("Профиль удалён", undefined, "info");
    },
    [setPresets, notify],
  );

  const toggleModule = useCallback(
    (id: string) => {
      setModules((current) =>
        current.map((module) => {
          if (module.id !== id) return module;
          const enabled = !module.enabled;
          if (id === "china-hat") patchVisuals({ hat: { ...visuals.hat, enabled } });
          if (id === "trail") patchVisuals({ trail: { ...visuals.trail, enabled } });
          return { ...module, enabled };
        }),
      );
    },
    [setModules, patchVisuals, visuals.hat, visuals.trail],
  );

  const exportConfig = useCallback(() => {
    const blob = new Blob(
      [JSON.stringify({ format: "gayclient-hud", version: APP_VERSION, hud, visuals }, null, 2)],
      { type: "application/json" },
    );
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = "gayclient-hud.json";
    anchor.click();
    URL.revokeObjectURL(url);
    notify("Конфигурация выгружена", "Файл gayclient-hud.json сохранён.", "success");
  }, [hud, visuals, notify]);

  const enabledWidgets = Object.values(hud.widgets).filter(Boolean).length;

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      if (target && ["INPUT", "TEXTAREA", "SELECT"].includes(target.tagName)) return;
      if (document.querySelector('[role="dialog"]')) return;
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "s") {
        event.preventDefault();
        setTopTab("profiles");
        notify("Профили HUD", "Сохраните текущую сборку кнопкой «Сохранить текущий».", "info");
        return;
      }
      if (!event.ctrlKey && !event.metaKey && !event.altKey && /^[1-7]$/.test(event.key)) {
        const next = sections[Number(event.key) - 1];
        if (next) {
          event.preventDefault();
          setTopTab("settings");
          setSection(next.id);
        }
      }
      if (event.key === "Escape" && windowState === "minimized") setWindowState("normal");
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [notify, windowState]);

  const hudTitle =
    topTab === "settings"
      ? section === "hud"
        ? "HUD"
        : sections.find((item) => item.id === section)?.label ?? "Настройки"
      : topTab === "mods"
        ? "Моды"
        : topTab === "profiles"
          ? "Профили HUD"
          : "Статистика";

  return (
    <div className={cn("game-bg flex min-h-[100dvh] items-center justify-center p-2 sm:p-4")}>
      {iface.glow && (
        <>
          <div className="aurora top-[-16%] left-[-8%] h-[520px] w-[560px] opacity-70" aria-hidden="true" />
          <div className="aurora right-[-10%] bottom-[-18%] h-[560px] w-[620px] opacity-55 [animation-delay:-7s]" aria-hidden="true" />
        </>
      )}

      {windowState === "closed" ? (
        <div className="panel animate-fade-up relative z-10 w-full max-w-[430px] overflow-hidden p-7 text-center">
          <PixelSparkles className="opacity-50" />
          <div className="relative mx-auto h-32 w-32">
            <div className="absolute inset-2 rounded-full bg-[rgba(var(--acc-rgb),0.2)] blur-2xl" />
            <img src={mascot} alt="Маскот GAYCLIENT" className="mascot-glow mascot-fade relative h-32 w-32 object-contain" />
          </div>
          <p className="mt-3 font-pixel text-[11px] text-[#f1fff4]">GAYCLIENT</p>
          <h1 className="mt-3 font-display text-[19px] text-[#f2fff5]">Редактор закрыт</h1>
          <p className="mx-auto mt-1.5 max-w-[280px] text-[10.5px] leading-relaxed text-[#8aa793]">
            Настройки HUD и сохранённые профили остались на месте. Можно вернуться в любой момент.
          </p>
          <button
            type="button"
            onClick={() => {
              setWindowState("normal");
              notify("Редактор открыт", "Продолжайте настройку HUD.", "success");
            }}
            className="btn-solid mt-5 h-10 w-full"
          >
            <LayoutDashboard size={14} />
            Открыть снова
          </button>
          <p className="mt-2.5 font-mono text-[8px] text-[#4f6b58]">локальная сессия · v{APP_VERSION}</p>
        </div>
      ) : (
        <>
          <div className={cn("shell", windowState === "maximized" && "shell--max", windowState === "minimized" && "invisible")}>
            <div className="hidden lg:flex">
              <Sidebar
                section={section}
                topTab={topTab}
                onNavigate={navigate}
                hudEnabled={enabledWidgets > 0}
                version={APP_VERSION}
              />
            </div>

            <main className="flex min-h-0 min-w-0 flex-1 flex-col">
              <div className="flex items-center gap-2 border-b border-[rgba(var(--acc-rgb),0.12)] bg-[rgba(7,20,12,0.72)] px-3 py-1.5 lg:hidden">
                <img src={mascot} alt="" className="mascot-fade h-7 w-7 object-contain" />
                <span className="font-pixel text-[9px] text-[#f0fff4]">GAYCLIENT</span>
                <span className="ml-auto font-mono text-[8px] text-[#6d8b78]">{hudTitle}</span>
              </div>
              <TopBar
                tab={topTab}
                onTab={setTopTab}
                windowState={windowState}
                onMinimize={() => setWindowState("minimized")}
                onMaximize={() => setWindowState((current) => (current === "maximized" ? "normal" : "maximized"))}
                onClose={() => setWindowState("closed")}
              />

              {topTab === "settings" && (
                <nav
                  aria-label="Разделы настроек"
                  className="scroll flex shrink-0 gap-1 overflow-x-auto border-b border-[rgba(var(--acc-rgb),0.1)] bg-[rgba(6,18,11,0.6)] px-2 py-1.5 lg:hidden"
                >
                  {sections.map((item) => {
                    const Icon = item.icon;
                    const active = section === item.id;
                    return (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => setSection(item.id)}
                        aria-current={active ? "page" : undefined}
                        className={cn(
                          "flex shrink-0 items-center gap-1.5 rounded-lg border px-2.5 py-1.5 text-[9.5px] font-bold transition-colors",
                          active
                            ? "border-[rgba(var(--acc-rgb),0.4)] bg-[rgba(var(--acc-rgb),0.12)] text-[#e4ffea]"
                            : "border-white/7 bg-white/[0.02] text-[#7d9b87] hover:text-white",
                        )}
                      >
                        <Icon size={11} className={active ? "text-[var(--acc)]" : undefined} />
                        {item.label}
                      </button>
                    );
                  })}
                </nav>
              )}

              <div className="scroll min-h-0 flex-1 overflow-y-auto px-2.5 pt-2.5 pb-3 lg:overflow-hidden">
                {topTab !== "settings" ? (
                  <div className="scroll h-full overflow-y-auto pr-0.5">
                    {topTab === "mods" && (
                      <ModsPage
                        modules={modules}
                        onToggle={toggleModule}
                        visuals={visuals}
                        onOpenVisuals={() => navigate("graphics")}
                      />
                    )}
                    {topTab === "profiles" && (
                      <ProfilesPage
                        hud={hud}
                        presets={presets}
                        onSave={savePreset}
                        onApply={applyPreset}
                        onDelete={deletePreset}
                        notify={notify}
                      />
                    )}
                    {topTab === "stats" && (
                      <StatsPage hud={hud} modules={modules} visuals={visuals} moduleCount={modules.length} />
                    )}
                  </div>
                ) : section === "hud" ? (
                  <div className="grid gap-2.5 xl:h-full xl:grid-cols-[minmax(0,0.82fr)_minmax(0,1.18fr)]">
                    <div className="panel h-[620px] min-h-0 overflow-hidden xl:h-full">
                      <HudSettingsPanel
                        hud={hud}
                        onChange={patchHud}
                        modules={modules}
                        visuals={visuals}
                        onVisualsChange={patchVisuals}
                        onReset={() => {
                          setHud(clone(defaultHud));
                          notify("HUD сброшен", "Виджеты и позиция вернулись к значениям по умолчанию.", "success");
                        }}
                        onOpenModules={() => setTopTab("mods")}
                      />
                    </div>

                    <div className="flex min-h-0 flex-col gap-2.5">
                      <div className="panel flex min-h-0 flex-1 flex-col overflow-hidden">
                        <div className="panel-head !px-3.5 !py-2.5">
                          <div className="flex items-center gap-2">
                            <span className="icon-tile h-7 w-7">
                              <Eye size={13} />
                            </span>
                            <div>
                              <p className="font-display text-[12px] leading-none text-[#f0fff4]">Предпросмотр</p>
                              <p className="mt-1 text-[8px] text-[#688574]">HUD поверх игрового мира · живой</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <span className="chip chip-accent hidden sm:inline-flex">
                              <span className="h-1 w-1 rounded-full bg-[var(--acc)]" />
                              {enabledWidgets} виджетов
                            </span>
                            <button
                              type="button"
                              onClick={() => setPreviewOpen(true)}
                              aria-label="Открыть превью на весь экран"
                              title="На весь экран"
                              className="btn-ghost !h-7 !w-7 !px-0"
                            >
                              <Expand size={12} />
                            </button>
                          </div>
                        </div>
                        <div className="min-h-[320px] flex-1 p-2 sm:p-2.5">
                          <Preview
                            hud={hud}
                            visuals={visuals}
                            modules={modules}
                            onChange={patchHud}
                            onVisualsChange={patchVisuals}
                            onToggleModule={toggleModule}
                            onNotify={notify}
                            onOpenVisuals={() => navigate("graphics")}
                            onReset={resetAll}
                          />
                        </div>
                      </div>

                      <div className="panel relative flex shrink-0 items-center gap-3 overflow-hidden p-3">
                        <PixelBlocks className="right-3 bottom-2 opacity-30" />
                        <div className="absolute right-2 bottom-[-18px] hidden h-24 w-24 opacity-80 sm:block">
                          <img src={mascot} alt="" className="mascot-fade h-full w-full object-contain" />
                        </div>
                        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-[rgba(var(--acc-rgb),0.28)] bg-[rgba(var(--acc-rgb),0.1)] text-[var(--acc)]">
                          <Lightbulb size={15} />
                        </span>
                        <div className="relative z-10 max-w-[72%]">
                          <p className="text-[11px] font-bold text-[#e7f9ec]">Совет</p>
                          <p className="mt-0.5 text-[9px] leading-relaxed text-[#8aa793]">
                            Вы можете изменить позицию HUD, чтобы он не перекрывал важные элементы.
                            Перетаскивайте прямо по превью или используйте слайдеры.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="scroll h-full overflow-y-auto pr-0.5">
                    {section === "home" && (
                      <HomeSection
                        hud={hud}
                        visuals={visuals}
                        modules={modules}
                        onOpenHud={() => setSection("hud")}
                        onOpenGraphics={() => setSection("graphics")}
                        onOpenProfiles={() => setTopTab("profiles")}
                        onNotify={notify}
                      />
                    )}
                    {section === "interface" && (
                      <InterfaceSection settings={iface} onChange={patchInterface} hud={hud} onHudChange={patchHud} />
                    )}
                    {section === "graphics" && <GraphicsSection visuals={visuals} onChange={patchVisuals} hud={hud} />}
                    {section === "sound" && <SoundSection sound={sound} onChange={patchSound} />}
                    {section === "controls" && (
                      <ControlsSection hud={hud} onHudChange={patchHud} modules={modules} />
                    )}
                    {section === "other" && (
                      <OtherSection
                        hud={hud}
                        visuals={visuals}
                        onExport={exportConfig}
                        onResetAll={resetAll}
                        onNotify={notify}
                      />
                    )}
                  </div>
                )}
              </div>
            </main>
          </div>

          {windowState === "minimized" && (
            <div className="animate-fade-up fixed bottom-4 left-1/2 z-30 flex w-[min(430px,calc(100vw-2rem))] -translate-x-1/2 items-center gap-2.5 rounded-2xl border border-[rgba(var(--acc-rgb),0.25)] bg-[linear-gradient(150deg,#13251a,#07120c)] px-3 py-2.5 shadow-[0_24px_70px_-20px_#000]">
              <img src={mascot} alt="" className="mascot-fade h-9 w-9 object-contain" />
              <div className="min-w-0 flex-1">
                <p className="font-pixel text-[8px] text-[#e9fcec]">GAYCLIENT</p>
                <p className="mt-1 flex items-center gap-1.5 text-[9px] text-[#86a48f]">
                  <span className="h-1.5 w-1.5 rounded-full bg-[var(--acc)]" />
                  {hudTitle} · свёрнуто
                </p>
              </div>
              <button type="button" onClick={() => setWindowState("normal")} className="btn-ghost !h-7">
                <Square size={9} />
                Открыть
              </button>
              <button
                type="button"
                onClick={() => setWindowState("closed")}
                aria-label="Закрыть"
                className="flex h-7 w-7 items-center justify-center rounded-md text-[#728f7c] hover:bg-red-500/15 hover:text-red-300"
              >
                <X size={12} />
              </button>
            </div>
          )}
        </>
      )}

      {previewOpen && (
        <div className="fixed inset-0 z-[70] flex flex-col gap-2 bg-[#020704]/92 p-3 backdrop-blur-md sm:p-5">
          <div className="flex items-center justify-between gap-3 px-1">
            <div className="flex items-center gap-2">
              <span className="icon-tile h-8 w-8">
                <Eye size={14} />
              </span>
              <div>
                <p className="font-display text-[13px] text-[#f1fff4]">Предпросмотр HUD</p>
                <p className="mt-0.5 text-[8.5px] text-[#7d9b87]">Полноэкранный режим · Esc закрывает</p>
              </div>
            </div>
            <button type="button" onClick={() => setPreviewOpen(false)} className="btn-ghost">
              <Minus size={12} />
              Закрыть превью
            </button>
          </div>
          <div className="min-h-0 flex-1">
            <Preview
              hud={hud}
              visuals={visuals}
              modules={modules}
              onChange={patchHud}
              onVisualsChange={patchVisuals}
              onToggleModule={toggleModule}
              onNotify={notify}
              onOpenVisuals={() => {
                setPreviewOpen(false);
                navigate("graphics");
              }}
              onReset={resetAll}
            />
          </div>
        </div>
      )}

      {previewOpen && (
        <button
          type="button"
          onClick={() => setPreviewOpen(false)}
          aria-label="Закрыть полноэкранное превью"
          className="fixed right-3 top-3 z-[75] flex h-8 w-8 items-center justify-center rounded-lg border border-white/12 bg-black/40 text-[#a7c3b0] hover:text-white"
        >
          <X size={14} />
        </button>
      )}

      <ToastCard toast={toast} onClose={dismiss} />
    </div>
  );
}

export default function App() {
  return (
    <AppErrorBoundary>
      <Launcher />
    </AppErrorBoundary>
  );
}
