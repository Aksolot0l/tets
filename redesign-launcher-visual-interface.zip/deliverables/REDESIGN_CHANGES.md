# GAYClient HUD redesign — visual layer

Base: `a4906259e7791f2e55fda659766b216f97a7c468` (`arena/5d11f1ec-tets`).
Reference: `redesign-launcher-visual-interface (1).zip`.

**Scope: visuals only.** No settings writes, game addresses, render hooks,
input changes or fake metrics. Client integration stays with the developer.

## Files

| Path | State | Purpose |
|---|---|---|
| `repair/src/hud_theme.h` | changed | Visual tokens: palettes, opacity/rounding guards, spacing, type hierarchy, editor geometry. No ImGui, no game state. |
| `repair/src/hud_visual_kit.h` | **new** | Pure specs for buttons (primary/secondary/ghost/danger), toggles, sliders, cards, section headers, pills, status dots, swatches, palette previews and the five-column layout. Includes a contrast guard. |
| `repair/src/compat.cpp` | changed | Reskin of the adapter's own windows: toolbar, five editor columns + preview, restyled Visuals and HUD entry, scoped legacy-card and main-menu colours. |
| `repair/tests/hud_visual_kit.cpp` | **new** | Unit tests for every visual spec and layout math. |
| `repair/tests/check_hud_visual_style.py` | **new** | Static proof of visual-only scope and preservation of controls/effects. |
| `repair/README.md` | changed | Visual-layer integration notes and limits. |
| `repair/HUD_ALL_IN_ONE.txt` | changed | Update note plus authoritative new sources; original material preserved. |
| `REDESIGN_CHANGES.md` | new | This handoff. |

## Preserved controls

Widget checkboxes (`setModule`), three palettes (Aogiri Green / Emerald /
Graphite), card rounding, widget background opacity, HUD text colour, Module
List HUD toggle/scale/opacity/X/Y, palette + preview, China Hat, Trail,
per-effect Settings, Options, Vertex gradient (test), Hat at player pass
(test), Game model replay (test), fallback avatar labels, Del / wheel / hooks.

## Deliberately untouched

- No `ag::Settings` writes and no new game addresses.
- No changes to depth-test, opacity behaviour or the known hat-occlusion bug.
- No independent camera, no automatic front view, no hat copy, no trail in the
  GPU preview.
- No mock FPS/CPS/ping/keystrokes/inventory values.
- Closed core may override card decoration; menu theming is scoped to
  `insideCoreMenu` around the adapter's own `realDrawGui(runtime)`.

## Checks

```bash
c++ -std=c++17 -O2 repair/tests/hud_theme.cpp -o /tmp/hud-theme && /tmp/hud-theme
c++ -std=c++17 -O2 repair/tests/hud_visual_kit.cpp -o /tmp/hud-kit && /tmp/hud-kit
python3 repair/tests/check_hud_visual_update.py
python3 repair/tests/check_hud_visual_style.py
```

No Windows DLL was built here (no Windows toolchain/closed core). Build with the
repository command, verify in Windows/Minecraft, then refresh
`repair/install-manifest.json` (SHA-256 + size).
