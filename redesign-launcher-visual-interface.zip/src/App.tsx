import { useEffect, useState } from "react";
import { ZIP_BASE64 } from "./lib/artifacts";
import patchText from "./assets/gayclient-hud-visual.patch?raw";
import changesText from "./assets/REDESIGN_CHANGES.md?raw";

const ZIP_SHA = "efd57c3f4ad161713f6936f03d68d90c712cc2cf00a08459fc36c71da3b2500a";
const PATCH_SHA = "6115f9f72264508ef203d0f7fef4cb26b805512ae3658f63c5e2ab2607d95223";
const ZIP_NAME = "gayclient-hud-visual.zip";
const PATCH_NAME = "gayclient-hud-visual.patch";

function base64ToBytes(value: string): Uint8Array {
  const binary = atob(value);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

function saveBlob(data: Uint8Array | string, name: string, type: string) {
  const blob = new Blob([data], { type });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = name;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 4000);
}

const downloadZip = () => saveBlob(base64ToBytes(ZIP_BASE64), ZIP_NAME, "application/zip");
const downloadPatch = () => saveBlob(patchText, PATCH_NAME, "text/x-patch;charset=utf-8");

const downloadChanges = () => {
  saveBlob(changesText, "REDESIGN_CHANGES.md", "text/markdown;charset=utf-8");
};

const BUILD = `zig c++ -target x86_64-windows-gnu -std=c++17 -shared -O2 -Wall -Wextra \\
  -Irepair/vendor/imgui repair/src/compat.cpp repair/src/uwp_extra.cpp \\
  repair/src/china_hat_native.cpp -o repair/GAYClientInternal.dll \\
  -ld3d11 -ldxgi -luser32 -lole32 -lapi-ms-win-core-winrt-l1-1-0 \\
  -lapi-ms-win-core-winrt-string-l1-1-0 -luuid -lbcrypt -static`;

type IconProps = { className?: string };
const Icon = {
  down: ({ className }: IconProps) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M12 3v12" /><path d="m7 11 5 5 5-5" /><path d="M5 21h14" />
    </svg>
  ),
  copy: ({ className }: IconProps) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <rect x="9" y="9" width="12" height="12" rx="2" /><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
    </svg>
  ),
  check: ({ className }: IconProps) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="m4 12 5 5L20 6" />
    </svg>
  ),
  arrow: ({ className }: IconProps) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M4 12h16" /><path d="m14 6 6 6-6 6" />
    </svg>
  ),
  file: ({ className }: IconProps) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8Z" /><path d="M14 3v5h5" />
    </svg>
  ),
  layers: ({ className }: IconProps) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="m12 3 9 5-9 5-9-5 9-5Z" /><path d="m3 13 9 5 9-5" /><path d="m3 18 9 5 9-5" />
    </svg>
  ),
  spark: ({ className }: IconProps) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M12 3v4M12 17v4M3 12h4M17 12h4M5.6 5.6l2.8 2.8M15.6 15.6l2.8 2.8M18.4 5.6l-2.8 2.8M8.4 15.6l-2.8 2.8" />
    </svg>
  ),
  alert: ({ className }: IconProps) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M12 3 2 21h20L12 3Z" /><path d="M12 9v5" /><path d="M12 18h.01" />
    </svg>
  ),
  branch: ({ className }: IconProps) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <circle cx="6" cy="5" r="2" /><circle cx="6" cy="19" r="2" /><circle cx="18" cy="7" r="2" />
      <path d="M6 7v10M18 9v2a4 4 0 0 1-4 4H9" />
    </svg>
  ),
  terminal: ({ className }: IconProps) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <rect x="2" y="4" width="20" height="16" rx="2" /><path d="m6 9 3 3-3 3M12 15h5" />
    </svg>
  ),
  shield: ({ className }: IconProps) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M12 3 4 6v6c0 5 8 9 8 9s8-4 8-9V6l-8-3Z" /><path d="m9 12 2 2 4-4" />
    </svg>
  ),
  leaf: ({ className }: IconProps) => (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
      <path d="M4 20c0-7 5-13 16-16-1 11-7 16-13 16H4Zm3-3c3-4 6-6 10-8-5 1-8 3-10 8Z" />
    </svg>
  ),
};

const palette = [
  { name: "Aogiri Green", hex: "#4dff88", bg: "#08130d" },
  { name: "Emerald", hex: "#2ee6a0", bg: "#07130f" },
  { name: "Graphite", hex: "#9dffb4", bg: "#0d1110" },
];

const files = [
  { path: "repair/src/hud_theme.h", state: "изменён", note: "Палитры, прозрачность, скругления, типографика и геометрия панелей." },
  { path: "repair/src/hud_visual_kit.h", state: "новый", note: "Спецификации кнопок, тумблеров, ползунков, карточек, пилюль и сетки." },
  { path: "repair/src/compat.cpp", state: "изменён", note: "Рескин окон адаптера: toolbar, 5 колонок, предпросмотр, Visuals, HUD entry." },
  { path: "repair/tests/hud_visual_kit.cpp", state: "новый", note: "Юнит-тесты визуальных спецификаций и геометрии." },
  { path: "repair/tests/check_hud_visual_style.py", state: "новый", note: "Проверки «только визуал» и сохранности всех контролов." },
  { path: "repair/README.md", state: "изменён", note: "Границы визуального слоя, интеграция и ограничения." },
  { path: "repair/HUD_ALL_IN_ONE.txt", state: "изменён", note: "Актуальные исходники добавлены, оригинал сохранён." },
  { path: "REDESIGN_CHANGES.md", state: "новый", note: "Краткий handoff: файлы, сохранённые контролы, проверки." },
];

const checks = [
  "hud_theme.cpp — API и токены, g++ 12",
  "hud_visual_kit.cpp — спецификации и сетка",
  "check_hud_visual_update.py — пройден",
  "check_hud_visual_style.py — пройден",
  "git apply на чистом клоне a490625 — OK",
];

const pending = [
  "Сборка GAYClientInternal.dll на Windows",
  "Проверка панелей в Minecraft 1.1.5",
  "Проверка читаемости на фоне игры",
  "Обновление install-manifest.json (SHA-256)",
];

const limits = [
  "Только визуал: новых записей в ag::Settings, адресов и хуков нет.",
  "Интеграция с клиентом остаётся за разработчиком.",
  "Ядро может переопределять фон карточек после scoped-стилизации.",
  "Прозрачность и depth-test не менялись; перекрытие шляпы не исправлено.",
  "Независимая камера, авто-фронт, копирование шляпы и Trail в GPU-preview — test.",
  "Ping, CPS, клавиши и инвентарь не рисуются и не выдумываются.",
];

function CopyButton({ value, label, onCopied }: { value: string; label: string; onCopied: (text: string) => void }) {
  return (
    <button
      type="button"
      className="icon-btn"
      title={`Скопировать ${label}`}
      aria-label={`Скопировать ${label}`}
      onClick={() => {
        navigator.clipboard?.writeText(value).then(
          () => onCopied("Скопировано"),
          () => onCopied("Не удалось скопировать"),
        );
      }}
    >
      <Icon.copy className="h-3.5 w-3.5" />
    </button>
  );
}

export default function App() {
  const [toast, setToast] = useState<string | null>(null);

  useEffect(() => {
    if (!toast) return;
    const id = window.setTimeout(() => setToast(null), 2200);
    return () => window.clearTimeout(id);
  }, [toast]);

  const copied = (text: string) => setToast(text);

  return (
    <div className="app">
      <div className="bg-aurora bg-aurora-a" aria-hidden="true" />
      <div className="bg-aurora bg-aurora-b" aria-hidden="true" />
      <div className="bg-grid" aria-hidden="true" />

      <header className="topbar">
        <a className="brand" href="#top" aria-label="GAYCLIENT — в начало">
          <span className="brand-mark"><Icon.leaf className="h-4 w-4" /></span>
          <span className="brand-text">GAYCLIENT</span>
          <span className="brand-sub">HUD</span>
        </a>
        <nav className="topnav" aria-label="Быстрые ссылки">
          <a href="#files">Файлы</a>
          <a href="#checks">Проверки</a>
          <a href="#build">Сборка</a>
        </nav>
        <a className="top-cta" onClick={downloadZip}>
          <Icon.down className="h-3.5 w-3.5" />
          Скачать
        </a>
      </header>

      <main id="top" className="container">
        <section className="hero">
          <div className="hero-copy">
            <div className="eyebrow">
              <span className="eyebrow-dot" />
              HUD REDESIGN · VISUAL ONLY
            </div>
            <h1>
              Новый интерфейс.
              <br />
              <span className="grad">Готов к интеграции.</span>
            </h1>
            <p className="lead">
              Визуальный слой для настоящего C++/ImGui-адаптера GAYClient: панели, кнопки,
              тумблеры, карточки и предпросмотр в стиле макета. Готовые файлы, патч и
              тесты — без логики, фиктивных данных и изменений закрытого ядра.
            </p>

            <div className="hero-actions">
              <a className="btn btn-primary" onClick={downloadZip}>
                <Icon.down className="h-4 w-4" />
                Скачать ZIP
                <span className="btn-meta">141 КБ</span>
              </a>
              <a className="btn btn-secondary" onClick={downloadPatch}>
                <Icon.branch className="h-4 w-4" />
                Git patch
              </a>
              <a className="btn btn-ghost" onClick={downloadChanges}>
                CHANGES.md
                <Icon.arrow className="h-3.5 w-3.5" />
              </a>
            </div>

            <dl className="meta">
              <div>
                <dt>База</dt>
                <dd><code>a490625</code></dd>
              </div>
              <div>
                <dt>Ветка</dt>
                <dd><code>arena/5d11f1ec-tets</code></dd>
              </div>
              <div>
                <dt>Ядро</dt>
                <dd><span className="tag">не изменено</span></dd>
              </div>
            </dl>
          </div>

          <aside className="release" aria-label="Состав релиза">
            <div className="release-head">
              <span className="release-title">release.bundle</span>
              <span className="release-state"><span className="live-dot" />готов</span>
            </div>
            <div className="release-art">
              <div className="art-ring" aria-hidden="true">
                <span className="art-leaf"><Icon.leaf className="h-7 w-7" /></span>
                <span className="art-orbit" />
              </div>
              <div>
                <p className="art-title">HUD REDESIGN</p>
                <p className="art-sub">adapter UI · session style</p>
              </div>
            </div>
            <div className="swatches">
              {palette.map((p) => (
                <div key={p.name} className="swatch" style={{ background: p.bg, borderColor: `${p.hex}55` }}>
                  <span className="swatch-dot" style={{ background: p.hex }} />
                  <span className="swatch-name">{p.name}</span>
                </div>
              ))}
            </div>
            <div className="release-grid">
              <div><span>8</span><small>файлов</small></div>
              <div><span>5</span><small>панелей</small></div>
              <div><span>3</span><small>палитры</small></div>
              <div><span>0</span><small>записей</small></div>
            </div>
            <div className="release-foot">
              <Icon.shield className="h-3.5 w-3.5" />
              <span>Только визуал · логика не тронута</span>
            </div>
          </aside>
        </section>

        <section className="downloads" aria-label="Загрузки">
          <div className="dl-card dl-primary">
            <div className="dl-top">
              <span className="dl-icon"><Icon.down className="h-4 w-4" /></span>
              <div>
                <h2>ZIP со всеми файлами</h2>
                <p>Пути сохранены относительно корня репозитория.</p>
              </div>
            </div>
            <div className="sha">
              <span className="sha-label">SHA-256</span>
              <code title={ZIP_SHA}>{ZIP_SHA}</code>
              <CopyButton value={ZIP_SHA} label="SHA-256 ZIP" onCopied={copied} />
            </div>
            <a className="dl-link" onClick={downloadZip}>
              gayclient-hud-visual.zip
              <span>144 513 Б</span>
            </a>
          </div>

          <div className="dl-card">
            <div className="dl-top">
              <span className="dl-icon"><Icon.branch className="h-4 w-4" /></span>
              <div>
                <h2>Git patch</h2>
                <p>Применяется к базовому коммиту целиком.</p>
              </div>
            </div>
            <div className="sha">
              <span className="sha-label">SHA-256</span>
              <code title={PATCH_SHA}>{PATCH_SHA}</code>
              <CopyButton value={PATCH_SHA} label="SHA-256 patch" onCopied={copied} />
            </div>
            <a className="dl-link" onClick={downloadPatch}>
              gayclient-hud-visual.patch
              <span>157 514 Б</span>
            </a>
          </div>

          <div className="dl-card">
            <div className="dl-top">
              <span className="dl-icon"><Icon.file className="h-4 w-4" /></span>
              <div>
                <h2>Передача разработчику</h2>
                <p>Краткое описание визуального слоя.</p>
              </div>
            </div>
            <pre className="dl-apply"><code>git checkout a490625{`\n`}git apply gayclient-hud-visual.patch</code></pre>
            <a className="dl-link" onClick={downloadChanges}>
              REDESIGN_CHANGES.md
              <span>открыть</span>
            </a>
          </div>
        </section>

        <section id="files" className="section">
          <div className="section-head">
            <div>
              <p className="kicker">Состав</p>
              <h2>Изменённые и новые файлы</h2>
            </div>
            <span className="chip"><Icon.layers className="h-3 w-3" />8 файлов · 1 архив</span>
          </div>
          <div className="file-list">
            {files.map((file, index) => (
              <article className="file-row" key={file.path}>
                <span className="file-index">{String(index + 1).padStart(2, "0")}</span>
                <span className={`status ${file.state === "новый" ? "status-new" : "status-mod"}`}>{file.state}</span>
                <code className="file-path">{file.path}</code>
                <p className="file-note">{file.note}</p>
              </article>
            ))}
          </div>
        </section>

        <section className="section split">
          <div>
            <div className="section-head">
              <div>
                <p className="kicker">Верификация</p>
                <h2>Что уже проверено</h2>
              </div>
              <span className="chip chip-ok"><Icon.check className="h-3 w-3" />5 / 5</span>
            </div>
            <div className="panel checks">
              <ul>
                {checks.map((check) => (
                  <li key={check}>
                    <span className="check-mark"><Icon.check className="h-3 w-3" /></span>
                    {check}
                  </li>
                ))}
              </ul>
              <p className="panel-note">
                Патч проверен <code>git apply</code> на чистом клоне базового коммита.
              </p>
            </div>

            <div className="panel pending">
              <div className="pending-head">
                <Icon.alert className="h-4 w-4" />
                <h3>Требует Windows и Minecraft</h3>
              </div>
              <ul>
                {pending.map((item) => (
                  <li key={item}><span className="pending-dot" />{item}</li>
                ))}
              </ul>
              <p className="panel-note">
                В этой среде нет Windows-кросс-компилятора и закрытого ядра, поэтому DLL
                не собрана. Статические тесты не заменяют проверку в игре.
              </p>
            </div>
          </div>

          <div className="side-stack">
            <div className="panel limits">
              <div className="section-head compact">
                <div>
                  <p className="kicker">Границы</p>
                  <h2>Что не подключено</h2>
                </div>
              </div>
              <ul>
                {limits.map((item) => (
                  <li key={item}><span className="limit-dash" />{item}</li>
                ))}
              </ul>
            </div>

            <div className="panel honest">
              <Icon.shield className="h-5 w-5" />
              <div>
                <h3>Без выдуманных данных</h3>
                <p>
                  Патч не добавляет показателей и контролов: он меняет только цвета,
                  отступы, радиусы и компоновку существующих элементов.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section id="build" className="section">
          <div className="section-head">
            <div>
              <p className="kicker">Интеграция</p>
              <h2>Сборка у разработчика</h2>
            </div>
            <span className="chip"><Icon.terminal className="h-3 w-3" />Zig 0.13</span>
          </div>
          <div className="code-card">
            <div className="code-head">
              <span className="code-dots" aria-hidden="true"><i /><i /><i /></span>
              <span>build-windows.sh</span>
              <CopyButton value={BUILD} label="команду сборки" onCopied={copied} />
            </div>
            <pre><code>{BUILD}</code></pre>
            <div className="code-foot">
              После сборки: прогнать тесты, проверить в игре и обновить
              <code> repair/install-manifest.json</code> — SHA-256 и размер DLL.
            </div>
          </div>
        </section>

        <footer className="footer">
          <div className="footer-brand">
            <span className="brand-mark small"><Icon.leaf className="h-3.5 w-3.5" /></span>
            <div>
              <p>GAYCLIENT</p>
              <small>HUD redesign handoff · {new Date().getFullYear()}</small>
            </div>
          </div>
          <div className="footer-links">
            <a onClick={downloadZip}>ZIP</a>
            <a onClick={downloadPatch}>Patch</a>
            <a onClick={downloadChanges}>CHANGES</a>
          </div>
          <p className="footer-note">Лаунчер отдельно не переделывался · проверка в игре обязательна</p>
        </footer>
      </main>

      {toast && (
        <div className="toast" role="status" aria-live="polite">
          <Icon.check className="h-3.5 w-3.5" />
          {toast}
        </div>
      )}
    </div>
  );
}
