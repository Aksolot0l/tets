import { ChevronDown, Sparkles, X } from "lucide-react";
import { useEffect, type ReactNode } from "react";
import { cn } from "../utils/cn";

export function Toggle({
  checked,
  onChange,
  label,
  disabled,
}: {
  checked: boolean;
  onChange: (value: boolean) => void;
  label: string;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      disabled={disabled}
      data-on={checked}
      className="toggle"
      onClick={() => onChange(!checked)}
    />
  );
}

export function ToggleRow({
  icon,
  title,
  hint,
  checked,
  onChange,
  badge,
  disabled,
}: {
  icon?: ReactNode;
  title: string;
  hint?: string;
  checked: boolean;
  onChange: (value: boolean) => void;
  badge?: string;
  disabled?: boolean;
}) {
  return (
    <div className="flex items-center gap-2.5 py-[7px]">
      {icon && (
        <span className="flex h-6 w-6 flex-none items-center justify-center rounded-md border border-[rgba(var(--acc-rgb),0.16)] bg-[rgba(var(--acc-rgb),0.05)] text-[#80b891]">
          {icon}
        </span>
      )}
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-1.5">
          <p className="truncate text-[11.5px] font-semibold text-[#dcefe2]">{title}</p>
          {badge && (
            <span className="rounded border border-white/10 bg-white/4 px-1 py-px text-[7.5px] font-bold tracking-wide text-[#8aa895] uppercase">
              {badge}
            </span>
          )}
        </div>
        {hint && <p className="mt-0.5 truncate text-[9.5px] text-[#6c8a78]">{hint}</p>}
      </div>
      <Toggle checked={checked} onChange={onChange} label={title} disabled={disabled} />
    </div>
  );
}

export function Slider({
  label,
  icon,
  value,
  min,
  max,
  step = 0.01,
  format,
  onChange,
  accent,
}: {
  label: string;
  icon?: ReactNode;
  value: number;
  min: number;
  max: number;
  step?: number;
  format?: (value: number) => string;
  onChange: (value: number) => void;
  accent?: boolean;
}) {
  const pct = Math.round(((value - min) / (max - min)) * 100);
  return (
    <div className="flex items-center gap-2.5 py-[6px]">
      {icon && (
        <span className="flex h-6 w-6 flex-none items-center justify-center rounded-md border border-[rgba(var(--acc-rgb),0.16)] bg-[rgba(var(--acc-rgb),0.05)] text-[#80b891]">
          {icon}
        </span>
      )}
      <div className="min-w-0 flex-1">
        <div className="flex items-center justify-between gap-2">
          <p className="truncate text-[11px] font-semibold text-[#d6ecdd]">{label}</p>
          <span
            className={cn(
              "min-w-[42px] rounded border px-1.5 py-0.5 text-right font-mono text-[9.5px] font-bold",
              accent
                ? "border-[rgba(var(--acc-rgb),0.28)] bg-[rgba(var(--acc-rgb),0.08)] text-[#c9ffd8]"
                : "border-white/8 bg-black/25 text-[#9fbaa8]",
            )}
          >
            {format ? format(value) : value.toFixed(2)}
          </span>
        </div>
        <input
          type="range"
          className="range mt-1.5"
          min={min}
          max={max}
          step={step}
          value={value}
          aria-label={label}
          style={{ "--pct": `${pct}%` } as React.CSSProperties}
          onChange={(event) => onChange(Number(event.target.value))}
        />
      </div>
    </div>
  );
}

export function SectionCard({
  title,
  icon,
  children,
  action,
  className,
}: {
  title: string;
  icon?: ReactNode;
  children: ReactNode;
  action?: ReactNode;
  className?: string;
}) {
  return (
    <section className={cn("panel-section", className)}>
      <header className="section-head">
        {icon}
        <span className="flex-1">{title}</span>
        {action}
      </header>
      <div className="px-3 py-1.5">{children}</div>
    </section>
  );
}

export function Dropdown({
  value,
  options,
  onChange,
  label,
}: {
  value: string;
  options: { id: string; label: string }[];
  onChange: (value: string) => void;
  label: string;
}) {
  return (
    <div className="relative">
      <select
        aria-label={label}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        className="select"
      >
        {options.map((option) => (
          <option key={option.id} value={option.id}>
            {option.label}
          </option>
        ))}
      </select>
      <ChevronDown
        size={13}
        className="pointer-events-none absolute top-1/2 right-2.5 -translate-y-1/2 text-[var(--acc)]"
      />
    </div>
  );
}

export function ColorDots({
  colors,
  value,
  onChange,
}: {
  colors: string[];
  value: string;
  onChange: (color: string) => void;
}) {
  return (
    <div className="flex flex-wrap items-center gap-1.5" role="group" aria-label="Цвет текста HUD">
      {colors.map((color) => (
        <button
          key={color}
          type="button"
          onClick={() => onChange(color)}
          aria-label={`Цвет ${color}`}
          aria-pressed={value === color}
          className={cn(
            "h-5 w-5 rounded-full border transition-transform",
            value === color
              ? "scale-110 border-white/80 shadow-[0_0_0_2px_rgba(var(--acc-rgb),0.35)]"
              : "border-white/15 hover:scale-105",
          )}
          style={{ background: color }}
        />
      ))}
      <label className="relative ml-0.5 flex h-5 w-5 cursor-pointer items-center justify-center overflow-hidden rounded-full border border-dashed border-white/25">
        <input
          type="color"
          value={value}
          onChange={(event) => onChange(event.target.value)}
          aria-label="Свой цвет HUD"
          className="absolute inset-0 cursor-pointer opacity-0"
        />
        <Sparkles size={10} className="pointer-events-none text-[#9fbdaa]" />
      </label>
    </div>
  );
}

export function PageTitle({
  eyebrow,
  title,
  description,
  action,
}: {
  eyebrow: string;
  title: string;
  description: string;
  action?: ReactNode;
}) {
  return (
    <div className="flex flex-wrap items-end justify-between gap-3 pb-3">
      <div>
        <p className="flex items-center gap-1.5 text-[8.5px] font-extrabold tracking-[0.2em] text-[var(--acc)] uppercase">
          <span className="h-1 w-1 rounded-full bg-[var(--acc)] shadow-[0_0_7px_1px_rgba(var(--acc-rgb),0.7)]" />
          {eyebrow}
        </p>
        <h1 className="mt-1.5 font-display text-[22px] leading-tight text-[#f1fdf4]">{title}</h1>
        <p className="mt-1 max-w-2xl text-[11.5px] leading-relaxed text-[#87a592]">{description}</p>
      </div>
      {action}
    </div>
  );
}

export function Modal({
  open,
  onClose,
  title,
  description,
  children,
  footer,
  icon,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  description?: string;
  children?: ReactNode;
  footer?: ReactNode;
  icon?: ReactNode;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-[#020704]/82 backdrop-blur-sm" onClick={onClose} aria-hidden="true" />
      <div
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className="animate-fade-up relative w-full max-w-md overflow-hidden rounded-2xl border border-[rgba(var(--acc-rgb),0.28)] bg-[linear-gradient(160deg,#102619,#06130c)] shadow-[0_40px_120px_-30px_#000]"
      >
        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[var(--acc)] to-transparent opacity-70" />
        <div className="flex items-start gap-3 p-4">
          {icon && (
            <span className="icon-tile h-9 w-9">{icon}</span>
          )}
          <div className="min-w-0 flex-1">
            <h3 className="font-display text-[15px] text-[#f1fff4]">{title}</h3>
            {description && <p className="mt-1 text-[10.5px] leading-relaxed text-[#88a493]">{description}</p>}
          </div>
          <button type="button" onClick={onClose} aria-label="Закрыть" className="btn-ghost h-7 w-7 p-0">
            <X size={13} />
          </button>
        </div>
        {children && <div className="px-4 pb-4">{children}</div>}
        {footer && (
          <div className="flex items-center justify-end gap-2 border-t border-white/6 bg-black/20 px-4 py-3">
            {footer}
          </div>
        )}
      </div>
    </div>
  );
}

export function PixelSparkles({ className }: { className?: string }) {
  return (
    <div className={cn("pointer-events-none absolute inset-0 overflow-hidden", className)} aria-hidden="true">
      <span className="pixel-spark left-[10%] top-[22%] h-[3px] w-[3px] rounded-[1px]" />
      <span className="pixel-spark left-[22%] top-[64%] h-[4px] w-[4px] rounded-[1px] [animation-delay:1.2s]" />
      <span className="pixel-spark right-[24%] top-[14%] h-[3px] w-[3px] rounded-[1px] [animation-delay:0.6s]" />
      <span className="pixel-spark right-[8%] top-[52%] h-[5px] w-[5px] rounded-[1px] [animation-delay:2s]" />
    </div>
  );
}

export function PixelBlocks({ className }: { className?: string }) {
  return (
    <div className={cn("pointer-events-none absolute grid grid-cols-3 gap-[3px] opacity-50", className)} aria-hidden="true">
      {Array.from({ length: 12 }).map((_, index) => (
        <span
          key={index}
          className="h-[6px] w-[6px] rounded-[1px] bg-[var(--acc)]"
          style={{ opacity: 0.2 + ((index * 5) % 8) / 11 }}
        />
      ))}
    </div>
  );
}

export function EmptyState({
  icon,
  title,
  description,
  action,
}: {
  icon: ReactNode;
  title: string;
  description: string;
  action?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-white/10 bg-black/15 px-5 py-9 text-center">
      <span className="mb-2.5 flex h-10 w-10 items-center justify-center rounded-xl border border-white/8 bg-white/4 text-[#75937e]">
        {icon}
      </span>
      <p className="text-[11.5px] font-bold text-[#dcece1]">{title}</p>
      <p className="mt-1 max-w-xs text-[9.5px] leading-relaxed text-[#7d9a86]">{description}</p>
      {action && <div className="mt-3">{action}</div>}
    </div>
  );
}
