import {
  Gamepad2,
  Home,
  Image as ImageIcon,
  LayoutDashboard,
  MoreHorizontal,
  Palette,
  Volume2,
  Wifi,
} from "lucide-react";
import { mascot } from "../lib/images";
import type { Section, TopTab } from "../lib/types";
import { cn } from "../utils/cn";
import { PixelBlocks, PixelSparkles } from "./ui";

export const sections: { id: Section; label: string; icon: typeof Home; hint: string }[] = [
  { id: "home", label: "Главная", icon: Home, hint: "обзор" },
  { id: "hud", label: "HUD", icon: LayoutDashboard, hint: "виджеты" },
  { id: "interface", label: "Интерфейс", icon: Palette, hint: "тема" },
  { id: "graphics", label: "Графика", icon: ImageIcon, hint: "визуалы" },
  { id: "sound", label: "Звук", icon: Volume2, hint: "громкость" },
  { id: "controls", label: "Управление", icon: Gamepad2, hint: "клавиши" },
  { id: "other", label: "Прочее", icon: MoreHorizontal, hint: "о клиенте" },
];

export const sectionMeta: Record<Section, { title: string; subtitle: string }> = {
  home: { title: "Главная", subtitle: "Состояние HUD и быстрый доступ" },
  hud: { title: "HUD", subtitle: "Настройте отображение игрового интерфейса" },
  interface: { title: "Интерфейс", subtitle: "Оформление лаунчера и его масштаб" },
  graphics: { title: "Графика", subtitle: "Visuals, шляпа и след" },
  sound: { title: "Звук", subtitle: "Громкость интерфейса и эффектов" },
  controls: { title: "Управление", subtitle: "Горячие клавиши и мышь" },
  other: { title: "Прочее", subtitle: "Данные клиента и сброс" },
};

export function Sidebar({
  section,
  topTab,
  onNavigate,
  hudEnabled,
  version,
}: {
  section: Section;
  topTab: TopTab;
  onNavigate: (section: Section) => void;
  hudEnabled: boolean;
  version: string;
}) {
  return (
    <aside className="sidebar">
      <PixelSparkles className="opacity-40" />
      <PixelBlocks className="right-2 bottom-24" />

      <div className="mascot-wrap relative flex flex-col items-center px-4 pt-5">
        <div className="relative flex h-[134px] w-[168px] items-center justify-center">
          <div className="absolute inset-2 rounded-full bg-[rgba(var(--acc-rgb),0.2)] blur-2xl" />
          <div className="absolute inset-x-5 bottom-2 h-4 rounded-full bg-[rgba(var(--acc-rgb),0.18)] blur-md" />
          <img
            src={mascot}
            alt="Пиксельный маскот GAYCLIENT — кот в зелёном капюшоне"
            className="mascot-glow mascot-fade animate-float relative z-10 h-[150px] w-[150px] object-contain"
          />
          <span className="pixel-spark left-2 top-[28%] h-[4px] w-[4px] rounded-[1px]" />
          <span className="pixel-spark right-0 top-[50%] h-[5px] w-[5px] rounded-[1px] [animation-delay:1.1s]" />
          <span className="pixel-spark right-[22%] top-[6%] h-[3px] w-[3px] rounded-[1px] [animation-delay:2s]" />
        </div>
        <div className="mt-1 text-center">
          <p className="font-pixel text-[17px] leading-none tracking-[-0.02em] text-[#f3fff6] [text-shadow:0_0_22px_rgba(var(--acc-rgb),0.45)]">
            GAYCLIENT
          </p>
          <p className="mt-2 text-[9px] font-extrabold tracking-[0.36em] text-[#7d9f88] uppercase">
            Game Launcher
          </p>
        </div>
      </div>

      <nav aria-label="Разделы настроек" className="relative mt-4 flex-1 px-3">
        <p className="mb-2 px-2.5 text-[8px] font-extrabold tracking-[0.22em] text-[#55735f] uppercase">
          Настройки
        </p>
        <ul className="space-y-[3px]">
          {sections.map((item, index) => {
            const Icon = item.icon;
            const active = topTab === "settings" && section === item.id;
            return (
              <li key={item.id}>
                <button
                  type="button"
                  onClick={() => onNavigate(item.id)}
                  data-active={active}
                  aria-current={active ? "page" : undefined}
                  className="nav-btn"
                >
                  <span className="nav-icon">
                    <Icon size={14} strokeWidth={active ? 2.4 : 1.9} />
                  </span>
                  <span className="flex-1">{item.label}</span>
                  {item.id === "hud" && (
                    <span className="rounded border border-[rgba(var(--acc-rgb),0.25)] bg-[rgba(var(--acc-rgb),0.08)] px-1 py-px font-mono text-[7px] font-bold tracking-wide text-[#baf3c6]">
                      NEW
                    </span>
                  )}
                  <span className="hidden font-mono text-[8px] text-[#4f6b58] xl:inline">{index + 1}</span>
                </button>
              </li>
            );
          })}
        </ul>
      </nav>

      <div className="relative px-3 pt-3 pb-3.5">
        <div
          className={cn(
            "relative overflow-hidden rounded-xl border px-3 py-2.5",
            "border-[rgba(var(--acc-rgb),0.22)] bg-[linear-gradient(155deg,rgba(28,56,36,0.7),rgba(6,18,11,0.85))]",
          )}
        >
          <div className="flex items-center gap-2">
            <span className="relative flex h-2 w-2">
              <span className="live-dot absolute inline-flex h-full w-full rounded-full bg-[var(--acc)] opacity-70" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-[var(--acc)] shadow-[0_0_8px_rgba(var(--acc-rgb),0.8)]" />
            </span>
            <p className="text-[11px] font-bold text-[#e5f9ea]">Онлайн</p>
            <Wifi size={11} className="ml-auto text-[#5f7f6a]" />
          </div>
          <div className="mt-1.5 flex items-center justify-between text-[9.5px] text-[#7f9f89]">
            <span>Версия</span>
            <span className="font-mono font-bold text-[#b8d8c1]">{version}</span>
          </div>
          <div className="mt-2 h-px bg-white/6" />
          <p className="mt-1.5 flex items-center gap-1.5 text-[9px] text-[#6d8d77]">
            <span
              className={cn(
                "h-1 w-1 rounded-full",
                hudEnabled ? "bg-[var(--acc)] shadow-[0_0_5px_rgba(var(--acc-rgb),0.8)]" : "bg-[#667f6d]",
              )}
            />
            {hudEnabled ? "HUD готов к отрисовке" : "HUD отключён в настройках"}
          </p>
        </div>
        <p className="mt-2 text-center text-[8px] tracking-wide text-[#49634f]">
          локальные настройки · сессия не сохранена
        </p>
      </div>
    </aside>
  );
}
