import {
  Boxes,
  ChartNoAxesColumn,
  Minus,
  Settings2,
  Square,
  UserRound,
  X,
} from "lucide-react";
import type { TopTab, WindowState } from "../lib/types";
import { cn } from "../utils/cn";
import { PixelBlocks } from "./ui";

const tabs: { id: TopTab; label: string; icon: typeof Settings2 }[] = [
  { id: "settings", label: "Настройки", icon: Settings2 },
  { id: "mods", label: "Моды", icon: Boxes },
  { id: "profiles", label: "Профили", icon: UserRound },
  { id: "stats", label: "Статистика", icon: ChartNoAxesColumn },
];

export function TopBar({
  tab,
  onTab,
  windowState,
  onMinimize,
  onMaximize,
  onClose,
}: {
  tab: TopTab;
  onTab: (tab: TopTab) => void;
  windowState: WindowState;
  onMinimize: () => void;
  onMaximize: () => void;
  onClose: () => void;
}) {
  return (
    <header className="topbar">
      <div className="flex min-w-0 flex-1 items-center gap-1" role="tablist" aria-label="Разделы лаунчера">
        {tabs.map((item) => {
          const Icon = item.icon;
          const active = tab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              role="tab"
              aria-selected={active}
              onClick={() => onTab(item.id)}
              className="tab"
              data-active={active}
            >
              <Icon size={14} strokeWidth={active ? 2.4 : 1.9} />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>

      <div className="flex shrink-0 items-center gap-1.5">
        <div className="relative hidden items-center gap-1.5 rounded-lg border border-[rgba(var(--acc-rgb),0.18)] bg-black/25 px-2 py-1 sm:flex">
          <PixelBlocks className="relative inset-auto grid-cols-4 opacity-60" />
          <span className="font-mono text-[8.5px] tracking-[0.14em] text-[#70907b] uppercase">
            editor
          </span>
        </div>
        <div
          className={cn(
            "flex items-center gap-0.5 rounded-xl border border-[rgba(var(--acc-rgb),0.25)] bg-[linear-gradient(180deg,rgba(21,47,30,0.8),rgba(7,20,12,0.85))] p-1",
            "shadow-[inset_0_1px_0_rgba(255,255,255,0.06)]",
          )}
        >
          <button
            type="button"
            onClick={onMinimize}
            aria-label="Свернуть"
            title="Свернуть"
            className="flex h-7 w-7 items-center justify-center rounded-md text-[#8cae97] transition-colors hover:bg-white/6 hover:text-white"
          >
            <Minus size={13} />
          </button>
          <button
            type="button"
            onClick={onMaximize}
            aria-label={windowState === "maximized" ? "Восстановить" : "Развернуть"}
            title={windowState === "maximized" ? "Восстановить" : "Развернуть"}
            className="hidden h-7 w-7 items-center justify-center rounded-md text-[#8cae97] transition-colors hover:bg-white/6 hover:text-white sm:flex"
          >
            <Square size={10} />
          </button>
          <button
            type="button"
            onClick={onClose}
            aria-label="Закрыть"
            title="Закрыть"
            className="flex h-7 w-7 items-center justify-center rounded-md text-[#8cae97] transition-colors hover:bg-red-500/15 hover:text-red-300"
          >
            <X size={13} />
          </button>
        </div>
      </div>
    </header>
  );
}
