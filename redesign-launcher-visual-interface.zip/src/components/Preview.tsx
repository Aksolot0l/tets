import {
  Apple,
  BarChart3,
  Blocks,
  Clock3,
  Cpu,
  Diamond,
  Droplets,
  Flame,
  MemoryStick,
  MousePointer2,
  Pickaxe,
  Shield,
  Sword,
  Zap,
} from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { mascot, world } from "../lib/images";
import type { GameModule, HudSettings, VisualSettings } from "../lib/types";
import { cn } from "../utils/cn";

const keyList = [
  { code: "KeyW", label: "W" },
  { code: "KeyA", label: "A" },
  { code: "KeyS", label: "S" },
  { code: "KeyD", label: "D" },
  { code: "Space", label: "SPACE" },
  { code: "ShiftLeft", label: "SHIFT" },
];

const hotbarItems = [Pickaxe, Sword, Apple, Flame, Blocks, Diamond, Droplets, Shield, Zap];

function PixelHearts({ count = 10, half = 1 }: { count?: number; half?: number }) {
  const rows = [
    [1, 0, 2, 1],
    [5, 0, 2, 1],
    [0, 1, 4, 1],
    [5, 1, 4, 1],
    [0, 2, 9, 1],
    [1, 3, 7, 1],
    [2, 4, 5, 1],
    [3, 5, 3, 1],
    [4, 6, 1, 1],
  ];
  return (
    <div className="flex items-center gap-[2px]">
      {Array.from({ length: count }).map((_, index) => (
        <svg
          key={index}
          viewBox="0 0 9 7"
          width="11"
          height="9"
          className="pixel-heart"
          aria-hidden="true"
          shapeRendering="crispEdges"
        >
          {rows.map(([x, y, w, h], i) => (
            <rect
              key={i}
              x={x}
              y={y}
              width={w}
              height={h}
              fill={index === count - half ? "#ff6b6b" : "#ff3b3b"}
            />
          ))}
          <rect x="2" y="2" width="1" height="1" fill="#ffb3b3" opacity="0.85" />
        </svg>
      ))}
    </div>
  );
}

function HudRow({
  icon,
  label,
  value,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
}) {
  return (
    <div className="hud-row" style={{ gap: 7 }}>
      <span className="hud-icon" style={{ display: "inline-flex" }}>
        {icon}
      </span>
      <span className="hud-label">{label}</span>
      <span className="ml-auto pl-2 font-bold tracking-wide">{value}</span>
    </div>
  );
}

export function Preview({
  hud,
  visuals,
  modules,
  onHudPosition,
  onModulePosition,
}: {
  hud: HudSettings;
  visuals: VisualSettings;
  modules: GameModule[];
  onHudPosition: (x: number, y: number) => void;
  onModulePosition: (x: number, y: number) => void;
}) {
  const sceneRef = useRef<HTMLDivElement>(null);
  const [fps, setFps] = useState(144);
  const [clock, setClock] = useState(() => new Date());
  const [pressed, setPressed] = useState<Set<string>>(new Set());
  const [clicks, setClicks] = useState<number[]>([]);
  const [cps, setCps] = useState(0);
  const [pop, setPop] = useState<{ id: number; x: number; y: number } | null>(null);
  const [drag, setDrag] = useState<{
    target: "hud" | "modules";
    startX: number;
    startY: number;
    originX: number;
    originY: number;
    rect: DOMRect;
  } | null>(null);

  useEffect(() => {
    const fpsTimer = window.setInterval(() => setFps(140 + Math.floor(Math.random() * 8)), 900);
    const clockTimer = window.setInterval(() => setClock(new Date()), 1000);
    const cpsTimer = window.setInterval(() => {
      const now = Date.now();
      setClicks((current) => current.filter((time) => now - time < 1000));
    }, 130);
    return () => {
      window.clearInterval(fpsTimer);
      window.clearInterval(clockTimer);
      window.clearInterval(cpsTimer);
    };
  }, []);

  useEffect(() => {
    setCps(clicks.length);
  }, [clicks]);

  useEffect(() => {
    const down = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      if (target && ["INPUT", "TEXTAREA", "SELECT"].includes(target.tagName)) return;
      if (keyList.some((key) => key.code === event.code)) {
        setPressed((current) => new Set(current).add(event.code));
      }
    };
    const up = (event: KeyboardEvent) => {
      setPressed((current) => {
        const next = new Set(current);
        next.delete(event.code);
        return next;
      });
    };
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    return () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
    };
  }, []);

  useEffect(() => {
    if (!drag) return;
    const move = (event: PointerEvent) => {
      const scene = sceneRef.current?.getBoundingClientRect();
      if (!scene) return;
      const x = Math.min(94, Math.max(0, drag.originX + ((event.clientX - drag.startX) / scene.width) * 100));
      const y = Math.min(92, Math.max(0, drag.originY + ((event.clientY - drag.startY) / scene.height) * 100));
      if (drag.target === "hud") onHudPosition(x, y);
      else onModulePosition(x, y);
    };
    const end = () => setDrag(null);
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", end);
    window.addEventListener("pointercancel", end);
    return () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", end);
      window.removeEventListener("pointercancel", end);
    };
  }, [drag, onHudPosition, onModulePosition]);

  const startDrag = (event: React.PointerEvent, target: "hud" | "modules") => {
    event.preventDefault();
    event.stopPropagation();
    const scene = sceneRef.current?.getBoundingClientRect();
    const card = (event.currentTarget as HTMLElement).getBoundingClientRect();
    if (!scene) return;
    const originX = ((card.left - scene.left) / scene.width) * 100;
    const originY = ((card.top - scene.top) / scene.height) * 100;
    if (target === "hud") onHudPosition(Math.max(0, originX), Math.max(0, originY));
    setDrag({ target, startX: event.clientX, startY: event.clientY, originX, originY, rect: scene });
  };

  const addClick = (event: React.MouseEvent<HTMLDivElement>) => {
    const now = Date.now();
    setClicks((current) => [...current.filter((time) => now - time < 1000), now].slice(-20));
    const scene = sceneRef.current?.getBoundingClientRect();
    if (scene) {
      setPop({ id: now, x: event.clientX - scene.left, y: event.clientY - scene.top });
      window.setTimeout(() => setPop((current) => (current?.id === now ? null : current)), 620);
    }
  };

  const anchor: React.CSSProperties =
    hud.position === "custom"
      ? { left: `${hud.x}%`, top: `${hud.y}%` }
      : hud.position === "top-left"
        ? { left: "3%", top: "4%" }
        : hud.position === "top-right"
          ? { right: "3%", top: "4%" }
          : hud.position === "bottom-left"
            ? { left: "3%", bottom: "18%" }
            : { right: "3%", bottom: "18%" };

  const widgets = hud.widgets;
  const mainVisible =
    widgets.fps || widgets.cps || widgets.clock || widgets.performance || widgets.keys;
  const enabledModules = modules.filter((module) => module.enabled);
  const moduleNames = [
    ...enabledModules.map((module) => module.name),
    ...(visuals.hat.enabled ? ["China Hat"] : []),
    ...(visuals.trail.enabled ? ["Trail"] : []),
  ];
  const timeLabel = new Intl.DateTimeFormat("ru-RU", { hour: "2-digit", minute: "2-digit" }).format(clock);

  return (
    <div
      ref={sceneRef}
      className="scene relative h-full min-h-[320px] w-full touch-none select-none"
      onClick={addClick}
      role="img"
      aria-label="Предпросмотр игрового HUD поверх мира Minecraft. Перетаскивайте HUD для смены позиции, кликайте для CPS."
    >
      <img
        src={world}
        alt=""
        className="pointer-events-none absolute inset-0 h-full w-full object-cover"
        draggable={false}
      />
      <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(180deg,rgba(5,10,16,0.32),rgba(5,10,16,0.14)_38%,rgba(3,8,10,0.34))]" />
      <div className="crosshair" aria-hidden="true" />

      {visuals.hat.enabled && (
        <div
          className="pointer-events-none absolute left-1/2 top-[13%] z-10 h-16 w-14 -translate-x-1/2 opacity-90"
          aria-hidden="true"
          style={{ filter: `drop-shadow(0 0 12px ${visuals.hat.color})` }}
        >
          <div
            className="absolute inset-x-0 top-0 h-full"
            style={{
              background: visuals.hat.rainbow
                ? "linear-gradient(120deg,#ff7b7b,#ffe97b,#8cff9d,#7bb9ff)"
                : visuals.hat.color,
              clipPath: "polygon(50% 0%, 96% 100%, 4% 100%)",
              opacity: visuals.hat.opacity * 0.85,
            }}
          />
          <div className="absolute inset-x-4 top-1 h-full border border-white/40 [clip-path:polygon(50%_0%,100%_100%,0%_100%)]" />
          <span className="absolute -bottom-2 left-1/2 h-1 w-16 -translate-x-1/2 rounded-full bg-white/30 blur-[2px]" />
        </div>
      )}

      {visuals.trail.enabled && (
        <div
          className="pointer-events-none absolute bottom-[26%] left-[8%] z-10 h-2 w-[42%] rounded-full opacity-80 blur-[2px]"
          aria-hidden="true"
          style={{
            background: visuals.trail.rainbow
              ? "linear-gradient(90deg,transparent,#ff8b8b,#ffe97b,#8cff9d,#7bb9ff,transparent)"
              : `linear-gradient(90deg, transparent, ${visuals.trail.color}, transparent)`,
            opacity: visuals.trail.opacity * 0.75,
            transform: `translateY(${-(visuals.trail.height * 20)}px)`,
          }}
        />
      )}

      {mainVisible && (
        <div
          className="hud-card"
          data-dragging={drag?.target === "hud"}
          style={{
            ...anchor,
            "--hud-scale": hud.scale,
            "--hud-color": hud.textColor,
            "--hud-opacity": hud.opacity,
            padding: hud.padding,
            display: "flex",
            flexDirection: "column",
            gap: hud.gap,
          } as React.CSSProperties}
          onPointerDown={(event) => startDrag(event, "hud")}
          onClick={(event) => event.stopPropagation()}
          title="Перетащите HUD, чтобы изменить позицию"
        >
          {widgets.fps && (
            <HudRow
              icon={<BarChart3 size={12 * hud.scale} strokeWidth={2.6} />}
              label="FPS:"
              value={String(fps)}
            />
          )}
          {widgets.cps && (
            <HudRow
              icon={<MousePointer2 size={12 * hud.scale} strokeWidth={2.6} />}
              label="CPS:"
              value={String(cps)}
            />
          )}
          {widgets.clock && (
            <HudRow
              icon={<Clock3 size={12 * hud.scale} strokeWidth={2.6} />}
              label=""
              value={timeLabel}
            />
          )}
          {widgets.performance && (
            <>
              <HudRow
                icon={<Cpu size={12 * hud.scale} strokeWidth={2.6} />}
                label="CPU:"
                value="12%"
              />
              <HudRow
                icon={<MemoryStick size={12 * hud.scale} strokeWidth={2.6} />}
                label="RAM:"
                value="48%"
              />
            </>
          )}
          {widgets.keys && (
            <div className="mt-0.5 flex flex-wrap gap-1" style={{ maxWidth: 120 * hud.scale }}>
              {keyList.map((key) => {
                const active = pressed.has(key.code);
                return (
                  <span
                    key={key.code}
                    className={cn(
                      "rounded-[3px] border px-1 py-px font-minecraft leading-none transition-all",
                      active
                        ? "border-white/80 bg-white/90 text-[#08120c]"
                        : "border-white/20 bg-black/35 text-white/60",
                    )}
                    style={{ fontSize: Math.max(6, 7 * hud.scale) }}
                  >
                    {key.label}
                  </span>
                );
              })}
            </div>
          )}
        </div>
      )}

      {widgets.moduleList && (
        <div
          className="hud-card"
          data-dragging={drag?.target === "modules"}
          style={{
            left: `${hud.moduleX}%`,
            top: `${hud.moduleY}%`,
            "--hud-scale": hud.moduleScale,
            "--hud-color": hud.textColor,
            "--hud-opacity": hud.moduleOpacity,
            padding: hud.padding,
            minWidth: 108,
          } as React.CSSProperties}
          onPointerDown={(event) => startDrag(event, "modules")}
          onClick={(event) => event.stopPropagation()}
          title="Перетащите плашку модулей"
        >
          <p className="hud-label mb-1 font-bold tracking-[0.12em]" style={{ opacity: 0.95 }}>
            MODULES
          </p>
          {moduleNames.length === 0 ? (
            <p className="hud-row" style={{ opacity: 0.5, fontSize: 8 }}>
              No active modules
            </p>
          ) : (
            moduleNames.slice(0, 7).map((name) => (
              <p key={name} className="hud-row" style={{ fontSize: 9 }}>
                <span className="hud-icon">›</span> {name}
              </p>
            ))
          )}
        </div>
      )}

      {widgets.watermark && (
        <div className="pointer-events-none absolute bottom-[16%] left-[3%] z-20 flex items-center gap-1.5 rounded-md border border-white/10 bg-black/35 px-1.5 py-1 backdrop-blur-sm">
          <img src={mascot} alt="" className="mascot-fade h-5 w-5 object-contain" />
          <span className="font-pixel text-[6px] text-white/85">GAYCLIENT</span>
          <span className="font-minecraft text-[7px] text-[#8affaa]">v1.5</span>
        </div>
      )}

      {widgets.coordinates && (
        <div className="pointer-events-none absolute bottom-[16%] left-[3%] z-20 font-minecraft text-[8px] leading-relaxed text-white/85 [text-shadow:1px_1px_0_#000]">
          <p>X: 128 &nbsp; Y: 72 &nbsp; Z: -304</p>
          <p className="text-white/55">Facing: north · Overworld</p>
        </div>
      )}

      <div className="pointer-events-none absolute inset-x-0 bottom-2 z-20 flex flex-col items-center gap-1">
        {hud.showHearts && (
          <div className="flex w-full max-w-[260px] items-end justify-between px-2">
            <PixelHearts count={10} half={2} />
            <div className="flex items-center gap-[2px] text-[#e8ad4f]">
              {Array.from({ length: 10 }).map((_, index) => (
                <span
                  key={index}
                  className="inline-block h-[6px] w-[6px] rounded-[1px] bg-current"
                  style={{ opacity: index === 8 ? 0.45 : 0.95, boxShadow: "0 1px 0 rgba(0,0,0,.6)" }}
                />
              ))}
            </div>
          </div>
        )}

        {hud.showHotbar && (
          <div className="rounded-[3px] border border-white/25 bg-black/35 p-[2px] shadow-[0_2px_10px_rgba(0,0,0,.5)] backdrop-blur-[1px]">
            <div className="flex items-center gap-[2px]">
              {hotbarItems.map((Icon, index) => (
                <div
                  key={index}
                  className="hotbar-slot relative"
                  data-selected={index === 0}
                  style={{ height: 22 * hud.scale + 4, width: 22 * hud.scale + 4 }}
                >
                  <Icon size={11 * hud.scale} strokeWidth={2} />
                  {index === 2 && (
                    <span className="absolute right-0.5 bottom-0 font-minecraft text-[5px] text-white">2</span>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="h-[2px] w-[210px] overflow-hidden rounded-full bg-black/50">
          <div className="h-full w-[64%] rounded-full bg-[#7dff5e] shadow-[0_0_6px_rgba(125,255,94,.8)]" />
        </div>
      </div>

      {widgets.keys && (
        <div className="pointer-events-none absolute bottom-[30%] left-1/2 z-10 flex -translate-x-1/2 items-center gap-1 rounded-md border border-white/10 bg-black/25 px-1.5 py-1 backdrop-blur-[2px]">
          {keyList.slice(0, 4).map((key) => (
            <span
              key={key.code}
              className={cn(
                "flex h-4 w-4 items-center justify-center rounded-[2px] border font-minecraft text-[6px] transition-colors",
                pressed.has(key.code)
                  ? "border-[var(--acc)] bg-[var(--acc)] text-[#062410]"
                  : "border-white/25 text-white/60",
              )}
            >
              {key.label}
            </span>
          ))}
        </div>
      )}

      {pop && (
        <span
          className="pointer-events-none absolute z-30 font-minecraft text-[10px] font-bold text-[#b9ff62]"
          style={{ left: pop.x, top: pop.y, animation: "cps-pop 0.62s ease-out forwards" }}
        >
          +1 click
        </span>
      )}

      <div className="pointer-events-none absolute top-2 left-2 z-20 flex items-center gap-1.5 rounded border border-white/10 bg-black/35 px-1.5 py-1 backdrop-blur-sm">
        <span className="h-1 w-1 rounded-full bg-[#7dff5e]" />
        <span className="font-minecraft text-[7px] tracking-wide text-white/70">LIVE PREVIEW</span>
      </div>

      <div className="pointer-events-none absolute top-2 right-2 z-20 rounded border border-white/10 bg-black/35 px-1.5 py-1 font-minecraft text-[7px] text-white/60 backdrop-blur-sm">
        перетащите HUD · клик = CPS
      </div>
    </div>
  );
}
