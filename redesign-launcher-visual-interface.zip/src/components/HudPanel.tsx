import {
  Activity,
  BarChart3,
  CircleAlert,
  Clock3,
  Cpu,
  Crosshair,
  Eye,
  Gauge,
  Grid2x2,
  Heart,
  Info,
  Keyboard,
  Layers,
  Maximize2,
  MonitorCog,
  MousePointer2,
  Move,
  Palette,
  RotateCcw,
  ScanEye,
  SlidersHorizontal,
  Sparkles,
  Stamp,
  Triangle,
  WandSparkles,
  Waves,
} from "lucide-react";
import { useState } from "react";
import {
  hudPositions,
  hudTextColors,
  widgetDescriptions,
  widgetLabels,
} from "../lib/data";
import type {
  GameModule,
  HatSettings,
  HudSettings,
  HudTab,
  TrailSettings,
  VisualSettings,
  WidgetKey,
} from "../lib/types";
import { cn } from "../utils/cn";
import { ColorDots, Dropdown, SectionCard, Slider, ToggleRow } from "./ui";

const positionDefaults: Record<Exclude<HudSettings["position"], "custom">, { x: number; y: number }> = {
  "top-left": { x: 3, y: 4 },
  "top-right": { x: 76, y: 4 },
  "bottom-left": { x: 3, y: 72 },
  "bottom-right": { x: 76, y: 72 },
};

function CornerPicker({
  value,
  onChange,
}: {
  value: HudSettings["position"];
  onChange: (value: HudSettings["position"]) => void;
}) {
  const corners: { id: Exclude<HudSettings["position"], "custom">; label: string }[] = [
    { id: "top-left", label: "Слева сверху" },
    { id: "top-right", label: "Справа сверху" },
    { id: "bottom-left", label: "Слева снизу" },
    { id: "bottom-right", label: "Справа снизу" },
  ];
  return (
    <div className="flex items-center gap-1.5" role="group" aria-label="Быстрый выбор позиции HUD">
      {corners.map((corner) => (
        <button
          key={corner.id}
          type="button"
          title={corner.label}
          aria-label={corner.label}
          aria-pressed={value === corner.id}
          onClick={() => onChange(corner.id)}
          className={cn(
            "relative h-6 w-8 rounded-[4px] border transition-colors",
            value === corner.id
              ? "border-[rgba(var(--acc-rgb),0.6)] bg-[rgba(var(--acc-rgb),0.12)]"
              : "border-white/12 bg-black/25 hover:border-white/25",
          )}
        >
          <span
            className={cn(
              "absolute h-1.5 w-2.5 rounded-[1px]",
              corner.id.startsWith("top") ? "top-1" : "bottom-1",
              corner.id.endsWith("left") ? "left-1" : "right-1",
              value === corner.id ? "bg-[var(--acc)] shadow-[0_0_6px_rgba(var(--acc-rgb),0.7)]" : "bg-[#688272]",
            )}
          />
        </button>
      ))}
    </div>
  );
}

export function HudSettingsPanel({
  hud,
  onChange,
  modules,
  visuals,
  onVisualsChange,
  onReset,
  onOpenModules,
}: {
  hud: HudSettings;
  onChange: (patch: Partial<HudSettings>) => void;
  modules: GameModule[];
  visuals: VisualSettings;
  onVisualsChange: (patch: Partial<VisualSettings>) => void;
  onReset: () => void;
  onOpenModules: () => void;
}) {
  const [tab, setTab] = useState<HudTab>("widgets");
  const [advanced, setAdvanced] = useState(false);

  const setWidget = (key: WidgetKey, value: boolean) =>
    onChange({ widgets: { ...hud.widgets, [key]: value } });

  const setPosition = (position: HudSettings["position"]) => {
    if (position === "custom") {
      onChange({ position });
      return;
    }
    onChange({ position, ...positionDefaults[position] });
  };

  const activeModules = [
    ...modules.filter((module) => module.enabled).map((module) => module.name),
    ...(visuals.hat.enabled ? ["China Hat"] : []),
    ...(visuals.trail.enabled ? ["Trail"] : []),
  ];

  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="panel-head shrink-0 !px-4 !py-3">
        <div className="flex min-w-0 items-center gap-2.5">
          <span className="icon-tile">
            <MonitorCog size={16} />
          </span>
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <h2 className="font-display text-[15px] leading-none text-[#f2fff5]">HUD</h2>
              <span className="flex items-center gap-1 rounded border border-[rgba(var(--acc-rgb),0.3)] bg-[rgba(var(--acc-rgb),0.1)] px-1.5 py-px font-mono text-[7px] font-bold tracking-wide text-[#bdf7c8]">
                <span className="h-1 w-1 rounded-full bg-[var(--acc)]" />
                LIVE
              </span>
            </div>
            <p className="mt-1 truncate text-[9.5px] text-[#7d9b87]">Изменения применяются сразу</p>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-1 rounded-lg border border-white/7 bg-black/25 p-0.5">
          {(
            [
              { id: "widgets", label: "HUD", icon: Grid2x2 },
              { id: "visuals", label: "Visuals", icon: Sparkles },
              { id: "modules", label: "Модули", icon: Layers },
            ] as { id: HudTab; label: string; icon: typeof Grid2x2 }[]
          ).map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                type="button"
                aria-pressed={tab === item.id}
                onClick={() => setTab(item.id)}
                className={cn(
                  "flex items-center gap-1 rounded-md px-2 py-1.5 text-[9.5px] font-bold transition-colors",
                  tab === item.id
                    ? "bg-[rgba(var(--acc-rgb),0.14)] text-[#dcffe4] shadow-[inset_0_0_0_1px_rgba(var(--acc-rgb),0.24)]"
                    : "text-[#718e7c] hover:text-[#cfe7d6]",
                )}
              >
                <Icon size={11} />
                {item.label}
              </button>
            );
          })}
          <button
            type="button"
            onClick={onReset}
            title="Сбросить настройки HUD"
            aria-label="Сбросить настройки HUD"
            className="ml-0.5 flex h-6 w-6 items-center justify-center rounded-md text-[#75937f] transition-colors hover:bg-white/6 hover:text-[var(--acc)]"
          >
            <RotateCcw size={11} />
          </button>
        </div>
      </div>

      <div className="scroll min-h-0 flex-1 space-y-2.5 overflow-y-auto p-3">
        {tab === "widgets" && (
          <>
            <SectionCard title="Основные настройки" icon={<SlidersHorizontal size={12} className="text-[var(--acc)]" />}>
              <div className="divide-y divide-white/5">
                <ToggleRow
                  icon={<BarChart3 size={12} />}
                  title={widgetLabels.fps}
                  hint="Счётчик кадров в секунду"
                  checked={hud.widgets.fps}
                  onChange={(value) => setWidget("fps", value)}
                />
                <ToggleRow
                  icon={<MousePointer2 size={12} />}
                  title={widgetLabels.cps}
                  hint="Клики мышью за секунду"
                  checked={hud.widgets.cps}
                  onChange={(value) => setWidget("cps", value)}
                />
                <ToggleRow
                  icon={<Keyboard size={12} />}
                  title={widgetLabels.keys}
                  hint={widgetDescriptions.keys}
                  checked={hud.widgets.keys}
                  onChange={(value) => setWidget("keys", value)}
                />
                <ToggleRow
                  icon={<Clock3 size={12} />}
                  title={widgetLabels.clock}
                  hint="Системное время"
                  checked={hud.widgets.clock}
                  onChange={(value) => setWidget("clock", value)}
                />
                <ToggleRow
                  icon={<Stamp size={12} />}
                  title={widgetLabels.watermark}
                  hint="Подпись с маскотом"
                  checked={hud.widgets.watermark}
                  onChange={(value) => setWidget("watermark", value)}
                />
              </div>
              <button
                type="button"
                onClick={() => setAdvanced((value) => !value)}
                className="mt-1 flex w-full items-center justify-between rounded-md px-1 py-1.5 text-[9.5px] font-bold text-[#7f9d8a] transition-colors hover:text-[#c8e5d0]"
              >
                Дополнительные виджеты
                <span className="flex items-center gap-1 text-[8px] text-[#5d7c68]">
                  {advanced ? "свернуть" : "показать"}
                  <SlidersHorizontal size={10} />
                </span>
              </button>
              {advanced && (
                <div className="divide-y divide-white/5 border-t border-white/5">
                  <ToggleRow
                    icon={<Crosshair size={12} />}
                    title={widgetLabels.coordinates}
                    hint="X / Y / Z и направление"
                    checked={hud.widgets.coordinates}
                    onChange={(value) => setWidget("coordinates", value)}
                  />
                  <ToggleRow
                    icon={<Cpu size={12} />}
                    title={widgetLabels.performance}
                    hint="CPU и RAM"
                    checked={hud.widgets.performance}
                    onChange={(value) => setWidget("performance", value)}
                  />
                  <ToggleRow
                    icon={<Layers size={12} />}
                    title={widgetLabels.moduleList}
                    hint="Плашка MODULES"
                    checked={hud.widgets.moduleList}
                    onChange={(value) => {
                      setWidget("moduleList", value);
                      if (value) setTab("modules");
                    }}
                  />
                  <ToggleRow
                    icon={<Heart size={12} />}
                    title="Сердца и хотбар"
                    hint="Элементы игрового интерфейса в превью"
                    checked={hud.showHearts && hud.showHotbar}
                    onChange={(value) => onChange({ showHearts: value, showHotbar: value })}
                  />
                </div>
              )}
            </SectionCard>

            <SectionCard title="Размеры и отступы" icon={<Maximize2 size={12} className="text-[var(--acc)]" />}>
              <Slider
                label="Масштаб HUD"
                icon={<Maximize2 size={12} />}
                value={hud.scale}
                min={0.7}
                max={1.6}
                step={0.01}
                format={(value) => `${value.toFixed(2)}x`}
                onChange={(value) => onChange({ scale: value })}
                accent
              />
              <Slider
                label="Размер HUD"
                icon={<Gauge size={12} />}
                value={hud.padding}
                min={2}
                max={22}
                step={1}
                format={(value) => `${value.toFixed(0)}px`}
                onChange={(value) => onChange({ padding: value })}
              />
              <Slider
                label="Интервал строк"
                icon={<Move size={12} />}
                value={hud.gap}
                min={0}
                max={14}
                step={1}
                format={(value) => `${value.toFixed(0)}px`}
                onChange={(value) => onChange({ gap: value })}
              />
              <Slider
                label="Непрозрачность фона"
                icon={<Eye size={12} />}
                value={hud.opacity * 100}
                min={0}
                max={100}
                step={1}
                format={(value) => `${value.toFixed(0)}%`}
                onChange={(value) => onChange({ opacity: value / 100 })}
              />
            </SectionCard>

            <SectionCard title="Положение" icon={<Grid2x2 size={12} className="text-[var(--acc)]" />}>
              <div className="flex items-center gap-2 py-1">
                <span className="flex-1 text-[11px] font-semibold text-[#d6ecdd]">Позиция HUD</span>
                <div className="w-[132px]">
                  <Dropdown
                    label="Позиция HUD"
                    value={hud.position}
                    options={hudPositions.map((item) => ({ id: item.id, label: item.label }))}
                    onChange={(value) => setPosition(value as HudSettings["position"])}
                  />
                </div>
              </div>
              <div className="flex items-center justify-between gap-2 pb-1">
                <span className="text-[9.5px] text-[#718e7c]">Быстрый выбор</span>
                <CornerPicker value={hud.position} onChange={setPosition} />
              </div>
              <div className="border-t border-white/5 pt-0.5">
                <Slider
                  label="Позиция X"
                  icon={<Move size={12} />}
                  value={hud.x}
                  min={0}
                  max={92}
                  step={1}
                  format={(value) => `${value}%`}
                  onChange={(value) => onChange({ x: value, position: "custom" })}
                />
                <Slider
                  label="Позиция Y"
                  icon={<Move size={12} className="rotate-90" />}
                  value={hud.y}
                  min={0}
                  max={92}
                  step={1}
                  format={(value) => `${value}%`}
                  onChange={(value) => onChange({ y: value, position: "custom" })}
                />
                <p className="flex items-start gap-1.5 px-1 pt-1 pb-1 text-[8.5px] leading-relaxed text-[#5f7e69]">
                  <Info size={9} className="mt-px shrink-0" />
                  HUD можно перетаскивать прямо на превью — позиция станет «своей».
                </p>
              </div>
            </SectionCard>

            <SectionCard title="Оформление" icon={<Palette size={12} className="text-[var(--acc)]" />}>
              <div className="flex items-center justify-between gap-3 py-1.5">
                <span className="text-[11px] font-semibold text-[#d6ecdd]">Цвет текста HUD</span>
                <ColorDots colors={hudTextColors} value={hud.textColor} onChange={(textColor) => onChange({ textColor })} />
              </div>
              <p className="text-[8.5px] leading-relaxed text-[#5f7e69]">
                Цвет применяется ко всем виджетам. Прозрачность фона независима от прозрачности
                3D-эффектов в Visuals.
              </p>
            </SectionCard>
          </>
        )}

        {tab === "visuals" && (
          <div className="space-y-2.5">
            <div className="flex items-start gap-2 rounded-lg border border-amber-300/20 bg-amber-400/[0.06] px-2.5 py-2 text-[9px] leading-relaxed text-amber-200/85">
              <CircleAlert size={11} className="mt-px shrink-0" />
              <span>
                Visuals экспериментальные: градиент и прозрачность зависят от материала игры.
                Просвечивание сквозь блоки не исправлено.
              </span>
            </div>
            <VisualsPanel visuals={visuals} onChange={onVisualsChange} compact />
          </div>
        )}

        {tab === "modules" && (
          <>
            <SectionCard title="Плашка Module List" icon={<Layers size={12} className="text-[var(--acc)]" />}>
              <ToggleRow
                title={widgetLabels.moduleList}
                hint="Отдельная плашка MODULES в игре и превью"
                checked={hud.widgets.moduleList}
                onChange={(value) => setWidget("moduleList", value)}
              />
              <div className="border-t border-white/5">
                <Slider
                  label="Масштаб плашки"
                  icon={<Maximize2 size={12} />}
                  value={hud.moduleScale}
                  min={0.7}
                  max={1.6}
                  step={0.01}
                  format={(value) => `${value.toFixed(2)}x`}
                  onChange={(value) => onChange({ moduleScale: value })}
                />
                <Slider
                  label="Прозрачность фона"
                  icon={<Eye size={12} />}
                  value={hud.moduleOpacity * 100}
                  min={0}
                  max={100}
                  step={1}
                  format={(value) => `${value.toFixed(0)}%`}
                  onChange={(value) => onChange({ moduleOpacity: value / 100 })}
                />
                <Slider
                  label="Позиция X"
                  icon={<Move size={12} />}
                  value={hud.moduleX}
                  min={0}
                  max={90}
                  step={1}
                  format={(value) => `${value}%`}
                  onChange={(value) => onChange({ moduleX: value })}
                />
                <Slider
                  label="Позиция Y"
                  icon={<Move size={12} className="rotate-90" />}
                  value={hud.moduleY}
                  min={0}
                  max={90}
                  step={1}
                  format={(value) => `${value}%`}
                  onChange={(value) => onChange({ moduleY: value })}
                />
              </div>
              <p className="border-t border-white/5 pt-1.5 pb-1 text-[8.5px] leading-relaxed text-[#5f7e69]">
                Плашку тоже можно перетаскивать в превью. Новый редактор не меняет стиль старых
                HUD-виджетов ядра. В нативном клиенте параметры живут до закрытия игры.
              </p>
            </SectionCard>

            <SectionCard title="Как плашка выглядит в игре" icon={<Grid2x2 size={12} className="text-[var(--acc)]" />}>
              <div className="my-1.5 rounded-lg border border-white/8 bg-[linear-gradient(145deg,rgba(18,32,44,0.9),rgba(8,14,20,0.95))] p-2.5">
                <p
                  className="font-minecraft text-[8px] font-bold tracking-[0.1em]"
                  style={{ color: hud.textColor, opacity: hud.widgets.moduleList ? 1 : 0.45 }}
                >
                  MODULES
                </p>
                <div className="mt-1 space-y-0.5" style={{ opacity: hud.widgets.moduleList ? hud.moduleOpacity : 0.3 }}>
                  {activeModules.length === 0 ? (
                    <p className="font-minecraft text-[7.5px] text-white/45">No active modules</p>
                  ) : (
                    activeModules.slice(0, 6).map((name) => (
                      <p key={name} className="font-minecraft text-[7.5px]" style={{ color: hud.textColor }}>
                        › {name}
                      </p>
                    ))
                  )}
                </div>
                <div className="mt-2 flex items-center justify-between border-t border-white/8 pt-1.5">
                  <span className="font-mono text-[7px] text-white/40">
                    scale {hud.moduleScale.toFixed(2)}x · X{hud.moduleX} Y{hud.moduleY}
                  </span>
                  <span
                    className={cn(
                      "rounded border px-1 py-px font-mono text-[7px]",
                      hud.widgets.moduleList
                        ? "border-[rgba(var(--acc-rgb),0.35)] text-[#c8ffd3]"
                        : "border-white/12 text-white/45",
                    )}
                  >
                    {hud.widgets.moduleList ? "VISIBLE" : "HIDDEN"}
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setWidget("moduleList", !hud.widgets.moduleList)}
                className="btn-ghost mb-1 w-full !h-7"
              >
                {hud.widgets.moduleList ? "Скрыть плашку" : "Показать плашку"}
              </button>
            </SectionCard>

            <SectionCard
              title="Активные модули"
              icon={<Activity size={12} className="text-[var(--acc)]" />}
              action={
                <button type="button" onClick={onOpenModules} className="text-[8.5px] font-bold text-[var(--acc)] hover:underline">
                  управлять
                </button>
              }
            >
              <div className="py-1">
                {activeModules.length === 0 ? (
                  <p className="rounded-md border border-dashed border-white/10 px-2 py-3 text-center text-[9px] text-[#5f7e69]">
                    No active modules
                  </p>
                ) : (
                  <div className="flex flex-wrap gap-1">
                    {activeModules.map((name) => (
                      <span key={name} className="chip chip-accent">
                        <span className="h-1 w-1 rounded-full bg-[var(--acc)]" />
                        {name}
                      </span>
                    ))}
                  </div>
                )}
                <p className="mt-2 flex items-start gap-1.5 text-[8.5px] leading-relaxed text-[#5f7e69]">
                  <Info size={9} className="mt-px shrink-0" />
                  China Hat и Trail добавляются в список, когда включены в Visuals.
                </p>
              </div>
            </SectionCard>
          </>
        )}
      </div>

    </div>
  );
}

export function VisualsPanel({
  visuals,
  onChange,
  compact = false,
}: {
  visuals: VisualSettings;
  onChange: (patch: Partial<VisualSettings>) => void;
  compact?: boolean;
}) {
  const hat = visuals.hat;
  const trail = visuals.trail;
  const setHat = (patch: Partial<HatSettings>) => onChange({ hat: { ...hat, ...patch } });
  const setTrail = (patch: Partial<TrailSettings>) => onChange({ trail: { ...trail, ...patch } });

  return (
    <div className="space-y-2.5">
      <SectionCard
        title="China Hat"
        icon={<Triangle size={12} className="text-[var(--acc)]" />}
        action={<span className="chip !px-1.5 !py-0 !text-[7px]">test</span>}
      >
        <div className="divide-y divide-white/5">
          <ToggleRow
            icon={<Triangle size={12} />}
            title="Включить China Hat"
            hint="Конус над локальным игроком"
            checked={hat.enabled}
            onChange={(value) => setHat({ enabled: value })}
          />
          <ToggleRow
            icon={<Waves size={12} />}
            title="Заливка конуса"
            hint="Заполнение внутри контура"
            checked={hat.fill}
            onChange={(value) => setHat({ fill: value })}
            disabled={!hat.enabled}
          />
          <ToggleRow
            icon={<WandSparkles size={12} />}
            title="Радуга"
            hint="Переливание вместо своего цвета"
            checked={hat.rainbow}
            onChange={(value) => setHat({ rainbow: value })}
            disabled={!hat.enabled}
          />
        </div>
        {!hat.rainbow && (
          <div className="flex items-center justify-between gap-2 border-t border-white/5 py-1.5">
            <span className="text-[10.5px] font-semibold text-[#d6ecdd]">Цвет шляпы</span>
            <ColorDots
              colors={[hat.color, "#6dff87", "#59d8ff", "#ffd75e", "#ff8e8e", "#c9a7ff"]}
              value={hat.color}
              onChange={(color) => setHat({ color })}
            />
          </div>
        )}
        <div className={cn("border-t border-white/5", !hat.enabled && "opacity-45")}>
          {hat.rainbow ? (
            <Slider
              label="Скорость радуги"
              icon={<WandSparkles size={12} />}
              value={hat.rainbowSpeed}
              min={0.1}
              max={2}
              step={0.05}
              format={(value) => `${value.toFixed(2)}`}
              onChange={(value) => setHat({ rainbowSpeed: value })}
            />
          ) : null}
          <Slider
            label="Прозрачность (test)"
            icon={<Eye size={12} />}
            value={hat.opacity}
            min={0}
            max={1}
            step={0.01}
            format={(value) => `${value.toFixed(2)}`}
            onChange={(value) => setHat({ opacity: value })}
          />
          <Slider
            label="Радиус"
            icon={<Maximize2 size={12} />}
            value={hat.radius}
            min={0.1}
            max={1}
            step={0.01}
            format={(value) => value.toFixed(2)}
            onChange={(value) => setHat({ radius: value })}
          />
          <Slider
            label="Высота конуса"
            icon={<Triangle size={12} />}
            value={hat.coneHeight}
            min={0.1}
            max={2}
            step={0.01}
            format={(value) => value.toFixed(2)}
            onChange={(value) => setHat({ coneHeight: value })}
          />
          <Slider
            label="Смещение"
            icon={<Move size={12} className="rotate-90" />}
            value={hat.offset}
            min={-0.5}
            max={0.8}
            step={0.01}
            format={(value) => value.toFixed(2)}
            onChange={(value) => setHat({ offset: value })}
          />
          <Slider
            label="Амплитуда покачивания"
            icon={<Waves size={12} />}
            value={hat.floatAmount}
            min={0}
            max={0.3}
            step={0.005}
            format={(value) => value.toFixed(3)}
            onChange={(value) => setHat({ floatAmount: value })}
          />
          <Slider
            label="Скорость покачивания"
            icon={<Activity size={12} />}
            value={hat.floatSpeed}
            min={0.1}
            max={3}
            step={0.05}
            format={(value) => value.toFixed(2)}
            onChange={(value) => setHat({ floatSpeed: value })}
          />
        </div>
        <p className="border-t border-white/5 pt-1.5 pb-1 text-[8.5px] leading-relaxed text-[#5f7e69]">
          {hat.enabled ? "Hat: waiting for player · 48 сегментов, 12 спиц" : "Hat выключена"}
        </p>
      </SectionCard>

      <SectionCard
        title="Trail"
        icon={<Waves size={12} className="text-[var(--acc)]" />}
        action={<span className="chip !px-1.5 !py-0 !text-[7px]">test</span>}
      >
        <div className="divide-y divide-white/5">
          <ToggleRow
            icon={<Waves size={12} />}
            title="Включить Trail"
            hint="Лента за игроком"
            checked={trail.enabled}
            onChange={(value) => setTrail({ enabled: value })}
          />
          <ToggleRow
            icon={<Layers size={12} />}
            title="Заливка ленты"
            hint="Линия и заполнение"
            checked={trail.fill}
            onChange={(value) => setTrail({ fill: value })}
            disabled={!trail.enabled}
          />
          <ToggleRow
            icon={<WandSparkles size={12} />}
            title="Радужный след"
            checked={trail.rainbow}
            onChange={(value) => setTrail({ rainbow: value })}
            disabled={!trail.enabled}
          />
        </div>
        {!trail.rainbow && (
          <div className="flex items-center justify-between gap-2 border-t border-white/5 py-1.5">
            <span className="text-[10.5px] font-semibold text-[#d6ecdd]">Цвет следа</span>
            <ColorDots
              colors={[trail.color, "#6dff87", "#59d8ff", "#ffd75e", "#ff8e8e", "#c9a7ff"]}
              value={trail.color}
              onChange={(color) => setTrail({ color })}
            />
          </div>
        )}
        <div className={cn("border-t border-white/5", !trail.enabled && "opacity-45")}>
          {trail.rainbow ? (
            <Slider
              label="Скорость радуги"
              icon={<WandSparkles size={12} />}
              value={trail.rainbowSpeed}
              min={0.1}
              max={2}
              step={0.05}
              format={(value) => value.toFixed(2)}
              onChange={(value) => setTrail({ rainbowSpeed: value })}
            />
          ) : null}
          <Slider
            label="Прозрачность (test)"
            icon={<Eye size={12} />}
            value={trail.opacity}
            min={0}
            max={1}
            step={0.01}
            format={(value) => value.toFixed(2)}
            onChange={(value) => setTrail({ opacity: value })}
          />
          <Slider
            label="Высота следа"
            icon={<Move size={12} className="rotate-90" />}
            value={trail.height}
            min={0}
            max={1}
            step={0.01}
            format={(value) => value.toFixed(2)}
            onChange={(value) => setTrail({ height: value })}
          />
          <Slider
            label="Время жизни"
            icon={<Clock3 size={12} />}
            value={trail.lifetime}
            min={0.2}
            max={5}
            step={0.1}
            format={(value) => `${value.toFixed(1)} с`}
            onChange={(value) => setTrail({ lifetime: value })}
          />
        </div>
        <p className="border-t border-white/5 pt-1.5 pb-1 text-[8.5px] leading-relaxed text-[#5f7e69]">
          {trail.enabled ? "Trail: move to create trail · история до 128 точек" : "Trail выключен"}
        </p>
      </SectionCard>

      {!compact && (
        <SectionCard title="Options" icon={<ScanEye size={12} className="text-[var(--acc)]" />}>
          <ToggleRow
            icon={<Palette size={12} />}
            title="Enable colors"
            hint="Пользовательские цвета эффектов"
            checked={visuals.enableColors}
            onChange={(value) => onChange({ enableColors: value })}
          />
          <ToggleRow
            icon={<Sparkles size={12} />}
            title="Vertex gradient (test)"
            hint="Разные цвета вершин; зависит от материала игры"
            checked={visuals.vertexGradient}
            onChange={(value) => onChange({ vertexGradient: value })}
            badge="test"
          />
          <div className="mt-1 rounded-md border border-white/7 bg-black/30 px-2 py-1.5 font-mono text-[8px] leading-relaxed text-[#688a74]">
            <p>Before UI: DSV bound, depth on, blend on</p>
            <p>After UI: DSV none, depth off, blend on</p>
            <p className="mt-1 text-[7px] text-[#4c6855]">Diagnostics only; not proof of valid scene depth.</p>
          </div>
        </SectionCard>
      )}
    </div>
  );
}
