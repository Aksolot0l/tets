import {
  Activity,
  BadgeCheck,
  BarChart3,
  Boxes,
  Check,
  ChevronDown,
  Clock3,
  Copy,
  Cpu,
  Download,
  Gauge,
  Info,
  Layers,
  MonitorCog,
  Plus,
  Radar,
  Save,
  Search,
  SlidersHorizontal,
  Sparkles,
  Trash2,
  Triangle,
  Zap,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { statsSeries } from "../lib/data";
import type { GameModule, HudPreset, HudSettings, Toast, VisualSettings } from "../lib/types";
import { cn } from "../utils/cn";
import {
  EmptyState,
  Modal,
  PageTitle,
  SectionCard,
  Toggle,
} from "./ui";

type Notify = (title: string, description?: string, tone?: Toast["tone"]) => void;

const positionLabel: Record<HudSettings["position"], string> = {
  "top-left": "сверху слева",
  "top-right": "сверху справа",
  "bottom-left": "снизу слева",
  "bottom-right": "снизу справа",
  custom: "своя позиция",
};

const widgetShort: Record<keyof HudSettings["widgets"], string> = {
  fps: "FPS",
  cps: "CPS",
  keys: "Keys",
  clock: "Clock",
  watermark: "Watermark",
  coordinates: "Coords",
  performance: "CPU/RAM",
  moduleList: "Modules",
};

export function ModsPage({
  modules,
  onToggle,
  visuals,
  onOpenVisuals,
}: {
  modules: GameModule[];
  onToggle: (id: string) => void;
  visuals: VisualSettings;
  onOpenVisuals: () => void;
}) {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<"Все" | GameModule["category"]>("Все");

  const filtered = modules.filter((module) => {
    const matchesCategory = category === "Все" || module.category === category;
    const needle = query.trim().toLowerCase();
    const matchesQuery =
      !needle ||
      module.name.toLowerCase().includes(needle) ||
      module.description.toLowerCase().includes(needle);
    return matchesCategory && matchesQuery;
  });
  const enabled = modules.filter((module) => module.enabled).length;
  const activeList = [
    ...modules.filter((module) => module.enabled).map((module) => module.name),
    ...(visuals.hat.enabled ? ["China Hat"] : []),
    ...(visuals.trail.enabled ? ["Trail"] : []),
  ];

  return (
    <div className="animate-fade-up space-y-3">
      <PageTitle
        eyebrow="Библиотека"
        title="Моды и модули"
        description="Список активных модулей формирует плашку MODULES в HUD. China Hat и Trail добавляются из Visuals автоматически."
        action={
          <span className="chip chip-accent">
            <Activity size={10} />
            активно {enabled} из {modules.length}
          </span>
        }
      />

      <div className="grid gap-3 xl:grid-cols-[minmax(0,1.4fr)_minmax(0,0.6fr)]">
        <div className="panel overflow-hidden">
          <div className="flex flex-wrap items-center gap-2 border-b border-white/6 p-3">
            <div className="relative min-w-[180px] flex-1">
              <Search size={13} className="pointer-events-none absolute top-1/2 left-2.5 -translate-y-1/2 text-[#5f7d69]" />
              <input
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Поиск модуля…"
                aria-label="Поиск модулей"
                className="h-8 w-full rounded-lg border border-white/8 bg-black/25 pr-3 pl-8 text-[11px] text-[#e4f5ea] placeholder:text-[#5b7665] focus:border-[rgba(var(--acc-rgb),0.5)] focus:outline-none"
              />
            </div>
            <div className="flex gap-1">
              {(["Все", "HUD", "Визуал", "Утилиты"] as const).map((item) => (
                <button
                  key={item}
                  type="button"
                  onClick={() => setCategory(item)}
                  aria-pressed={category === item}
                  className={cn(
                    "rounded-md border px-2 py-1.5 text-[9px] font-bold transition-colors",
                    category === item
                      ? "border-[rgba(var(--acc-rgb),0.35)] bg-[rgba(var(--acc-rgb),0.11)] text-[#dbffe3]"
                      : "border-white/7 bg-white/[0.02] text-[#75927f] hover:text-[#d5eadb]",
                  )}
                >
                  {item}
                </button>
              ))}
            </div>
          </div>

          <div className="scroll max-h-[520px] divide-y divide-white/5 overflow-y-auto">
            {filtered.map((module) => (
              <div key={module.id} className="flex items-center gap-3 px-3 py-2.5 transition-colors hover:bg-white/[0.015]">
                <span
                  className={cn(
                    "flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border",
                    module.enabled
                      ? "border-[rgba(var(--acc-rgb),0.3)] bg-[rgba(var(--acc-rgb),0.1)] text-[var(--acc)]"
                      : "border-white/8 bg-white/4 text-[#6f8d7a]",
                  )}
                >
                  {module.category === "Визуал" ? <Triangle size={14} /> : module.category === "HUD" ? <MonitorCog size={14} /> : <Zap size={14} />}
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5">
                    <p className="truncate text-[11.5px] font-bold text-[#e6f7ea]">{module.name}</p>
                    <span className="rounded border border-white/8 bg-white/4 px-1 py-px text-[7px] font-bold tracking-wide text-[#7f9d89] uppercase">
                      {module.category}
                    </span>
                  </div>
                  <p className="mt-0.5 truncate text-[9.5px] text-[#6d8b78]">{module.description}</p>
                </div>
                <kbd className="rounded-md border border-white/8 bg-black/25 px-1.5 py-0.5 font-mono text-[8px] text-[#9ab8a4]">
                  {module.bind}
                </kbd>
                <Toggle
                  checked={module.enabled}
                  onChange={() => onToggle(module.id)}
                  label={`Модуль ${module.name}`}
                />
              </div>
            ))}
            {filtered.length === 0 && (
              <div className="p-4">
                <EmptyState
                  icon={<Search size={18} />}
                  title="Модули не найдены"
                  description="Измените запрос или категорию."
                  action={
                    <button type="button" onClick={() => { setQuery(""); setCategory("Все"); }} className="btn-ghost">
                      Сбросить фильтр
                    </button>
                  }
                />
              </div>
            )}
          </div>
        </div>

        <div className="space-y-3">
          <SectionCard title="Плашка MODULES" icon={<Layers size={12} className="text-[var(--acc)]" />}>
            <div className="flex flex-wrap gap-1 py-1.5">
              {activeList.length ? (
                activeList.map((name) => (
                  <span key={name} className="chip chip-accent">
                    <span className="h-1 w-1 rounded-full bg-[var(--acc)]" />
                    {name}
                  </span>
                ))
              ) : (
                <span className="text-[9.5px] text-[#6d8b78]">No active modules</span>
              )}
            </div>
            <div className="mt-1 rounded-md border border-white/7 bg-black/25 px-2 py-1.5 font-minecraft text-[8px] leading-relaxed text-[#78e3a0]">
              <p className="mb-1 text-[7px] tracking-[0.12em] text-white/70">MODULES</p>
              {activeList.length ? (
                activeList.map((name) => <p key={name}>› {name}</p>)
              ) : (
                <p className="opacity-50">No active modules</p>
              )}
            </div>
            <p className="mt-1.5 flex items-start gap-1.5 text-[8.5px] leading-relaxed text-[#5f7d69]">
              <Info size={9} className="mt-px shrink-0" />
              Плашка дублирует старый Active Modules. Её видимость и позиция — во вкладке HUD →
              Модули.
            </p>
          </SectionCard>
          <SectionCard title="Visuals" icon={<Triangle size={12} className="text-[var(--acc)]" />}>
            <p className="py-1 text-[9px] leading-relaxed text-[#86a292]">
              Конус и след настраиваются отдельно и появляются в списке, когда включены.
            </p>
            <button type="button" onClick={onOpenVisuals} className="btn-ghost mt-1 !h-7">
              Открыть Visuals
              <ChevronDown size={11} className="-rotate-90" />
            </button>
          </SectionCard>
        </div>
      </div>
    </div>
  );
}

export function ProfilesPage({
  hud,
  presets,
  onSave,
  onApply,
  onDelete,
  notify,
}: {
  hud: HudSettings;
  presets: HudPreset[];
  onSave: (name: string) => void;
  onApply: (preset: HudPreset) => void;
  onDelete: (id: string) => void;
  notify: Notify;
}) {
  const [saveOpen, setSaveOpen] = useState(false);
  const [name, setName] = useState("");
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (saveOpen) window.setTimeout(() => inputRef.current?.focus(), 80);
  }, [saveOpen]);

  const currentChips = Object.entries(hud.widgets)
    .filter(([, value]) => value)
    .map(([key]) => widgetShort[key as keyof HudSettings["widgets"]]);

  const exportPreset = (preset: HudPreset) => {
    const blob = new Blob([JSON.stringify({ ...preset, format: "gayclient-hud-preset" }, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `${preset.name.replace(/\s+/g, "-").toLowerCase()}.json`;
    anchor.click();
    URL.revokeObjectURL(url);
    notify("Профиль выгружен", `«${preset.name}» сохранён в JSON.`, "success");
  };

  return (
    <div className="animate-fade-up space-y-3">
      <PageTitle
        eyebrow="Пресеты"
        title="Профили HUD"
        description="Сохраняйте сборки HUD и Visuals целиком. В нативном клиенте новые параметры плашки живут только до закрытия игры — здесь прототип хранит их локально."
        action={
          <button
            type="button"
            onClick={() => {
              setName(`HUD ${presets.length + 1}`);
              setSaveOpen(true);
            }}
            className="btn-solid"
          >
            <Plus size={14} />
            Сохранить текущий
          </button>
        }
      />

      <div className="panel p-4">
        <div className="flex flex-wrap items-center gap-3">
          <span className="icon-tile h-10 w-10 shrink-0">
            <MonitorCog size={17} />
          </span>
          <div className="min-w-[150px] flex-1">
            <p className="text-[9px] font-extrabold tracking-[0.16em] text-[#6f8d7a] uppercase">Текущая конфигурация</p>
            <h3 className="mt-1 font-display text-[15px] text-[#f0fff4]">HUD · {positionLabel[hud.position]}</h3>
            <div className="mt-1.5 flex flex-wrap gap-1">
              {currentChips.length ? (
                currentChips.map((chip) => <span key={chip} className="chip chip-accent">{chip}</span>)
              ) : (
                <span className="text-[9px] text-[#6d8b78]">Виджеты не выбраны</span>
              )}
            </div>
          </div>
          <div className="grid w-full grid-cols-3 gap-2 text-center sm:w-auto">
            {[
              { label: "scale", value: `${hud.scale.toFixed(2)}x` },
              { label: "opacity", value: `${Math.round(hud.opacity * 100)}%` },
              { label: "positions", value: `X${hud.x} Y${hud.y}` },
            ].map((metric) => (
              <div key={metric.label} className="rounded-lg border border-white/7 bg-black/25 px-2 py-1.5">
                <p className="font-mono text-[9px] font-bold text-[#d9efdf]">{metric.value}</p>
                <p className="mt-0.5 text-[7px] tracking-wide text-[#5f7d69] uppercase">{metric.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {presets.length === 0 ? (
        <EmptyState
          icon={<Save size={18} />}
          title="Пока нет сохранённых профилей"
          description="Настройте HUD и нажмите «Сохранить текущий», чтобы вернуться к этой сборке позже."
          action={
            <button type="button" onClick={() => setSaveOpen(true)} className="btn-primary !h-8">
              <Plus size={12} /> Создать профиль
            </button>
          }
        />
      ) : (
        <div className="grid gap-2.5 sm:grid-cols-2 xl:grid-cols-3">
          {presets.map((preset) => {
            const chips = Object.entries(preset.hud.widgets)
              .filter(([, value]) => value)
              .map(([key]) => widgetShort[key as keyof HudSettings["widgets"]]);
            return (
              <article key={preset.id} className="panel flex flex-col overflow-hidden">
                <div className="flex items-start gap-2.5 p-3">
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-[rgba(var(--acc-rgb),0.25)] bg-[rgba(var(--acc-rgb),0.08)] text-[var(--acc)]">
                    <MonitorCog size={15} />
                  </span>
                  <div className="min-w-0 flex-1">
                    <h3 className="truncate text-[11.5px] font-bold text-[#e8f9ed]">{preset.name}</h3>
                    <p className="mt-0.5 font-mono text-[8px] text-[#6d8b78]">
                      {preset.createdAt} · {preset.hud.scale.toFixed(2)}x
                    </p>
                  </div>
                  <span className="chip !px-1.5 !py-0 !text-[7.5px]">{positionLabel[preset.hud.position]}</span>
                </div>
                <div className="flex flex-wrap gap-1 px-3 pb-2">
                  {chips.slice(0, 5).map((chip) => (
                    <span key={chip} className="chip !px-1.5 !py-0 !text-[8px]">{chip}</span>
                  ))}
                  {chips.length === 0 && <span className="text-[8px] text-[#607d6b]">пустой HUD</span>}
                  {chips.length > 5 && <span className="chip !px-1.5 !py-0 !text-[8px]">+{chips.length - 5}</span>}
                </div>
                <div className="mt-auto flex items-center gap-1 border-t border-white/5 bg-black/15 px-2.5 py-2">
                  <button
                    type="button"
                    onClick={() => onApply(preset)}
                    className="btn-primary !h-7 flex-1 !text-[9.5px]"
                  >
                    <Check size={11} />
                    Применить
                  </button>
                  <button type="button" onClick={() => exportPreset(preset)} aria-label={`Экспорт ${preset.name}`} className="btn-ghost !h-7 !w-7 !px-0">
                    <Download size={11} />
                  </button>
                  <button type="button" onClick={() => setDeleteId(preset.id)} aria-label={`Удалить ${preset.name}`} className="btn-ghost !h-7 !w-7 !px-0 !text-red-300/80 hover:!border-red-400/30">
                    <Trash2 size={11} />
                  </button>
                </div>
              </article>
            );
          })}
        </div>
      )}

      <div className="flex items-start gap-2 rounded-lg border border-white/7 bg-white/[0.02] px-3 py-2 text-[9px] leading-relaxed text-[#6d8b78]">
        <Info size={11} className="mt-px shrink-0" />
        Профиль хранит HUD, положение плашки модулей и оба 3D-эффекта. Параметры старых HUD-виджетов
        ядра сюда не входят.
      </div>

      <Modal
        open={saveOpen}
        onClose={() => setSaveOpen(false)}
        title="Сохранить профиль HUD"
        description="Снимок текущих виджетов, масштаба, позиции и Visuals."
        icon={<Save size={16} />}
        footer={
          <>
            <button type="button" onClick={() => setSaveOpen(false)} className="btn-ghost !h-9">Отмена</button>
            <button
              type="button"
              disabled={!name.trim()}
              onClick={() => {
                onSave(name.trim());
                setSaveOpen(false);
                setName("");
              }}
              className="btn-primary !h-9"
            >
              <Save size={12} /> Сохранить
            </button>
          </>
        }
      >
        <label className="block">
          <span className="mb-1.5 block text-[9px] font-bold tracking-wider text-[#7f9d89] uppercase">Название профиля</span>
          <input
            ref={inputRef}
            value={name}
            maxLength={64}
            onChange={(event) => setName(event.target.value)}
            placeholder="Например, PvP минимал"
            className="h-9 w-full rounded-lg border border-white/10 bg-black/30 px-3 text-[11.5px] text-[#e6f7ea] focus:border-[rgba(var(--acc-rgb),0.55)] focus:outline-none"
          />
        </label>
        <div className="mt-2 flex flex-wrap gap-1">
          {Object.entries(hud.widgets)
            .filter(([, value]) => value)
            .map(([key]) => (
              <span key={key} className="chip chip-accent !text-[8px]">{widgetShort[key as keyof HudSettings["widgets"]]}</span>
            ))}
        </div>
      </Modal>

      <Modal
        open={Boolean(deleteId)}
        onClose={() => setDeleteId(null)}
        title="Удалить профиль?"
        description="Настройки HUD не изменятся — удалится только сохранённая копия."
        icon={<Trash2 size={16} />}
        footer={
          <>
            <button type="button" onClick={() => setDeleteId(null)} className="btn-ghost !h-9">Отмена</button>
            <button
              type="button"
              onClick={() => {
                if (deleteId) onDelete(deleteId);
                setDeleteId(null);
              }}
              className="btn-primary !h-9 !border-red-300/40"
            >
              <Trash2 size={12} /> Удалить
            </button>
          </>
        }
      />
    </div>
  );
}

export function StatsPage({
  hud,
  modules,
  visuals,
  moduleCount,
}: {
  hud: HudSettings;
  modules: GameModule[];
  visuals: VisualSettings;
  moduleCount: number;
}) {
  const [range, setRange] = useState<"7" | "30">("7");
  const data = statsSeries[range];
  const max = Math.max(...data.values);
  const activeModules = modules.filter((module) => module.enabled).length;
  const enabledWidgets = Object.values(hud.widgets).filter(Boolean).length;

  const health = useMemo(
    () => [
      { label: "Отрисовка HUD", value: enabledWidgets > 0 ? "активна" : "off", ok: enabledWidgets > 0, icon: MonitorCog },
      { label: "Список модулей", value: hud.widgets.moduleList ? "виден" : "скрыт", ok: hud.widgets.moduleList, icon: Layers },
      { label: "China Hat", value: visuals.hat.enabled ? "вкл." : "выкл.", ok: visuals.hat.enabled, icon: Triangle },
      { label: "Trail", value: visuals.trail.enabled ? "вкл." : "выкл.", ok: visuals.trail.enabled, icon: Activity },
    ],
    [enabledWidgets, hud.widgets.moduleList, visuals.hat.enabled, visuals.trail.enabled],
  );

  return (
    <div className="animate-fade-up space-y-3">
      <PageTitle
        eyebrow="Метрики"
        title="Статистика HUD"
        description="Демонстрационные метрики прототипа: реальные FPS, задержка и журнал игры здесь не читаются."
        action={
          <div className="flex rounded-lg border border-white/8 bg-black/25 p-0.5" role="group" aria-label="Период">
            {(["7", "30"] as const).map((item) => (
              <button
                key={item}
                type="button"
                onClick={() => setRange(item)}
                aria-pressed={range === item}
                className={cn(
                  "rounded-md px-3 py-1.5 text-[9.5px] font-bold transition-colors",
                  range === item
                    ? "bg-[rgba(var(--acc-rgb),0.14)] text-[#dfffe6] shadow-[inset_0_0_0_1px_rgba(var(--acc-rgb),0.24)]"
                    : "text-[#75927f] hover:text-[#d6e9dc]",
                )}
              >
                {item === "7" ? "7 дней" : "30 дней"}
              </button>
            ))}
          </div>
        }
      />

      <div className="grid gap-2.5 sm:grid-cols-2 xl:grid-cols-4">
        {[
          { label: "Средний FPS", value: "144", hint: "±2 в превью", icon: BarChart3 },
          { label: "Виджетов", value: `${enabledWidgets} / 8`, hint: "включено", icon: SlidersHorizontal },
          { label: "Модулей", value: String(activeModules + (visuals.hat.enabled ? 1 : 0) + (visuals.trail.enabled ? 1 : 0)), hint: `в каталоге ${moduleCount}`, icon: Boxes },
          { label: "Масштаб HUD", value: `${hud.scale.toFixed(2)}x`, hint: "в пределах 0.70–1.60", icon: Gauge },
        ].map((metric) => {
          const Icon = metric.icon;
          return (
            <div key={metric.label} className="panel flex items-center gap-3 p-3.5">
              <span className="icon-tile">
                <Icon size={14} />
              </span>
              <div>
                <p className="text-[8px] font-extrabold tracking-[0.16em] text-[#688574] uppercase">{metric.label}</p>
                <p className="mt-1 font-display text-[15px] leading-none text-[#f0fff4]">{metric.value}</p>
                <p className="mt-1 text-[8.5px] text-[#607d6b]">{metric.hint}</p>
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid gap-3 xl:grid-cols-[minmax(0,1.4fr)_minmax(0,0.6fr)]">
        <div className="panel p-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <p className="text-[10.5px] font-bold text-[#e4f6e9]">Активность редактора</p>
              <p className="mt-0.5 text-[9px] text-[#6d8b78]">Условные минуты настройки HUD по дням</p>
            </div>
            <span className="chip chip-accent">
              <Activity size={9} />
              демо-данные
            </span>
          </div>
          <div className="mt-3 flex h-[186px] items-end gap-1.5 sm:gap-2.5">
            {data.values.map((value, index) => (
              <div key={index} className="group flex h-full flex-1 flex-col justify-end gap-1">
                <span className="text-center font-mono text-[7.5px] text-[#607d6b] opacity-0 transition-opacity group-hover:opacity-100">
                  {value}
                </span>
                <div
                  className="w-full rounded-t-[3px] border border-b-0 border-[rgba(var(--acc-rgb),0.25)] bg-[linear-gradient(180deg,rgba(var(--acc-rgb),0.5),rgba(var(--acc-rgb),0.08))] transition-all duration-300 group-hover:border-[rgba(var(--acc-rgb),0.55)] group-hover:bg-[linear-gradient(180deg,rgba(var(--acc-rgb),0.7),rgba(var(--acc-rgb),0.16))]"
                  style={{ height: `${(value / max) * 100}%` }}
                />
                <span className="text-center font-mono text-[7.5px] text-[#5f7d69]">{data.labels[index]}</span>
              </div>
            ))}
          </div>
          <div className="mt-2 flex items-center justify-between border-t border-white/5 pt-2 text-[8.5px] text-[#607d6b]">
            <span className="flex items-center gap-1"><Clock3 size={9} /> сессия 42 мин</span>
            <span className="flex items-center gap-1"><Cpu size={9} /> CPU клиента 11%</span>
            <span className="flex items-center gap-1"><Radar size={9} /> легенда условная</span>
          </div>
        </div>

        <div className="space-y-3">
          <SectionCard title="Состояние HUD" icon={<BadgeCheck size={12} className="text-[var(--acc)]" />}>
            <div className="py-0.5">
              {health.map((item) => {
                const Icon = item.icon;
                return (
                  <div key={item.label} className="flex items-center gap-2 border-b border-white/4 py-1.5 last:border-0">
                    <Icon size={10} className="text-[#72907d]" />
                    <span className="flex-1 text-[9.5px] text-[#a5c0ae]">{item.label}</span>
                    <span
                      className={cn(
                        "flex items-center gap-1 font-mono text-[8px]",
                        item.ok ? "text-[var(--acc)]" : "text-[#5f7d69]",
                      )}
                    >
                      <span className={cn("h-1 w-1 rounded-full", item.ok ? "bg-[var(--acc)]" : "bg-[#607d6b]")} />
                      {item.value}
                    </span>
                  </div>
                );
              })}
            </div>
          </SectionCard>
          <SectionCard title="Позиция и масштаб" icon={<Radar size={12} className="text-[var(--acc)]" />}>
            <div className="relative my-1 h-20 overflow-hidden rounded-md border border-white/8 bg-black/25">
              <div className="absolute inset-0 opacity-40 [background-image:linear-gradient(rgba(109,255,135,.12)_1px,transparent_1px),linear-gradient(90deg,rgba(109,255,135,.12)_1px,transparent_1px)] [background-size:16px_16px]" />
              <span
                className="absolute h-3 w-7 rounded-[2px] border border-[rgba(var(--acc-rgb),0.6)] bg-[rgba(var(--acc-rgb),0.25)] shadow-[0_0_8px_rgba(var(--acc-rgb),0.4)]"
                style={{ left: `${Math.min(84, hud.x)}%`, top: `${Math.min(74, hud.y)}%` }}
              />
              <span className="absolute right-1.5 bottom-1 font-mono text-[7px] text-[#5f7d69]">
                X {hud.x}% · Y {hud.y}%
              </span>
            </div>
            <p className="flex items-start gap-1.5 text-[8.5px] leading-relaxed text-[#5f7d69]">
              <Info size={9} className="mt-px shrink-0" />
              Координаты отрисовки берутся из настроек плашки. Старые виджеты используют свои позиции.
            </p>
          </SectionCard>
        </div>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-white/7 bg-white/[0.02] px-3 py-2 text-[8.5px] text-[#6d8b78]">
        <span className="flex items-center gap-1.5">
          <Info size={10} />
          FPS-график и сессии условные. Реальные значения требуют нативного клиента и журнала игры.
        </span>
        <span className="flex items-center gap-1.5 font-mono">
          <Save size={9} /> profiles: {moduleCount} modules
        </span>
      </div>
    </div>
  );
}

export const tabIcons = { Sparkles, SlidersHorizontal, Copy };
