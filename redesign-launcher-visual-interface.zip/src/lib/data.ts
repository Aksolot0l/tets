import type {
  GameModule,
  HatSettings,
  HudSettings,
  InterfaceSettings,
  SoundSettings,
  TrailSettings,
  VisualSettings,
} from "./types";

export const APP_VERSION = "1.5.0";

export const defaultHud: HudSettings = {
  widgets: {
    fps: true,
    cps: true,
    keys: false,
    clock: true,
    watermark: false,
    coordinates: false,
    performance: false,
    moduleList: false,
  },
  scale: 1,
  opacity: 0.78,
  padding: 8,
  gap: 4,
  textColor: "#5fd8ff",
  position: "top-right",
  x: 79,
  y: 5,
  moduleScale: 1,
  moduleOpacity: 0.78,
  moduleX: 76,
  moduleY: 52,
  showHearts: true,
  showHotbar: true,
};

export const defaultHat: HatSettings = {
  enabled: false,
  fill: true,
  rainbow: false,
  color: "#6dff87",
  rainbowSpeed: 0.6,
  opacity: 1,
  radius: 0.45,
  coneHeight: 0.8,
  offset: 0.1,
  floatAmount: 0.06,
  floatSpeed: 1,
};

export const defaultTrail: TrailSettings = {
  enabled: false,
  fill: true,
  rainbow: false,
  color: "#6dff87",
  rainbowSpeed: 0.6,
  opacity: 0.8,
  height: 0.35,
  lifetime: 1.5,
};

export const defaultVisuals: VisualSettings = {
  hat: defaultHat,
  trail: defaultTrail,
  vertexGradient: false,
  enableColors: true,
};

export const defaultInterface: InterfaceSettings = {
  accent: "neon",
  density: "comfortable",
  animations: true,
  glow: true,
  language: "ru",
  uiScale: 1,
};

export const defaultSound: SoundSettings = {
  master: 70,
  interface: 55,
  effects: 60,
  muted: false,
};

export const accentThemes = [
  {
    id: "neon" as const,
    name: "Неон",
    description: "Классический лаймово-зелёный",
    accent: "#6dff87",
    accent2: "#b9ff62",
    deep: "#1f8f45",
    rgb: "109, 255, 135",
    swatch: "linear-gradient(135deg, #b9ff62, #2fbf5f)",
  },
  {
    id: "lime" as const,
    name: "Кислота",
    description: "Яркий жёлто-зелёный",
    accent: "#b6ff4d",
    accent2: "#e6ff8a",
    deep: "#6a9e17",
    rgb: "182, 255, 77",
    swatch: "linear-gradient(135deg, #e6ff8a, #9bdc25)",
  },
  {
    id: "mint" as const,
    name: "Мята",
    description: "Холодный бирюзовый",
    accent: "#57f0c0",
    accent2: "#b8ffe6",
    deep: "#1a9c78",
    rgb: "87, 240, 192",
    swatch: "linear-gradient(135deg, #b8ffe6, #35d7a4)",
  },
  {
    id: "cyan" as const,
    name: "Кибер",
    description: "Голубой акцент HUD",
    accent: "#59d8ff",
    accent2: "#b5efff",
    deep: "#1b7fa8",
    rgb: "89, 216, 255",
    swatch: "linear-gradient(135deg, #b5efff, #35b6e8)",
  },
];

export const hudTextColors = ["#5fd8ff", "#6dff87", "#ffffff", "#ffd75e", "#ff8e8e", "#c9a7ff"];

export const hudPositions = [
  { id: "top-left" as const, label: "Сверху слева" },
  { id: "top-right" as const, label: "Сверху справа" },
  { id: "bottom-left" as const, label: "Снизу слева" },
  { id: "bottom-right" as const, label: "Снизу справа" },
  { id: "custom" as const, label: "Своя позиция" },
];

export const widgetLabels: Record<keyof HudSettings["widgets"], string> = {
  fps: "Показывать FPS",
  cps: "Показывать CPS",
  keys: "Показывать нажатые клавиши",
  clock: "Показывать часы",
  watermark: "Водяной знак",
  coordinates: "Координаты",
  performance: "CPU / RAM",
  moduleList: "Плашка модулей",
};

export const widgetDescriptions: Record<keyof HudSettings["widgets"], string> = {
  fps: "Счётчик кадров в секунду в правом углу",
  cps: "Скорость кликов мышью за секунду",
  keys: "Компактные подсказки W A S D / Space",
  clock: "Локальное системное время",
  watermark: "Минимальная подпись GAYCLIENT с маскотом",
  coordinates: "X / Y / Z позиции игрока",
  performance: "Загрузка процессора и памяти",
  moduleList: "Отдельная плашка со списком включённых модулей",
};

export const defaultModules: GameModule[] = [
  {
    id: "fps-boost",
    name: "FPS Boost",
    category: "Утилиты",
    description: "Бережные пресеты для стабильного кадра.",
    bind: "F6",
    enabled: true,
  },
  {
    id: "fullbright",
    name: "Fullbright",
    category: "Визуал",
    description: "Повышает видимость в тёмных местах.",
    bind: "F7",
    enabled: true,
  },
  {
    id: "auto-sprint",
    name: "Auto Sprint",
    category: "Утилиты",
    description: "Удерживает спринт во время движения.",
    bind: "F8",
    enabled: false,
  },
  {
    id: "china-hat",
    name: "China Hat",
    category: "Визуал",
    description: "Конус над локальным игроком (Visuals).",
    bind: "—",
    enabled: false,
  },
  {
    id: "trail",
    name: "Trail",
    category: "Визуал",
    description: "Лента за игроком (Visuals).",
    bind: "—",
    enabled: false,
  },
  {
    id: "coordinates",
    name: "Coordinates",
    category: "HUD",
    description: "Координаты и направление игрока.",
    bind: "F9",
    enabled: false,
  },
  {
    id: "zoom",
    name: "Zoom",
    category: "Утилиты",
    description: "Плавное приближение по клавише.",
    bind: "C",
    enabled: false,
  },
  {
    id: "watermark",
    name: "Watermark",
    category: "HUD",
    description: "Компактная подпись клиента в углу.",
    bind: "—",
    enabled: false,
  },
];

export const hotkeys = [
  { keys: ["Right Shift"], label: "Открыть меню HUD" },
  { keys: ["1", "—", "5"], label: "Разделы настроек" },
  { keys: ["Ctrl", "S"], label: "Сохранить профиль HUD" },
  { keys: ["Esc"], label: "Закрыть редактор" },
  { keys: ["Delete"], label: "Отключить оверлей (односторонне)" },
];

export const caps = [
  { label: "Кадры в секунду", value: "144", suffix: "FPS" },
  { label: "Задержка ввода", value: "3.2", suffix: "мс" },
  { label: "Готовность HUD", value: "100", suffix: "%" },
];

export const statsSeries = {
  "7": { label: "7 дней", values: [42, 68, 55, 88, 64, 104, 86], labels: ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"] },
  "30": {
    label: "30 дней",
    values: [35, 55, 44, 72, 62, 90, 54, 78, 96, 66, 102, 84],
    labels: ["01", "04", "07", "10", "13", "16", "19", "22", "25", "27", "29", "30"],
  },
};
