export type TopTab = "settings" | "mods" | "profiles" | "stats";

export type Section = "home" | "hud" | "interface" | "graphics" | "sound" | "controls" | "other";

export type HudTab = "widgets" | "visuals" | "modules";

export type HudPosition = "top-left" | "top-right" | "bottom-left" | "bottom-right" | "custom";

export type WidgetKey =
  | "fps"
  | "cps"
  | "keys"
  | "clock"
  | "watermark"
  | "coordinates"
  | "performance"
  | "moduleList";

export interface HudSettings {
  widgets: Record<WidgetKey, boolean>;
  scale: number;
  opacity: number;
  padding: number;
  gap: number;
  textColor: string;
  position: HudPosition;
  x: number;
  y: number;
  moduleScale: number;
  moduleOpacity: number;
  moduleX: number;
  moduleY: number;
  showHearts: boolean;
  showHotbar: boolean;
}

export interface HatSettings {
  enabled: boolean;
  fill: boolean;
  rainbow: boolean;
  color: string;
  rainbowSpeed: number;
  opacity: number;
  radius: number;
  coneHeight: number;
  offset: number;
  floatAmount: number;
  floatSpeed: number;
}

export interface TrailSettings {
  enabled: boolean;
  fill: boolean;
  rainbow: boolean;
  color: string;
  rainbowSpeed: number;
  opacity: number;
  height: number;
  lifetime: number;
}

export interface VisualSettings {
  hat: HatSettings;
  trail: TrailSettings;
  vertexGradient: boolean;
  enableColors: boolean;
}

export interface InterfaceSettings {
  accent: "neon" | "lime" | "mint" | "cyan";
  density: "comfortable" | "compact";
  animations: boolean;
  glow: boolean;
  language: "ru" | "en";
  uiScale: number;
}

export interface SoundSettings {
  master: number;
  interface: number;
  effects: number;
  muted: boolean;
}

export interface GameModule {
  id: string;
  name: string;
  category: "HUD" | "Визуал" | "Утилиты";
  description: string;
  bind: string;
  enabled: boolean;
}

export interface HudPreset {
  id: string;
  name: string;
  createdAt: string;
  hud: HudSettings;
  visuals: VisualSettings;
}

export interface Toast {
  id: number;
  title: string;
  description?: string;
  tone: "success" | "info" | "warning" | "error";
}

export type WindowState = "normal" | "maximized" | "minimized" | "closed";
